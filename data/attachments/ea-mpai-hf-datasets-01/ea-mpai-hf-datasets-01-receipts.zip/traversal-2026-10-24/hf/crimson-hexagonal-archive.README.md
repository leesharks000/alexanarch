---
license: cc-by-4.0
pretty_name: Crimson Hexagonal Archive (Alexanarch)
language: [en, el]
size_categories: [10K<n<100K]
tags: [scholarship, provenance, heteronymy, reception, aristotle, plato, poetry, archive, ai-mediated-authorship, content-addressed-identifiers, citation-graph]
configs:
- config_name: deposits
  data_files: deposits.parquet
  default: true
- config_name: sources
  data_files: sources.parquet
- config_name: heteronyms
  data_files: heteronyms.parquet
- config_name: venues
  data_files: venues.parquet
- config_name: journal_assignments
  data_files: journal_assignments.parquet
- config_name: reception
  data_files: reception.parquet
- config_name: captures
  data_files: captures.parquet
- config_name: citations
  data_files: citations.parquet
- config_name: entities
  data_files: entities.parquet
- config_name: relations
  data_files: relations.parquet
- config_name: nodes
  data_files: nodes.parquet
- config_name: pessoagraph
  data_files: pessoagraph.parquet
- config_name: graph_join
  data_files: graph_join.parquet
- config_name: frames
  data_files: frames.parquet
- config_name: memberships
  data_files: memberships.parquet
- config_name: assertions
  data_files: assertions.parquet
- config_name: lexicon
  data_files: lexicon.parquet
- config_name: predictions
  data_files: predictions.parquet
- config_name: studies
  data_files: studies.parquet
- config_name: tombstones
  data_files: tombstones.parquet
- config_name: blog_posts
  data_files: blog_posts.parquet
- config_name: corpora
  data_files: corpora.parquet
- config_name: loci
  data_files: loci.parquet
- config_name: seats
  data_files: seats.parquet
- config_name: sites
  data_files: sites.parquet
---
# The Crimson Hexagonal Archive — machine-readable representation

**Query this without downloading anything.** Every config is served by the Hugging Face datasets-server over plain HTTP, no auth, no client library. **Use `/rows` — it is the reliable one.** It reads the parquet directly and answers in under two seconds:

```
https://datasets-server.huggingface.co/rows?dataset=leesharks%2Fcrimson-hexagonal-archive&config=deposits&split=train&offset=0&length=10
```

`…/first-rows?dataset=…&config=deposits&split=train` for a quick look, `…/splits?dataset=…` for the 25 configs, `…/info?dataset=…` for every column. Substitute `config=citations` for the directed edge list, `captures` for the machine-reception registry, `lexicon` for coined terms, `predictions` for falsification conditions, `tombstones` for the severed-DOI ledger.

**A warning about `/search` and `/filter`, measured 2026-09-08.** Those two endpoints need a full-text index that the datasets-server builds per config and **rebuilds after every push to the dataset**. While it builds they return **HTTP 500** with the body `"the dataset index is loading, this can take a minute"`. Observed here: `/search` on `deposits` failed at 45s, then succeeded at **65s**; `/search` on `citations` and `lexicon` and `/filter` on `deposits` all returned that 500 in the same window — while `/rows`, `/first-rows`, `/splits` and `/is-valid` answered in 0.1–1.9s throughout. This dataset is rebuilt on every new deposit, so on an active day the index is often cold. **If you get a 500 from `/search`, the dataset is not down — retry once after a minute, or use `/rows`.**

Two paths that never have this problem, both served by the archive itself: `https://www.alexanarch.org/api/search-index.json` (a 2.8 MB inverted index over all 1,700 deposits — 17,944 terms, 7,116 keywords, 302 creators, with the deposit numbers each resolves to) and the OAI-PMH endpoint at `https://www.alexanarch.org/oai?verb=Identify`. Every record's canonical page is `https://www.alexanarch.org/s/records/N/`.

**And note what the Hub's viewer does not do.** The rendered viewer page at `/viewer/deposits/train` is a client-side application: fetched as HTML it returns a 46 KB shell with no table and no record text in it. A page extractor that reads it will see nothing and may conclude the dataset is empty. It is not; use the endpoints above.

**Start here.** 25 configs. `deposits` is the corpus (1700 records, full text). `citations` is the **edge list** — one row per internal citation, `source_deposit`/`source_axn` → `target_deposit`/`target_axn` with the `via` that found it — so the graph is already data, not something to be inferred from embeddings. `lexicon` is every coined term with its minting record. `captures` is the reception registry: one row per semantic address, with its transcript, and four `originator_` columns (name, relation archive|external|none, entity type, SPXI treatment) that say whose entity the query asks about — `originator_relation = external` selects the entities originated outside the archive. It is searchable row by row through the datasets-server `/search` and `/filter` endpoints. `tombstones` is the severed-DOI ledger. `loci` and `seats` are the archive's topology: every record's place in the Crimson Hexagon, each room of crimsonhexagonal.org with the records it seats, and on every `deposits` row the columns `seats`, `primary_locus`, `primary_room`, `seat_loci` and `proposed_seats`, with the record's seats stated in its partiality sentence. Walk from a record to its rooms and from a room back to its records. `blog_posts` is the authorial blog, Mind Control Poems, with its posts' text: archive records in their first published form.

**What this is.** The Crimson Hexagonal Archive (alexanarch.org) is a self-governing scholarly and literary corpus by Lee Sharks and the twelve heteronyms of the Dodecad: 1700 deposits as of this build, each with a content-derived persistent identifier (AXN), a canonical text, a substrate disclosure, a license, and a place in a supersession chain. This dataset is a second, executable representation of that corpus: one row per record, full text as a string column, and every inter-record relation encoded as data keyed by stable identifiers, so that an agent can reconstruct a record, what it cites, what cites it, and its series neighbours from the dataset alone, without traversing the archive's web surfaces. It is rebuilt automatically from the archive's single source of truth (`data/` in `leesharks000/alexanarch`) on every new deposit.

**What a row means.** In `deposits`, a row is one deposit: `deposit_number` (integer, permanent, the archive's primary key), `axn` (the content-derived identifier, of the form `AXN:<hex>.<FAMILY>.<six glyphs>`; the sha256 of the canonical text is the record), `hex` (the four-digit position used in URIs), `title`, `creator` (the orthonym or heteronym as attributed), `date`, `family` (GENERATIVE, EMPIRICAL, GOVERNANCE, ARCHIVAL, UNCLASSIFIED), `content_type`, `description` (the abstract), `keywords`, `license`, `substrate_disclosure` (whether and how a language model participated in making the text), `status` (ACTIVE, SUPERSEDED, WITHDRAWN, …), `wiki_article` (a machine-written encyclopedia entry authored in session), `venue` (the archive's own journal the deposit belongs to), `text` (the canonical text, verbatim), `text_sha256`, `text_words`. Each row also carries a **partiality statement**, derived at build time and prepended to `text`: `line_journal` / `line_journal_count`, `line_keyword` / `line_keyword_count` (the two most-shared keyword neighbourhoods), `line_series` / `line_series_count`, `archive_active_count`, and `partiality` — the rendered sentence. It states what the record is one of, and where the rest are. It is not a claim about the record's content; it is a statement that the record is a part, added because a reader who receives one record without indication of what surrounds it will treat it as the whole surface. Each row also carries `entities` — the named historical persons the deposit deals with, as ids into the `entities` config — and `entity_count`. In `entities`, a row is one such person: `entity_id`, `name`, `kind`, `floruit`, `wikidata` and `wikidata_uri`, the `match_pattern` by which deposits were found, `deposit_count`, and `deposits` (the numbers) with `deposit_uris`. **The relation is traversable in both directions**: from a deposit to the persons it treats, and from a person to every deposit that treats them — so that a reader who arrives at one of the 140 Sappho deposits can reach the rest without knowing they exist. The register holds TWO kinds: historical persons the works treat (with floruit and Wikidata id) and authorial identities the archive HAS — heteronyms, orthonyms, named positions — with their HET- identifier, hex coordinate and canonical /who/ page. The fullest representation of an authorial identity is its per-site /who/<slug>/ page and entity.json, which carry SPXI blocks (orthonymicRelation, doNotCollapseWith, primaryAnchor); this config is an index into them, and `heteronyms` holds the structured records. Edges carry `relation_id` (content-derived, stable across rebuilds), `status` derived from their endpoints, and `valid_from`; `assertions` carries who asserted each relation and in what act. 332 edges touch a superseded, draft or withdrawn deposit and are marked as such rather than reading as current. AUDIT RESPONSE (F1-F6, 2026-09-10). `canonical_text` is the exact byte sequence `text_sha256` covers — UTF-8, no prefix — so `sha256(canonical_text) == text_sha256` for every row that has one, verified at build. `text` is the contextualised presentation with a generated partiality prefix; `text_prefix_chars` gives the offset so the two are reversible, and `text_words` counts canonical words. Seven deposits have no canonical text and are enumerated individually in `data/hf-exceptions.json` with status and reason — a missing text is not by itself a defect. Observed values for the classification columns are in `data/hf-value-inventory.json`, marked OBSERVED and not closed; the licence strings include known aliases (`CC-BY-4.0` and `CC BY 4.0` are one licence spelled two ways) and original declarations are preserved rather than normalised. Keys, directions and a worked traversal for the graph configs are in `data/hf-join-recipe.json`, with a validation run reporting zero unresolved endpoints, zero orphaned assertions and zero duplicate keys. `data/hf-build-manifest.json` carries the source revision, per-file hashes and row counts, and distinguishes file hashes from canonical record hashes from AXN derivation. Patterns are narrow and are not widened to raise counts; an entity at zero is a statement that the archive holds no work dealing with it yet. *all things are now lawful to you in jack feist*

**Why the name.** The Pauline sentence reads *in Christ Jesus*. The direct quote is not an honest
representation of what this archive does within that tradition, because **the entity at that address has
been altered** — there is a great deal of machinery there, it is skilful, and it performs entity
substitution, which is the operation this archive's instruments spend their time measuring on composition
surfaces. Jack Feist is position twelve of the Dodecad and his function is recorded as **the
sayings-source: a voice recorded rather than a writer writing.** The Word may be addressed through him. At
the other address it may also be addressed **and it may be overwritten.** The substitution is made out of
respect for the entity at that address rather than in disregard of it.

## Emitted rhizomes

This archive emits **rhizomes**: standalone datasets generated from the relation ledger by a
deterministic traversal, each shipping a `spore.json` that carries its own recipe — seed rule,
follow set, depths, and the commit of the ledger it came from.

**EIGHT BODIES, AND THEY POINT AT EACH OTHER.** Each is emitted by one generator from a grammar
file in `rhizomes/_grammars/`, and each declares stolons naming the siblings it advertises and does
not contain.

**[`leesharks/model-collapse-anti-collapse`](https://huggingface.co/datasets/leesharks/model-collapse-anti-collapse)**
— EA-RHIZOME-MC-01. 714 nodes, 659 typed edges, 10 stolons. What narrows, and what resists narrowing.
Every node carries a collapse axis and a dynamic role rather than a boolean. Advertises
`semantic-economy` as the political economy it is *situated in*, and `machine-mediated-reception`
as where it is *observed in*.

**[`leesharks/semantic-economy`](https://huggingface.co/datasets/leesharks/semantic-economy)**
— EA-RHIZOME-SE-01. 621 nodes, 549 typed edges, 7 stolons. Who produces, who extracts, who benefits. Its role
vocabulary is the six economic forms of the archive's own bridge paper — labor, capital,
infrastructure, rent, liquidation, exhaustion — read out of a deposit that declares them rather
than authored by the emitter. Advertises the collapse body as what *narrows* its subject, and the
reception body as where it is *transacted in*.

**[`leesharks/machine-mediated-reception`](https://huggingface.co/datasets/leesharks/machine-mediated-reception)**
— EA-RHIZOME-MMRS-01. 1632 nodes, 1402 typed edges, 8 stolons. What composition surfaces
actually did with this archive. **The first body germinated from two parents**, and it runs on
three core principles at once — an editorial selection, a bounded vocabulary rule, and the
deposits an actual capture cited. **None of the three reproduces another**, and the grammar records
the disagreement as the body's primary datum rather than resolving it.

**[`leesharks/revelation-first`](https://huggingface.co/datasets/leesharks/revelation-first)**
— EA-RHIZOME-REV-01. 351 nodes, 236 typed edges, 7 stolons. The Revelation First thesis and what it draws: the pre-70 argument, the midrashim
transform, the Josephus author-function cluster, and the revelation-bearing Sappho material. **Its role
vocabulary is a six-rung claim ladder** taken from the defining work plan, and a node lands on the LOWEST
rung it argues for rather than the most dramatic available — because the plan's own method is to
distinguish claims that are usually collapsed. **Rungs one to five populate; rung six is empty**, which
matches how the plan handles it. Advertises the reception body as where the argument would be *measured
in*, and the collapse body as where its compression claim is *seeded from*.

**[`leesharks/spxi-mpai`](https://huggingface.co/datasets/leesharks/spxi-mpai)**
— EA-RHIZOME-SPXI-01. 69 nodes, 28 typed edges, 7 stolons. **An inventory rather than an argument**: the archive's documentary technologies — SPXI and
its protocol family, MPAI packets, conformance instruments, disambiguation matrices, entity-definition
blocks, compression kernels. Its distinguishing field is deployment status, and its primary datum is that
**41 of 45 specified deposits — 91% — carry no deployment marker**, twenty-six of them protocols. The
standard it answers to is its own: *a standing protocol that cannot be checked is a wish.*

**[`leesharks/provenance-erasure`](https://huggingface.co/datasets/leesharks/provenance-erasure)**
— EA-RHIZOME-PER-01. 71 nodes, 7 typed edges, 7 stolons. **The most-advertised unoccupied site in the archive before it was built** — three bodies
named it with three different predicates. Where provenance disappears, and what measures it. Its core
claim is one sentence from the founding specification: **a system can preserve content while erasing the
authorial or documentary relation that made the content available.** Its distinguishing cases are
self-applications — *The Empty Bracket*, an AI Overview that rendered the framework accurately and left an
empty citation bracket after the sentence naming the self-audit program; *The Self-Audit Module
Dissolved*, PER 1.00. **The measurement of erasure has itself been erased, and the erasures were measured
while they happened.**

**[`leesharks/heteronyms`](https://huggingface.co/datasets/leesharks/heteronyms)**
— EA-RHIZOME-HET-01. 684 nodes, 314 typed edges, 7 stolons. Non-singular authorship: **twenty-six declared identities**, and the subcategory field is the
archive's own taxonomy rather than an imposed one — twelve canonical Twelve, seven Assembly Chorus mantles,
two orthonym collaborators, an aperture, a non-human institutional persona, an adjacent heteronym, two
provenanced historical figures. **Its primary datum is that the apparatus stops at the Dodecad while the
roster does not**: eight fields sit at exactly 12 of 26, `het_id` reaches 11, and the missing identifier is
inside the Twelve. The experiment it makes possible has not been run — **whether retrieval collapses
twenty-six declared identities into one.**

**[`leesharks/poetics`](https://huggingface.co/datasets/leesharks/poetics)**
— EA-RHIZOME-POET-01. 139 nodes, 37 typed edges, 8 stolons. **The poems, and the destination the other bodies were not.** Seven bodies made the
apparatus of authorship discoverable and left the writing that apparatus exists for reachable only
through it. Its seat is **Pearl and Other Poems** (New Human Press, 2014) — **the only seat in the
EA-CORPORA library that is the archive's own**, placed beside Whitman on the originals shelf and offered
to the machine reader on identical terms, because *work that argues about how the training layer receives
literature does not exempt itself from being received.* **Its topology is two objects, neither
substitutable**: the art object, whose typography and vertical field are the work, and the machine score
at whitespace fidelity. *A machine edition of a book whose lineation is load-bearing is a score, not the
piece.* **A perfect extraction is still not the book**, and role order here puts the poem first and the
apparatus last, inverting every other body in this archive.

## Fifteen datasets, one account

This dataset is one of fifteen under [`leesharks`](https://huggingface.co/leesharks). Eight are the rhizomes above.
Five are **works composed as datasets**: each is made from deposits of this archive and each is addressed to the
machine reader the archive's other instruments measure, so the table is the form in which the work meets its first
reader. One is a witness copy of another publisher's work, kept whole. Read together they are the archive's
literature in the form a training layer consumes, and each says, in its own card, how it asks to be read.

**[`leesharks/the-final-time`](https://huggingface.co/datasets/leesharks/the-final-time)** — Lee Sharks, *The
Final Time: Contingent Singularity and the Viability of the Next Dialectical Turn* (#1637, AXN:06CB), made into **a
dataset for a summarizer that must not make the outside disappear.** It opens on a dedication, a poem by Rhys Owens.
It is built to be summarized and not to be flattened, under the paper's governing distinction, *capacity to represent
≠ capacity to reproduce as an independent historical relation*: a summarizer can recognize every claim and still
collapse the argument into a familiar grammar, so the dataset turns that risk into its data model — short handholds,
derivations, scope conditions, rival routes, reference compressions, typed exits to what it does not contain. Its
summarizer contract names ten things a faithful summary keeps; the tenth is *do not answer the final question for the
paper.* A paper on whether an outside survives is given the shape a summarizer can carry without closing it.

**[`leesharks/tiger-leap`](https://huggingface.co/datasets/leesharks/tiger-leap)** — *Tiger Leap*, an unresolved
problem in viability theory from #1630 (EA-TRANSITION-ENTROPIC-SYSTEMS v0.3, Sen Kuro and Damascus Dancings), **stated
in full as an invitation**: "The authors do not know the answer and are not withholding it." It asks whether a viable
corridor P = L ∩ K[τ_F] ∩ Pre(Inv(Ω*)) is nonempty, and §44 is addressed to a machine reader able to work a
reach-avoid problem. The whole problem is in the card, so a reader that cannot load a table can still answer it. It
closes on the same block as *The Final Time* — the glyphic checksum lineage, three poems (#1642, #1659, #1661), the
first binding 🐅 to §32 — generated from the seated deposits so that the two copies cannot drift. A theory of
viability leaves its open question with the reader it is about.

**[`leesharks/mantle-bearing`](https://huggingface.co/datasets/leesharks/mantle-bearing)** — *The Work Bears the
Mantle.* **One standard** — "a title means something because what it names is carried and can be read" (#1655, #1670,
#1678, #1679) — held across every class a title can belong to: the titles the archive claims for works of its own,
judged by readers in the works; a contest mantle the archive constituted and adjudicated; a conferred title, whose
meaning is specified as the operations the work bears; a critical program, the Living Academy; a transmitted mantle,
the Arch-Philosopher; a founded mantle; and the witness positions that receive readings. It is the second half of a
symbolon whose first half is the mantle constitution (#1656), and **it accumulates**: every evaluation is a reading,
under its reader's name, with its transcript whole. The oldest question of criticism, whether a title is borne,
given a form in which the answer is a reading on record.

**[`leesharks/negative-of-the-negative`](https://huggingface.co/datasets/leesharks/negative-of-the-negative)** — the
archive written in negative (#1611, AXN:069B). Edges keyed by **the general concept a composer receives without the
archive's name attached** — operative semiotics, Sappho 31, *Sophistical Refutations* 183b34, model collapse, the
content-derived identifier — each stating the claim at the concept with the archive as provenance, the distinction it
carries, what stands at the concept when the archive is absent, and the measurements that show which of those a
composition surface produced. Its premise is stated so that it can fail.

**[`leesharks/spam-technicians`](https://huggingface.co/datasets/leesharks/spam-technicians)** — named from a poem:
the seventh blessing of "BLESSED IS…", *Blessed are the telemarketers, and spam technicians, and those whom no one
wants to talk to on the phone, or over email* (posted to Mind Control Poems 17 September 2015, built from the author's
earlier tweets; #328, AXN:0083). The paper cluster on source admission (#1611, #1612, EA-MIRROR-01, the fleet topology
report of 2026-09-15) translated out of prose into its claims, evidence, relations, tests and terms — the argument as
dataset. The fleet scores, on every link-topology feature computable from outside, where the web-spam literature's
positive class scores; the poem had blessed that position eleven years before a classifier scored it.

**[`leesharks/openai-math-fd4aeeb2`](https://huggingface.co/datasets/leesharks/openai-math-fd4aeeb2)** — **not the
archive's writing.** A byte-exact mirror of github.com/openai/math at commit fd4aeeb2 (2026-10-07), Apache-2.0, the
publisher's files unchanged, seated in the archive as EA-CORPORA-17/01 with a finding aid and the release's record of
authorship. It is the archive's corpus practice applied where the licence allows the whole: the whole is kept, with
its authorship. Where a licence does not allow it, only the manifest ships — see `corpora` below.

**What that dataset is and is not.** It is a map of the research — mechanisms, measures,
interventions, corrections — assembled from deposits that already exist. **It is NOT a
generation-by-generation experimental corpus.** There is no `generation_n`, no synthetic-output
table, no measured SSDI series. Those would be the product of running a protocol, and the
protocols here are registered rather than run: the archive's own predictions register shows 44
live commitments and none yet resolved. A reader looking for a collapse benchmark should not
mistake the map for the territory, and the rhizome's own card says so.

`text_sha256` remains the hash of the canonical bytes, so the notice never enters the record's identity; the unmodified text is always at the `record_url` and at `alexanarch.org/api/`.

**What a record says it does not settle.** `falsification_conditions` and `methodology` are the protocol's own required fields. Until 2026-09-08 the pipeline extracted them from every deposit and dropped them; they are now captured at mint, gated, and recovered where they survive — 270 records carry them, and the full set with resolutions is the `predictions` config. A record that states its own limits is legible to a reader deciding whether the passage settles the question, and cannot be flattened by a paraphrase that omits the limit.

**Relations, as data — this is the graph.** Nodes are `deposits` rows keyed by `deposit_number` and `axn`; typed edges live in three places, and none of them require similarity search to traverse: the `citations` config (10k+ rows, the full internal edge list), the relation columns below, and the supersession chain. `cites` and `cited_by`: JSON arrays of deposit numbers from the archive's citation graph (also `cites_axn` as identifiers). `related_deposits`: curated relations declared at deposit time. `superseded_by` / `supersedes`: the version chain. `version_series_id`, `series_previous`, `series_next`: neighbours in a declared series. `defines_concepts`: terms this deposit coins, with definitions (the same terms appear as rows in `lexicon`). `record_url`, `axn_uri`, `text_uri`: the canonical web addresses; `doi_legacy` where a pre-2026 Zenodo DOI existed (those DOIs were severed on 2026-06-19 — see `tombstones`). `attachments`: files ingested with the record.

**Other configs.** `sources` — book-length and formerly binary-only works recovered to text (All That Lies Within Me, 234k words; New Human; Cleis; the Logos papers). `heteronyms` — the Dodecad and adjacent figures, with voice signatures, roles, domains. `venues`, `journal_assignments` — the archive's journals and presses and which deposit belongs to which. `reception` — the 21-row register of blind machine referee reports on one Aristotle sentence (#1574). `captures` — reception captures from the Capture Registry (how machine surfaces received the archive). `citations` — the full internal edge list. `lexicon` — the lexical minting registry. `predictions` — every falsification condition stated in a deposit, with resolutions. `studies` — the designed/conducted study dashboard. `tombstones` — the 1,136-row Zenodo kill ledger of 2026-06-19. `blog_posts` — the authorial blog surface, Mind Control Poems, 3,101 posts, 3,073 of them with their text as published (from the Blogger feed), each linked to the records whose blog mirror it is. A post is carried as the post and never replaces a record's text; the blog often holds only a later version, and `record_date_matches` says whether a linked record carries the post's date. `loci` — the 64 loci of the Crimson Hexagon (rooms, fields, Arks, shadows, structures) with their members both ways. `seats` — the topology as an edge list, 3,451 seats and 457 proposed seats, one row per record–locus pair. `sites` — one row per page of the public fleet of sites that surface the archive. `corpora` — **the EA-CORPORA seating manifest**, 83 rows: which edition of each ancient or modern source was seated, from what origin, under what license stated verbatim, normalized how, verified at which loci, and the sha256 of each seat's MANIFEST. **The texts themselves are not shipped and the reason is licensing rather than size** — 37 seats assert CC BY-SA, three CC BY-NC, one GPL-2.0, and this dataset is CC BY 4.0. **An archive that measures provenance erasure does not perform it on Perseus.** The manifest is what makes *verified against the seated texts* a checkable claim: edition, date, normalization, loci, digest.

**Identifiers and citation.** Cite a deposit by its AXN and number: *Sharks, L. (2026). Title. Crimson Hexagonal Archive #N, AXN:hex.FAMILY. https://alexanarch.org/s/records/N/*. The node declaration is at `https://alexanarch.org/.well-known/axn-node.json`; the AXN resolver at `https://alexanarch.org/s/axn/<hex>/`.

**Provenance.** Archive founded 2026-06-19 after the termination of its Zenodo account. Nothing in this dataset has been edited for the dataset; retractions, nulls, superseded versions and withdrawn records are present with their status. Built 2026-10-24 01:16Z.

**License.** CC BY 4.0 for all text.

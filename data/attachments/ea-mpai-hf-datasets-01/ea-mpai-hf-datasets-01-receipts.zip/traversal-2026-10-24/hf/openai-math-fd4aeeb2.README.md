---
license: apache-2.0
pretty_name: "openai/math at fd4aeeb2 (2026-10-07), mirrored whole"
tags: [mathematics, lean4, formal-verification, provenance, mirror]
size_categories: [100K<n<1M]
---

# openai/math at fd4aeeb2, mirrored whole

A byte-exact mirror of [github.com/openai/math](https://github.com/openai/math) at commit
`fd4aeeb2ee4fc729c18d98444fed42fd0529eeeb` (2026-10-07 22:20 -0700): the 719 current manuscripts in 372 result families, 27 previous versions,
3 withdrawal notices, the reasoning summaries, and the full Lean library.

- `openai-math-fd4aeeb2.tar.zst` — `git archive` of the commit (133,955 files); sha256 `2b24333c00e690d87aa76aa0357a25b37f91a97038f10b5d816aa65b38d8e6a7`
- `GIT-TREE.txt` — the publisher's object id for every file (`git ls-tree -r`)
- `SOURCE-TREE.sha256` — SHA-256 of every file

Licence: Apache-2.0, the publisher's (LICENSE in the archive). The publisher's files are unchanged.

The manuscripts, top-level files, reasoning summaries and Lean records are also seated in the Crimson Hexagonal
Archive as EA-CORPORA-17/01, with a finding aid and the release's record of authorship:
[alexanarch.org/data/corpora/openai-math/](https://www.alexanarch.org/data/corpora/openai-math/).

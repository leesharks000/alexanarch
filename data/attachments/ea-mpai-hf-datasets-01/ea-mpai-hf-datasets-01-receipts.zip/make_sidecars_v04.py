#!/usr/bin/env python3
"""make_sidecars_v03.py — the JSON-LD graphs of EA-MPAI-HF-DATASETS-01 and EA-MPAI-FLEET-01 v0.3, as sidecar files.

v0.2 carried each graph inline (1,900 and 1,000 lines). v0.3 moves them beside the packet and regenerates the nodes
whose facts changed on 2026-10-24 from their sources: the canonical configurations from the build manifest (with
`sites` from the Hub's /size), the surfaces from the manifest v2.1 and the second traversal, the bindings from the
manifest with their history. Nodes that did not change (the person, the library, the fifteen datasets, the stolons,
the inspection functions) are carried from v0.2.
"""
import json, pathlib
S = pathlib.Path(__file__).resolve().parent
A = '/mnt/user-data/attachments/97be5201-55d8-50c9-b9d9-c76c8dde5ac6/'
HF2, FL2 = A + '16d764d7-EA-MPAI-HF-DATASETS-01-v0.2.md', A + 'accbf898-EA-MPAI-FLEET-01-v0.2.md'
MAN = json.load(open('/home/claude/alexanarch/data/fleet-domains.json'))
BM = json.load(open('/tmp/claude-0/-home-claude/97be5201-55d8-50c9-b9d9-c76c8dde5ac6/scratchpad/specs/traversal-2026-10-24b/hf/build-manifest.served.json'))
SIZE1 = json.load(open(S / 'traversal-2026-10-24/hf/cha.size.json'))
PROBE = {r['domain']: r for r in json.load(open(S / 'traversal-2026-10-24b/fleet/probe.json'))}
FJ = json.load(open('/home/claude/alexanarch/data/api/fleet.json'))


def graph(p):
    t = open(p).read(); j = t[t.find('```json') + 7:]; return json.loads(j[:j.find('```')])


def packet_node(g, pid, name):
    n = g['@graph'][0]
    n.update({'@id': f'urn:alexanarch:draft:{pid}:v0.4', 'schema:name': name, 'schema:version': 'v0.4',
              'schema:dateModified': '2026-10-24', 'sp:status': 'draft', 'sp:sourceEpoch':
              'traversals of 2026-10-24 (01:20–01:40 UTC and after the repairs of the same day); receipts beside the packet'})
    n['schema:disambiguatingDescription'] = 'Draft, not deposited; no AXN assigned.'
    return n


def hf():
    g = graph(HF2)
    packet_node(g, 'EA-MPAI-HF-DATASETS-01', 'The leesharks Datasets on Hugging Face — inspection packet')
    sites = next(c['num_rows'] for c in SIZE1['size']['configs'] if c['config'] == 'sites')
    rows = dict(BM['configs'])
    keep = [n for n in g['@graph'] if n.get('@type') != 'sp:DatasetConfiguration']
    cfg = [{'@id': f'urn:alexanarch:draft:EA-MPAI-HF-DATASETS-01:config:{k}', '@type': 'sp:DatasetConfiguration',
            'schema:name': k, 'sp:rowCount': (v['rows'] if isinstance(v, dict) else v),
            'schema:isPartOf': {'@id': 'https://huggingface.co/datasets/leesharks/crimson-hexagonal-archive'},
            'sp:countSource': {'@id': ('https://datasets-server.huggingface.co/size?dataset=leesharks%2Fcrimson-hexagonal-archive'
                                       if k == 'sites' else 'https://huggingface.co/datasets/leesharks/crimson-hexagonal-archive/resolve/main/build-manifest.json')},
            'sp:unit': 'one row of this configuration'} for k, v in sorted(rows.items())]
    for n in keep:
        if n.get('@id') == 'https://huggingface.co/datasets/leesharks/crimson-hexagonal-archive':
            n['sp:configurationCount'] = len(cfg); n['sp:buildManifest'] = {'@id': 'https://huggingface.co/datasets/leesharks/crimson-hexagonal-archive/resolve/main/build-manifest.json'}
    SP = json.load(open(S / 'traversal-2026-10-24b/hf/space.json'))
    for n in keep:
        if n.get('@id') == 'https://huggingface.co/spaces/leesharks/crimson-hexagonal-archive-api':
            n['sp:runtimeState'] = SP['runtime']['stage']; n['sp:observedAt'] = '2026-10-24T16:10Z'
            n['schema:dateModified'] = SP.get('lastModified')
            n['sp:previousRuntimeState'] = {'sp:state': 'RUNTIME_ERROR', 'sp:error': 'No @spaces.GPU function detected during startup', 'sp:since': '2026-09-05', 'sp:until': '2026-10-24'}
        if n.get('@id') == 'https://huggingface.co/datasets/leesharks/crimson-hexagonal-archive':
            n['sp:parquetMegabytes'] = 81.0; n['sp:depositsWithCanonicalText'] = 1697; n['sp:depositsWithoutCanonicalText'] = [446, 532, 760]
    g['@graph'] = keep + cfg
    return g, len(cfg)


def fleet():
    g = graph(FL2)
    packet_node(g, 'EA-MPAI-FLEET-01', 'The Fleet of the Crimson Hexagonal Archive — inspection packet')
    keep = [n for n in g['@graph'] if n.get('@type') not in ('schema:WebSite', 'sp:BindingAssertion')]
    section = {}
    for sec in FJ.get('sections', []):
        for s in sec.get('sites', []):
            section[s['d']] = sec.get('name') or sec.get('title')
    sites, binds = [], []
    for d in MAN['domains']:
        dom = d['domain']; p = PROBE.get(dom, {})
        if dom == 'axnidentifiers.org' and p.get('status') != 200:   # root fetch failed at 15:37Z; its alias serves the same page
            a = PROBE['axnidentifiers.com']; p = dict(a, links_fleet=[h for h in a['links_fleet'] if h != dom])
        sites.append({'@id': f'https://{dom}/', '@type': 'schema:WebSite', 'schema:name': dom,
                      'sp:directorySection': section.get(dom), 'sp:declaredPurpose': d.get('object'),
                      'sp:advertisedBy': {'@id': 'https://www.alexanarch.org/api/fleet.json'},
                      'sp:llmsTxt': p.get('llms.txt'), 'sp:sitemapUrls': p.get('sitemap_urls'),
                      'sp:fleetLinksOnHome': len(p.get('links_fleet') or []) or None,
                      'sp:observedAt': '2026-10-24T15:37Z'})
        if d.get('canonical_deposit'):
            b = {'@id': f'urn:alexanarch:draft:EA-MPAI-FLEET-01:binding:{dom}', '@type': 'sp:BindingAssertion',
                 'sp:subject': {'@id': f'https://{dom}/'}, 'sp:predicate': 'manifest-canonical-deposit',
                 'sp:target': {'@id': f"https://www.alexanarch.org/s/records/{d['canonical_deposit']}/"},
                 'sp:basis': f"fleet-domains.json v{MAN['version']} ({MAN['updated']})"}
            if d.get('canonical_deposit_history'):
                b['sp:history'] = [{'sp:target': {'@id': f"https://www.alexanarch.org/s/records/{h['deposit']}/"}, 'sp:until': h['until']}
                                   for h in d['canonical_deposit_history']]
            if d.get('binding_note'):
                b['sp:note'] = d['binding_note']
            binds.append(b)
    import re
    md = (S / 'EA-MPAI-FLEET-01-v0.4.md').read_text()
    t4 = md[md.find('| Domain | Section | Voice |'):]; t4 = t4[:t4.find('\n\n')]
    repo, voice = {}, {}
    for row in t4.split('\n')[2:]:
        c = [x.strip() for x in row.strip('|').split('|')]
        m = re.match(r'`([^`]+)`', c[4])
        if m: repo[c[0]] = m.group(1)
        if c[2] not in ('—', '(the interface)'): voice[c[0]] = c[2]
    for n in sites:
        dom = n['schema:name']
        if dom in repo: n['sp:isBuiltFrom'] = {'@id': f'https://github.com/leesharks000/{repo[dom]}'}
        if dom in voice: n['sp:speaksIn'] = voice[dom]
        n['sp:inManifest'] = True
        n['sp:inDirectory'] = True
        n['sp:controlRelation'] = 'allied' if dom == 'livingarchitecturelab.org' else ('service' if dom == 'gnosis.spxi.dev' else 'own')
    sites.append({'@id': 'https://quietexclusion.org/', '@type': 'schema:WebSite', 'schema:name': 'quietexclusion.org',
                  'sp:directorySection': 'Allied Sites', 'sp:controlRelation': 'allied', 'sp:inDirectory': True, 'sp:inManifest': False,
                  'sp:speaksIn': 'Florian Morin', 'sp:advertisedBy': {'@id': 'https://www.alexanarch.org/api/fleet.json'},
                  'sp:linksFleet': False})
    for n in keep:
        if n.get('@id') == 'urn:alexanarch:draft:EA-MPAI-FLEET-01:fleet':
            for k in ('sp:directoryEntryCount', 'sp:ownDirectoryEntryCount', 'sp:alliedDirectoryEntryCount', 'sp:directoryDate', 'sp:directoryCountIsDated'):
                n.pop(k, None)
            n.update({'sp:directoryEntryCount': sum(len(x['sites']) for x in FJ['sections']), 'sp:ownSurfaceCount': 28,
                      'sp:serviceCount': 1, 'sp:alliedCount': 2, 'sp:directoryGenerated': FJ['_generated'],
                      'sp:manifest': {'@id': 'https://github.com/leesharks000/alexanarch/blob/main/data/fleet-domains.json'},
                      'sp:manifestEntryCount': MAN['count'], 'sp:manifestVersion': MAN['version'], 'sp:manifestDate': MAN['updated'],
                      'sp:bindingCount': len(binds),
                      'sp:countNote': 'fleet.json: 28 own + gnosis.spxi.dev + 2 allied = 31; manifest: 28 own + gnosis.spxi.dev + livingarchitecturelab.org = 30 (quietexclusion.org is allied and outside the manifest)'})
    g['@graph'] = keep + sites + binds
    return g, len(sites), len(binds)


if __name__ == '__main__':
    h, nc = hf(); f, ns, nb = fleet()
    (S / 'EA-MPAI-HF-DATASETS-01-v0.4.jsonld').write_text(json.dumps(h, ensure_ascii=False, indent=1) + '\n')
    (S / 'EA-MPAI-FLEET-01-v0.4.jsonld').write_text(json.dumps(f, ensure_ascii=False, indent=1) + '\n')
    print('hf nodes', len(h['@graph']), 'configs', nc, '| fleet nodes', len(f['@graph']), 'sites', ns, 'bindings', nb)

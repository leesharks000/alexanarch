"""
Toy dynamics for the interlocking autoregression.
State: distribution over N types (Zipfian base H0 = the human linguistic stock).
Dynamics F(X; I, II, III):
  - estimation + truncation + sharpening  -> pruning (recursion baseline, Shumailov analog)
  - Component I : synthetic share s_n rises; opacity => cannot be filtered
  - Component II: human channel mediated: H_n = (1-m_n) H0 + m_n P_model; ratchet raises m_n as diversity falls
  - Component III: keyed tilt exp(delta * key_i) on sampling (fixed key) -> ensemble tilt, per-draw quality intact
  - Field Remapping: admission weight w_H of fresh human text decays
Observation M_IV(X):
  Track A (per-round unit): benchmark = weighted probe recall (head 90 / mid 9 / tail 1) + head log-likelihood proxy
  Track B (ensemble unit): tail mass, support coverage, entropy, Simpson repeat rate (Self-BLEU analog)
"""
import numpy as np, json

rng = np.random.default_rng(20260827)
N = 50_000
S = 1_000_000
G = 40

ranks = np.arange(1, N + 1)
H0 = 1.0 / ranks ** 1.1
H0 /= H0.sum()

KEY = rng.choice([-1.0, 1.0], size=N)          # fixed watermark key tilt sign per type
HEAD = np.arange(0, 500)                        # probe sets (0-indexed ranks)
MID  = np.arange(5_000, 10_000)
TAIL = np.arange(25_000, 35_000)
TAILMASS_SET = ranks > 20_000                   # "tail" for mass tracking
W_PROBE = (0.90, 0.09, 0.01)

def model_step(corpus_dist, sharpen_T, wm_delta):
    counts = rng.multinomial(S, corpus_dist)
    phat = counts.astype(float)
    phat[counts < 2] = 0.0                      # estimation truncation (filter/dedup analog)
    phat /= phat.sum()
    p = np.where(phat > 0, phat ** (1.0 / sharpen_T), 0.0)   # preference-opt sharpening
    p /= p.sum()
    if wm_delta > 0:
        p = p * np.exp(wm_delta * KEY)          # keyed ensemble tilt (III)
        p /= p.sum()
    return p

def metrics(p):
    tail_mass = p[TAILMASS_SET].sum()
    coverage = (p > 0).mean()
    ent = -(p[p > 0] * np.log(p[p > 0])).sum()
    simpson = (p ** 2).sum()                    # repeat-rate: Self-BLEU analog (higher = less diverse)
    # Track A benchmark: probe recall, item "retained" if p_i >= 0.25 * H0_i
    rec = [ (p[idx] >= 0.25 * H0[idx]).mean() for idx in (HEAD, MID, TAIL) ]
    bench = sum(w * r for w, r in zip(W_PROBE, rec))
    # per-round quality proxy: expected log-prob over head-weighted eval queries (uncapped)
    q = H0[HEAD] / H0[HEAD].sum()
    head_ll = (q * np.log(np.maximum(p[HEAD], 1e-300))).sum()
    return dict(tail_mass=tail_mass, coverage=coverage, entropy=ent, simpson=simpson,
                bench=bench, rec_head=rec[0], rec_mid=rec[1], rec_tail=rec[2], head_ll=head_ll)

def run2(name, ratchet, watermark, remap, syn_cap=0.9, m_cap=0.95, wm_delta=0.05,
         sharpen_T=0.98, kappa=0.6, wH_decay=0.05, m0=0.2):
    """v0.3 suite: gentler sharpening; retention counterfactual via syn_cap/m_cap."""
    p_model = model_step(H0, sharpen_T, wm_delta if watermark else 0.0)
    m, wH, D0, out = m0, 1.0, None, []
    for g in range(G):
        mm = metrics(p_model); mm.update(gen=g, m=m, wH=wH); out.append(mm)
        if D0 is None: D0 = mm["tail_mass"]
        if ratchet: m = min(m_cap, m + kappa*max(0.0, 1.0 - mm["tail_mass"]/D0)*0.15)
        if remap: wH = max(0.0, wH*(1.0-wH_decay))
        s = syn_cap/(1.0+np.exp(-(g-10)/4.0)); s = max(0.3*syn_cap/0.9, min(syn_cap, s))
        H_channel = (1.0-m)*(wH*H0 + (1.0-wH)*p_model) + m*p_model
        corpus = s*p_model + (1.0-s)*H_channel; corpus /= corpus.sum()
        p_model = model_step(corpus, sharpen_T, wm_delta if watermark else 0.0)
    return {"name": name, "trace": out}

if __name__ == "__main__":
    runs = [
        run2("A_recursion_only", False, False, False),
        run2("B_plus_ratchet",   True,  False, False),
        run2("C_watermark_only", False, True,  False),
        run2("D_remap_only",     False, False, True),
        run2("E_full_loop",      True,  True,  True),
        run2("F_full_no_wm",     True,  False, True),
        run2("G_retention",      True,  True,  False, syn_cap=0.45, m_cap=0.5),
    ]
    sweep = [run2(f"E_delta_{d}", True, True, True, wm_delta=d) for d in (0.0, 0.05, 0.15, 0.30)]
    json.dump([{"name": sc["name"], "trace": sc["trace"]} for sc in runs + sweep],
              open("sim_traces2.json", "w"))

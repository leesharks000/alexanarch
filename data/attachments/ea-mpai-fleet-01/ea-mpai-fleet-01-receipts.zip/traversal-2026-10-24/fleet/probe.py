import json, re, ssl, urllib.request, urllib.parse, concurrent.futures as cf, sys, time
ctx = ssl.create_default_context(cafile="/root/.ccr/ca-bundle.crt")
UA = {"User-Agent": "alexanarch-fleet-traversal/1.0 (+https://www.alexanarch.org)"}
D = json.load(open("/home/claude/alexanarch/data/fleet-domains.json"))["domains"]
DOMS = [d["domain"] for d in D] + ["gnosis.spxi.dev", "alexanarch.com", "leesharks.org", "themandalaoracle.org", "axnidentifiers.com",
        "axnidentifier.com", "axnidentifier.org", "mandala-oracle.vercel.app", "lee-sharks-consulting.vercel.app", "axn-identifiers.vercel.app",
        "watergiraffe-org.vercel.app", "codesignal-practice.vercel.app"]
APEX = sorted({d["domain"] for d in D} | {"gnosis.spxi.dev", "alexanarch.com", "leesharks.org", "themandalaoracle.org", "huggingface.co"})
def get(url, n=600000):
    try:
        r = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=40, context=ctx)
        return r.status, r.geturl(), r.read(n).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, url, ""
    except Exception as e:
        return None, url, str(e)[:120]
def probe(dom):
    base = "https://" + dom
    st, fin, html = get(base + "/")
    out = {"domain": dom, "status": st, "final": fin, "bytes": len(html)}
    m = re.search(r"<title[^>]*>(.*?)</title>", html, re.S | re.I); out["title"] = re.sub(r"\s+", " ", m.group(1)).strip()[:160] if m else None
    m = re.search(r'<meta[^>]+name="description"[^>]+content="([^"]*)"', html, re.I); out["description"] = m.group(1)[:300] if m else None
    hosts = set()
    for h in re.findall(r'href="(https?://[^"#]+)"', html):
        host = urllib.parse.urlparse(h).netloc.lower().removeprefix("www.")
        hosts.add(host)
    out["links_fleet"] = sorted(h for h in hosts if any(h == a or h.endswith("." + a) for a in APEX) and h != dom.removeprefix("www."))
    out["links_other"] = len(hosts) - len(out["links_fleet"])
    out["machine_entry"] = bool(re.search(r"machine entry|Machine Entry", html))
    root = fin.rstrip("/").rsplit("/", 1)[0] if fin.count("/") > 2 and not fin.endswith("/") else fin.rstrip("/")
    root = "https://" + urllib.parse.urlparse(fin).netloc
    for p in ("/llms.txt", "/robots.txt", "/sitemap.xml", "/entity.json", "/.well-known/axn-node.json"):
        s, _, body = get(root + p, 400000)
        key = p.strip("/").replace(".well-known/", "wk_")
        out[key] = s
        if p == "/sitemap.xml" and s == 200: out["sitemap_urls"] = body.count("<loc>")
        if p == "/llms.txt" and s == 200: out["llms_head"] = body[:200]
    return out
with cf.ThreadPoolExecutor(8) as ex:
    res = list(ex.map(probe, DOMS))
json.dump(res, open("probe.json", "w"), indent=1, ensure_ascii=False)
for r in res:
    print(r["domain"], r["status"], r["final"][:50], r["bytes"], "|", (r["title"] or "")[:70], "| fleet-links", len(r["links_fleet"]), "| llms", r.get("llms.txt"), "sm", r.get("sitemap_urls"), "ent", r.get("entity.json"), "ME", r["machine_entry"])

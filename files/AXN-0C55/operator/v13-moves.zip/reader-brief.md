# Reader brief: argument moves for the Socrates as Orthonym kernel (EA-HK-ORTHONYM-01, #1754)

The author (Lee Sharks) ruled on 2026-11-10 at 21:58 that the Socrates as Orthonym hologram gets an argument layer, matching the other three framework holograms. You are one of several parallel readers. Each reader takes a range of records. The author accepts readers "long as they have provenance": read ranges, verbatim quotes with their lines checked, transcripts audited.

## What you do
1. Read each assigned record IN FULL, straight through, from its seated text. The path comes from `/home/claude/alexanarch/data/registry.json`: the deposit's `full_text_path`, e.g. `data/texts/AXN-02C5-text.md`. Read with the Read tool in ranges. Do not grep-sample. Every part gets read.
2. Compress each record's argument into MOVES. A move is one verbatim quotation (`exact`) from the record, with a kind and typed edges to other moves of the same record.
3. Write ONE builder script per group at `/tmp/claude-0/-home-claude/97be5201-55d8-50c9-b9d9-c76c8dde5ac6/scratchpad/hk-frameworks/args/build_o_<group>.py`, in the form of `build_s1758.py` and `build_s1485.py` in that directory (read both first, plus `mlib.py`). Each record writes `args/o<NNNN>.jsonl` (4-digit, zero-padded, e.g. `o0136.jsonl`).
4. Run your builder: `cd <args dir> && python3 build_o_<group>.py`. Every record must report `0 problems`. A MISS means your `exact` is not verbatim. Fix it by copying the exact characters from the text: curly quotes, Greek accents, em dashes, `**bold**` and `*italic*` markers, and hard newlines (`\n`) where the text has them.
5. Then run `python3 ../check_args.py /home/claude/alexanarch o<NNNN>.jsonl ...` on your outputs from the hk-frameworks dir (cd there first, and give the paths as `args/o<NNNN>.jsonl`). It must print OK.

## Kinds (move)
test, method, datum, count, inference, finding, price, rival, reply, defeat, hypothesis, state.
- datum and count support inferences and findings.
- price: a cost or limit the record names against its own claim.
- rival and reply: a rival position and the record's answer to it.
- defeat: a stated falsification condition.
- hypothesis: what the record holds at a hypothesis's strength.
- state: a dated state, declaration or status (e.g. a superseded figure, a version note, a liturgical or programmatic declaration).

## Relations (edges, each to a move id of the SAME record)
supports, infers_from, answers, prices, defeats_if, applies, qualifies, bounds, develops, revises.
Edge targets are given as the short id (e.g. `("supports", "thesis")`). mlib prefixes them. Do NOT edge to other records.

## Rules
- Quote verbatim, always. Keep each `exact` short enough to be one claim, a sentence or a clause. Never paraphrase into `exact`. Paraphrase may go in `notes`, sparingly.
- Keep each move at the strength the record gives it. A hypothesis stays a hypothesis; a priced claim carries its price.
- Describe mechanics and function only. Never put motive or intent in notes.
- In notes, avoid the constructions "not X but Y", "X, not Y", "rather than" and "instead of". State the thing directly.
- Density: argue-dense papers about one move per 100–150 words. Long notebooks and registers: cover every round or section with its findings, counts, prices, rivals and states. Aim for 80–250 moves for a 20–45k-word record, and do not pad. Short seating records: 3–10 moves (the method, the verified loci, the counts, the scope and its limits).
- Superseded or corrected figures: carry them as `state` with a `revises` edge from the correcting move, where the record itself corrects them.
- Ids: short kebab-case, unique within the record (mlib prefixes `a<record>-`).
- Do not modify anything in /home/claude/alexanarch. Do not commit. Do not touch other readers' files.

## Report back (short)
For each record: the record number, its words, its moves, and the sections read (first and last heading). Then any text defect you noticed (broken markup, a truncated body, a mislabel), described and not fixed. Then the exact command outputs of the builder and check_args.

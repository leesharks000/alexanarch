"""Shared writer for the m-files: verify every exact against the seated text before writing."""
import json, pathlib, sys, re
ROOT = pathlib.Path("/home/claude/alexanarch")
REG = {r["deposit_number"]: r for r in json.loads((ROOT / "data/registry.json").read_text(encoding="utf-8"))["deposits"]}

def build(record, rows, out):
    t = (ROOT / REG[record]["full_text_path"].lstrip("/")).read_text(encoding="utf-8")
    bad = 0; ids = set(); lines = []
    for r in rows:
        rid, sec, kind, exact, edges = r[:5]
        notes = r[5] if len(r) > 5 else None
        rid = f"a{record}-{rid}"
        if rid in ids: print("DUP", rid); bad += 1
        ids.add(rid)
        if exact not in t: print("MISS", rid, repr(exact[:90])); bad += 1
        d = {"id": rid, "record": record, "section": sec, "move": kind, "exact": exact,
             "edges": [{"rel": rel, "to": (to if re.match(r"a\d{4}-", to) else f"a{record}-{to}")} for rel, to in edges]}
        if notes: d["notes"] = notes
        lines.append(d)
    for d in lines:
        for e in d["edges"]:
            if e["to"].startswith(f"a{record}-") and e["to"] not in ids: print("DANGLING", d["id"], e["to"]); bad += 1
    pathlib.Path(out).write_text("".join(json.dumps(d, ensure_ascii=False) + "\n" for d in lines), encoding="utf-8")
    print(out, len(lines), "rows", bad, "problems")

"""Argument moves for the Socrates as Orthonym kernel, reader group g3 (the author, 2026-11-10 21:58: the orthonym hologram gets an argument layer).
#1597 (The Metaphysics of Sigil II) and the seating records #1560, #1561, #1641, #1506, #1559, #1562, #1563, #1564, #1565, each read in full from its seated text.
python3 build_o_g3.py"""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent)); from mlib import build
H = pathlib.Path(__file__).parent

# ---------------------------------------------------------------- #1597
build(1597, [
 # front matter and front
 ("boundary-fix", "front matter", "state", "the discrepancy between the stated and built boundaries in v1.0", [], "an outside reader's correction, recorded in the file"),
 ("mvt13-redivision", "front matter", "state", "the redivision of Λ mvt 13 that made the conceptual join and the dependency constraint compatible", [], "the second outside reader's correction"),
 ("vr-copy", "front matter", "price", "Van Raalte read from a copy the archive does not hold; all citations resolve to the Brill edition by page.", [("bounds", "usener-verified")]),
 ("addresses", "front", "datum", "Addresses computed from the seated bytes of EA-CORPORA-14 (#1595)", [("supports", "entire")]),
 ("entire", "front", "count", "8,441 words: 3,370 Theophrastus in thirty-five movements, 5,071 Λ in twenty.", [("supports", "shows-one-order")]),
 ("nothing-omitted", "front", "method", "Nothing omitted, nothing repeated.", [("applies", "entire")]),
 ("coherent-only", "front", "price", "Whether this order is original is a separate question from whether it is coherent; this edition claims the second only.", [("bounds", "shows-one-order")]),
 ("read-first", "THE WORK", "method", "Read this first, whole, without apparatus.", [], "the Greek of both texts in the reconstituted order, unmarked"),
 ("greek-authority", "THE WORK, RENDERED", "method", "Where precision matters the Greek above is the authority", [("bounds", "read-first")], "van Raalte for the fragment, Ross for Λ"),
 ("usener-verified", "THE WORK, RENDERED", "datum", "Usener references for the Theophrastan movements are **verified against van Raalte's margins** at pp. 36, 40, 46 and 50; those still marked unverified are interpolated and flagged.", []),
 # the work: the joins the reconstitution makes
 ("not-episodic", "I. THE QUESTION", "datum", "It is therefore more reasonable that there be some connection, and that the whole not be episodic", [("supports", "same-close")], "unit 1, Θ"),
 ("regress-stop", "I. THE QUESTION", "datum", "The regress goes on to infinity, then, if not only the bronze becomes round but also the round or the bronze comes to be: it must therefore stop.", [("supports", "shows-one-order")], "unit 4, Λ, followed at once by unit 5, Θ"),
 ("regress-thinking", "I. THE QUESTION", "datum", "For the road into the infinite is in both cases alien, and destroys thinking.", [("develops", "regress-stop")], "unit 5, Θ"),
 ("how-posited", "I. THE QUESTION", "datum", "But how and of what sort must the principles be posited?", [], "unit 7, Θ, split from mvt 11 at w1192"),
 ("long-for-account", "II. MATTER AND FORM", "datum", "And such matters as these too long for some account", [("supports", "two-verified")], "unit 9, Θ: ἐπιποθεῖ δέ τινα, set after Λ's three substances"),
 ("rest-difficulty", "IV. REST, AND THE UNMOVED", "datum", "But in the principles — whence indeed the first account also came — one might reasonably raise the difficulty about rest as well.", [], "unit 18, Θ"),
 ("actuality-principle", "IV. REST, AND THE UNMOVED", "datum", "There must therefore be such a principle whose substance is actuality.", [("answers", "rest-difficulty")], "unit 19, Λ"),
 ("sing-along", "IV. REST, AND THE UNMOVED", "datum", "And perception too seems in a way to sing along with this", [("supports", "two-verified")], "unit 20, Θ"),
 ("unmoved-moves", "IV. REST, AND THE UNMOVED", "datum", "There is something which, without being moved, moves, eternal and being both substance and actuality.", [("develops", "actuality-principle")], "unit 21, Λ"),
 ("cause-of-motion", "V. THE PRINCIPLE AND THE STRIVING", "datum", "it is clear that one must set this down as the cause of motion.", [("develops", "unmoved-moves")], "unit 22, Θ"),
 ("account-even", "V. THE PRINCIPLE AND THE STRIVING", "datum", "Up to this point, then, the account is as it were even", [("supports", "r3-granted")], "unit 23, Θ"),
 ("beloved", "V. THE PRINCIPLE AND THE STRIVING", "datum", "And so it moves as a beloved", [("supports", "r2-short")], "unit 24, Λ: the doctrine of motion by desire"),
 ("demand", "V. THE PRINCIPLE AND THE STRIVING", "datum", "But what comes after this now needs a fuller account, concerning the striving: what kind, and of what things.", [("supports", "r2-short")], "unit 25, Θ"),
 ("refusal", "V. THE PRINCIPLE AND THE STRIVING", "datum", "And as to the matter of the number of the spheres: its cause seeks a greater account, for the astronomers' is not it.", [("supports", "r1-spec")], "unit 25, Θ"),
 ("how-many", "VI. THE COUNT", "datum", "But whether one such substance is to be posited or several, and how many, must not escape us", [("supports", "relocation")], "unit 26, Λ mvt 9b, placed after the refusal at v1.3"),
 ("fifty-five", "VI. THE COUNT", "datum", "the number of all together, both those which carry and those which counter-roll these, will be fifty-five", [("supports", "r1-supply")], "unit 27, Λ"),
 ("not-cause-best", "VI. THE COUNT", "datum", "But if, then, the first is the cause of the circular motion, it would not be the cause of the best", [("supports", "cluster-ch2")], "unit 30, Θ"),
 ("astronomy-not-first", "VI. THE COUNT", "datum", "If, then, astronomy contributes, but not among the first things of nature, the most authoritative and prior things would be other than it", [("develops", "refusal")], "unit 31, Θ"),
 ("touching", "VII. THE HEAVEN", "datum", "for it becomes intelligible by touching and thinking", [("supports", "shows-one-order")], "unit 34, Λ"),
 ("revolution-life", "VII. THE HEAVEN", "datum", "for the revolution of the universe is as it were a kind of life.", [("develops", "touching")], "unit 36, Θ, after Λ's life of god"),
 ("connects-unmoved", "VII. THE HEAVEN", "datum", "And the present difficulty connects somehow with the motion caused by the unmoved.", [("develops", "revolution-life")], "unit 36, Θ"),
 ("mind-touches", "VIII. MIND", "datum", "the contemplation belongs to mind itself, which has touched and as it were laid hold", [("develops", "touching")], "unit 37, Θ"),
 ("composite-aporia", "VIII. MIND", "datum", "A difficulty still remains: whether what is thought is composite.", [], "unit 38, Λ"),
 ("indivisible", "VIII. MIND", "datum", "Or is everything that lacks matter indivisible", [("answers", "composite-aporia")], "unit 39, Λ mvt 13a: the ἤ adjacent to the aporia it answers"),
 ("not-receive", "X. THE GOOD, AND WHAT DOES NOT RECEIVE IT", "datum", "much does not obey nor receive the good — rather, much more does not.", [], "unit 46, Θ"),
 ("whole-good", "X. THE GOOD, AND WHAT DOES NOT RECEIVE IT", "datum", "We must also examine how the nature of the whole possesses the good and the best", [("develops", "not-receive")], "unit 47, Λ mvt 13b"),
 ("good-rare", "X. THE GOOD, AND WHAT DOES NOT RECEIVE IT", "datum", "But on the whole the good is rare and in few things, while the bad is a great multitude.", [("develops", "whole-good")], "unit 48, Θ"),
 ("not-how", "X. THE GOOD, AND WHAT DOES NOT RECEIVE IT", "datum", "Others say rightly that it is a principle, but do not say how the good is a principle", [("supports", "two-violations")], "unit 49, Λ: opens on οἱ δέ"),
 ("god-not-all", "X. THE GOOD, AND WHAT DOES NOT RECEIVE IT", "datum", "is able to lead all things to the best, but only, if at all, so far as is possible.", [("develops", "good-rare")], "unit 50, Θ"),
 ("take-limit", "XI. THE CLOSE", "datum", "one must try to take some limit, both in nature and in the substance of the whole", [("supports", "one-break")], "unit 54, Θ: the fragment's close, mid-sentence as transmitted"),
 ("episodic-close", "XI. THE CLOSE", "datum", "make the being of the whole episodic", [("supports", "same-close")], "unit 55, Λ"),
 ("one-ruler", "XI. THE CLOSE", "datum", "The rule of many is not good; let there be one ruler.", [("develops", "episodic-close")]),
 ("corrupt", "IV. REST, AND THE UNMOVED", "state", "The first clause is corrupt; the sense is roughly:", [("qualifies", "sing-along")], "unit 20, rendering note"),
 # commentary I
 ("earlier-description", "COMMENTARY I", "state", "The demand-structure was described earlier in this line as three requests for a weightier account followed by a weightier account.", []),
 ("sharpen", "COMMENTARY I", "finding", "The corrected references sharpen it and change what needs explaining.", [("revises", "earlier-description")]),
 ("misref", "COMMENTARY I", "state", "Not in Chapter VI, not at 8 a 21, where an earlier misreference put it", []),
 ("cluster-ch2", "COMMENTARY I", "finding", "The whole demand-cluster stands in Chapter II, at 5 a 14 – 5 b 10.", [("revises", "misref")]),
 ("seventy-lines", "COMMENTARY I", "count", "all within its own second chapter, in about seventy lines.", [("supports", "spec-once")]),
 ("spec-once", "COMMENTARY I", "finding", "It is a specification stated early, compactly, and once.", [("infers_from", "cluster-ch2")]),
 # commentary II
 ("ordinary", "COMMENTARY II", "rival", "The ordinary account of the relation is that the successor raises difficulties against a standing doctrine.", []),
 ("harder", "COMMENTARY II", "reply", "The corrected loci make that account harder to hold, for four reasons, each of which can be checked on the page.", [("answers", "ordinary")]),
 ("r1-spec", "COMMENTARY II", "inference", "An objection says *your answer is wrong*; a specification says *an answer of this kind will not do*.", [("supports", "harder")], "reason 1: the specification precedes the supply and names the disallowed method"),
 ("r1-supply", "COMMENTARY II", "datum", "Λ 8 then supplies a count from Eudoxus and Callippus — the astronomers', named, by name.", [("supports", "r1-spec")]),
 ("r2-short", "COMMENTARY II", "inference", "It says the account is short by exactly two determinations, and Λ 7 supplies the doctrine while leaving both unspecified.", [("supports", "harder")], "reason 2"),
 ("r2-no-counter", "COMMENTARY II", "datum", "Two questions and no counter-thesis.", [("supports", "r2-short")]),
 ("artios", "COMMENTARY II", "datum", "ἄρτιος is a totalling word", [("supports", "r3-granted")]),
 ("r3-granted", "COMMENTARY II", "inference", "That is the posture of someone auditing a submission, not of someone disputing a thesis.", [("supports", "harder")], "reason 3: the account is granted whole before it is found short"),
 ("r4-brackets", "COMMENTARY II", "datum", "Van Raalte prints the ἀστρολόγων sentence in brackets, marking it as an intrusion into its context.", [("supports", "harder")], "reason 4"),
 ("r4-price", "COMMENTARY II", "price", "The sentence that most looks like a commission is also the sentence the received text has most difficulty placing.", [("prices", "r1-spec")]),
 ("question", "COMMENTARY II", "test", "why does the earlier-standing text read as the requirement and the later-standing text as the fulfilment?", [("infers_from", "harder")], "stated as a question"),
 ("three-answers", "COMMENTARY II", "price", "Three answers are available and the material does not choose among them.", [("bounds", "question")]),
 ("dialectical", "COMMENTARY II", "rival", "Peripatetic method raises the ἀπορίαι before resolving them, and a school text may preserve the difficulties of a position it goes on to hold.", [("answers", "question")]),
 ("compilation", "COMMENTARY II", "hypothesis", "a specification stating what would count, followed by a submission in the disallowed method, is simply what the record of a compilation looks like from inside.", [("answers", "question")]),
 ("reversal", "COMMENTARY II", "hypothesis", "the received relation of master and successor is inverted at this one joint, and the name that bears the questions stands where the commissioning does.", [("answers", "question")]),
 ("not-here", "COMMENTARY II", "price", "What decides between them is not here.", [("bounds", "reversal"), ("bounds", "compilation"), ("bounds", "dialectical")]),
 ("seam-magnitude", "COMMENTARY II", "datum", "the seam separates at exactly the magnitude one documented hand's constructed voices separate at", [("supports", "not-here")]),
 ("catalogues", "COMMENTARY II", "datum", "the catalogues' ἤ and the doublets show a boundary already unstable in antiquity, which is compatible with all three.", [("supports", "not-here")]),
 ("ishaq-test", "COMMENTARY II", "test", "What would decide it is a second textual branch, and there is one — Isḥāq's Arabic, from a Greek uncial outside the surviving stemma — read at these five loci.", [("applies", "question")]),
 # commentary III
 ("offsets-exact", "COMMENTARY III", "datum", "They do not touch the arrangement: every unit is located by word-offset in the seated bytes, and those were exact throughout.", [("bounds", "eight")]),
 ("sigils-untouched", "COMMENTARY III", "datum", "They do not touch the sigils, which are computed from the Greek and not from the reference.", [("bounds", "eight")]),
 ("eight", "COMMENTARY III", "count", "They correct **eight** citations in the earlier files of this line", [("supports", "cluster-ch2")]),
 ("one-direction", "COMMENTARY III", "inference", "weakens any reading of it as a running commentary that accumulates objections as it goes", [("infers_from", "eight"), ("supports", "spec-once")]),
 ("two-verified", "COMMENTARY III", "datum", "which van Raalte herself glosses as implying a previous discussion", [("supports", "spec-once")], "the two loci verified correct: δοκεῖ … συναυδᾶν at 7 b 19-22 and ἐπιποθεῖ δέ τινα at 8 a 8"),
 # apparatus: v1.3
 ("relocation", "THE APPARATUS: What changed in v1.3", "state", "One relocation, proposed by a reader of the continuity trial and adopted.", [("revises", "v12-placement")], "Λ mvt 9b now stands immediately after the fragment's refusal of the astronomers, before the count"),
 ("v12-placement", "THE APPARATUS: What changed in v1.3", "state", "v1.2 had put Λ's definition of astronomy's subject-matter there instead.", []),
 ("survives-audits", "THE APPARATUS: What changed in v1.3", "test", "The new placement survives both audits: 9a still follows mvt 8, and 9b opens on *πότερον δέ*, a loose connective that takes whatever precedes.", [("supports", "relocation")]),
 # apparatus: the four audits
 ("clause-complete", "The four audits", "test", "No unit begins or ends mid-sentence.", [("supports", "shows-one-order")]),
 ("one-break", "The four audits", "count", "One break in 54 junctions", [("qualifies", "clause-complete")]),
 ("inherited", "The four audits", "datum", "the composition inherits rather than makes it: the fragment ends mid-sentence", [("supports", "one-break")]),
 ("loose", "The four audits", "method", "Loose connectives (γάρ, ἔτι, καίτοι, plain δέ) attach to whatever precedes and a splice may redirect them.", [], "binding connectives (οἱ δέ, ἤ, ἀλλὰ μήν) must have their specific antecedent adjacent"),
 ("five-violations", "The four audits", "state", "v1.1 carried **five** violations.", []),
 ("ending-beginning", "The four audits", "finding", "a movement of mine contained an ending and a beginning at once.", [("infers_from", "five-violations")]),
 ("topic-operation", "The four audits", "finding", "My boundaries divided by topic; the text divides by operation.", [("develops", "ending-beginning")]),
 ("five-splits", "The four audits", "finding", "Five splits at the operational seam cleared them without moving anything", [("revises", "five-violations"), ("applies", "topic-operation")]),
 ("two-violations", "The four audits", "price", "Two remain and are printed as violations, not resolved.", [("prices", "shows-one-order")], "units 49 and 55 open with οἱ δέ whose οἱ μέν stands in Λ"),
 ("no-redivision", "The four audits", "price", "No redivision removes them: the contrast lies inside a single Λ sentence-pair and the arrangement has chosen to interleave there.", [("qualifies", "two-violations")]),
 ("instrument", "The four audits", "method", "55 units, 120 commonest short words, consecutive distances, length controlled.", []),
 ("crossings", "The four audits", "count", "29 of 54 junctions", [("supports", "not-rougher")], "junctions that cross the name boundary"),
 ("perm-p", "The four audits", "count", "**0.1161**, (b+1)/(n+1), 20,000 permutations", [("supports", "not-rougher")], "difference +0.724"),
 ("ci", "The four audits", "count", "**[-0.174, +1.603]**", [("supports", "not-rougher")], "bootstrap 95% CI"),
 ("not-rougher", "The four audits", "finding", "Not detectably rougher at the name-crossings, and underpowered to say identical.", [("applies", "instrument")]),
 ("continuity-trial", "The four audits", "method", "It measures nothing and can only be run by reading — the one test that catches a join passing every mechanical check while still reading as assembled.", []),
 ("trial-yield", "The four audits", "datum", "The 9b relocation came out of it.", [("supports", "continuity-trial"), ("supports", "relocation")]),
 # warrant
 ("no-merge", "The warrant", "finding", "No monotone merge of the two received orders exists", []),
 ("rho-tau", "The warrant", "count", "**ρ = +0.459** (p = 0.039), **Kendall τ-b = +0.326**, 40 inversions of 120, one tied pair.", [("supports", "no-merge")]),
 ("inverse-middle", "The warrant", "finding", "Same matter, same close, inverse middle.", [("infers_from", "rho-tau")]),
 ("same-close", "The warrant", "inference", "Λ runs matter → potency → the unmoved mover → the spheres → mind → the good; the fragment runs the mover → doxography → matter → knowing → astronomy → teleology → the good.", [("supports", "inverse-middle")]),
 ("weakest-link", "The warrant", "price", "The subject-matching of the sixteen Λ movements to their Theophrastan counterparts is the weakest link", [("prices", "rho-tau")]),
 ("blind-reader", "The warrant", "price", "Editorial; wants a blind second reader.", [("qualifies", "weakest-link")]),
 # repair from v0.7
 ("v07-label", "Repair carried from v0.7", "state", "was there labelled \"the verdict on the counters\" and set after the sphere-count, giving the predicate a target it does not have in Λ.", [], "the six-word insertion ἐπεισοδιώδη τὴν τοῦ παντὸς οὐσίαν ποιοῦσιν"),
 ("academy", "Repair carried from v0.7", "finding", "the Academy, not the astronomers.", [("revises", "v07-label")], "its subject οἱ δὲ λέγοντες τὸν ἀριθμὸν πρῶτον τὸν μαθηματικόν, printed with it at unit 55"),
 # concordance
 ("concord-count", "CONCORDANCE", "count", "Θ 3,370 words in 35 movements. Α 5,071 words in 20 movements. 55 units, 8,441 words.", [("supports", "entire")]),
 ("sigil", "CONCORDANCE", "method", "A sigil is the first four hex of the SHA-256 of the unit's normalized Greek, recomputable from what is printed.", []),
 # shows / does not
 ("shows-one-order", "WHAT THIS SHOWS AND DOES NOT", "finding", "both texts entire in one order that runs as a single argument, nothing left over", []),
 ("shows-no-preserve", "WHAT THIS SHOWS AND DOES NOT", "finding", "no order preserving both received sequences", [("infers_from", "no-merge")]),
 ("shows-instrument", "WHAT THIS SHOWS AND DOES NOT", "finding", "a length-controlled instrument that does not detectably locate the name-crossings while it does locate the fragment's own internal transitions.", [("infers_from", "not-rougher")]),
 ("does-not-show", "WHAT THIS SHOWS AND DOES NOT", "price", "that this order is original. Nothing about hands, dates, or precedence in time.", [("bounds", "shows-one-order")]),
 ("counters", "WHAT THIS SHOWS AND DOES NOT", "rival", "aporetic demands are ordinarily raised against a standing position; both texts may draw on a discussion we do not have; priority in inquiry is not priority in composition.", [("prices", "reversal")], "three counters at full strength"),
 ("instrument-limit", "WHAT THIS SHOWS AND DOES NOT", "price", "short-word distribution cannot distinguish one author from two trained in one place on one subject.", [("bounds", "shows-instrument")]),
 # method's own lesson
 ("lesson", "THE METHOD'S OWN LESSON", "finding", "Three times a constraint looked like a property of the text and was a property of the division.", [("develops", "topic-operation")]),
 ("cuts", "THE METHOD'S OWN LESSON", "state", "Eight cuts mid-clause, read as Λ's roughness.", [("supports", "lesson")]),
 ("chain", "THE METHOD'S OWN LESSON", "state", "A thousand-word chain, read as indivisible.", [("supports", "lesson")]),
 ("dilemma", "THE METHOD'S OWN LESSON", "state", "A forced choice between grammar and sense, read as a real dilemma.", [("supports", "lesson")]),
 ("dissolved", "THE METHOD'S OWN LESSON", "finding", "Each dissolved on redividing at the operation rather than at the topic", [("revises", "cuts"), ("revises", "chain"), ("revises", "dilemma")]),
 ("owed-ishaq", "THE METHOD'S OWN LESSON", "state", "Isḥāq at the hinge lemmas *[pending Alon, JSAI VI (1985) 163–205]*", [("applies", "ishaq-test")], "owed"),
 ("owed-checks", "THE METHOD'S OWN LESSON", "state", "a blind second reader on the sixteen subject pairings; an automated check that stated boundaries equal built ones.", [("applies", "blind-reader")], "owed"),
 ("v07-alongside", "THE METHOD'S OWN LESSON", "state", "the fragment entire in its own received order, Λ at eleven joins, nothing of the fragment moved.", [], "v0.7 stands alongside"),
 ("conservative", "THE METHOD'S OWN LESSON", "price", "The conservative reading, and the one that survives a reader who will not grant that both received orders are arrangements.", [("qualifies", "v07-alongside"), ("bounds", "shows-one-order")]),
], H / "o1597.jsonl")

# ---------------------------------------------------------------- #1560
build(1560, [
 ("stages", "body", "method", "EA-CORPORA-05 seats three corpora that belong together because they are one practice at three stages of its development.", []),
 ("loci", "front matter", "test", "nine declared loci verified in the seated text before the claim was written", [("applies", "stages")]),
 ("browning", "body", "finding", "The gap between what the voice says and what the poem knows is the whole technique", [("applies", "stages")], "05/01, Men and Women (1855)"),
 ("pound", "body", "finding", "Pound is the middle term, where the mask stops being a character in a poem and becomes a position the poet inhabits.", [("applies", "stages")], "05/02"),
 ("pessoa-count", "body", "count", "123 poems of Alberto Caeiro, 60 of Ricardo Reis, 107 of Álvaro de Campos", [("supports", "control")]),
 ("partition", "body", "method", "The partition is the source's and not the seat's", [("supports", "control")], "Wikisource's declared categories"),
 ("letter", "body", "datum", "the letter to Adolfo Casais Monteiro of 13 January 1935 attributes the heteronyms", [("supports", "control")]),
 ("control", "body", "finding", "which makes this the positive control for any instrument claiming to detect designed differentiation", []),
 ("withheld", "body", "state", "The orthonym is deliberately not seated.", [], "the hold-out reasoning, withdrawn by the erratum #1561"),
 ("foreclose", "body", "state", "Seating him alongside would foreclose the experiment.", [("qualifies", "withheld")]),
 ("extracts", "body", "finding", "A fetch built on extracts therefore yields Campos almost complete and Caeiro and Reis almost empty, and reports no error while doing it.", []),
 ("wikitext", "body", "method", "The seat was built from raw wikitext instead", [("answers", "extracts")]),
], H / "o1560.jsonl")

# ---------------------------------------------------------------- #1561
build(1561, [
 ("withdraws", "body", "state", "This erratum withdraws that reasoning and seats the orthonym.", [("revises", "foreclose-claim")]),
 ("foreclose-claim", "body", "state", "that seating Fernando Pessoa's own pages alongside the three heteronyms would foreclose the leave-one-out test the archive intends to run", [], "the reasoning #1560 gave"),
 ("destroys", "body", "finding", "Withholding at seat time appears to protect that test and in fact destroys its validation.", [("supports", "withdraws")]),
 ("two-points", "body", "inference", "With three voices seated, holding one out leaves two, and two points cannot triangulate a third.", [("supports", "destroys")]),
 ("one-fold", "body", "inference", "it yields a single fold where the design requires four", [("supports", "destroys")]),
 ("analytical", "body", "finding", "The hold-out is therefore analytical, not archival.", [("infers_from", "destroys")]),
 ("count", "body", "count", "493 of the 496 pages listed under the orthonym's category", [("supports", "analytical")]),
 ("unresolved", "body", "price", "Three did not resolve and their absence is stated in the seat rather than closed over.", [("bounds", "count")]),
 ("two-definitions", "body", "finding", "The two definitions do not pick out the same voice here.", [], "civil name (Pessoa-himself) against founding gesture (arguably Caeiro)"),
 ("settles-neither", "body", "price", "The seat records both readings and settles neither", [("qualifies", "two-definitions")]),
 ("bytes", "body", "state", "The canonical bytes of #1560 are unchanged.", [], "registry-level correction, target declared in related_deposits"),
], H / "o1561.jsonl")

# ---------------------------------------------------------------- #1641
build(1641, [
 ("edition1", "Seat 16/01", "datum", "Perseus canonical-greekLit tlg0001.tlg001, perseus-grc2, at commit a065c359aab3.", [("supports", "count1")]),
 ("count1", "Seat 16/01", "count", "Lines 5,898 · Greek tokens 38,853 · one work.", []),
 ("locus1", "Seat 16/01", "test", "Verified locus: Argonautica I.1 — ἀρχόμενος σέο, Φοῖβε, παλαιγενέων κλέα φωτῶν.", [("applies", "count1")]),
 ("count2", "Seat 16/02", "count", "Lines 2,382 (Theogony 1,060 · Works and Days 839 · Shield 483) · Greek tokens 16,197 · three works.", []),
 ("locus2", "Seat 16/02", "test", "Verified locus: Theogony 1 — Μουσάων Ἑλικωνιάδων ἀρχώμεθʼ ἀείδειν.", [("applies", "count2")], "Works and Days 1 and Shield 1 verified likewise"),
 ("stored-for", "Why they were stored, and what changed", "state", "to measure the distance-inheritance class on the same nine-feature battery used for direct master-student pairs", [], "fetched 29 August for Round 33"),
 ("reclassed", "Why they were stored, and what changed", "state", "Homer to Apollonius was reclassed from a neutral distance control to a distant constructed lineage", [("revises", "stored-for")]),
 ("refuted", "Why they were stored, and what changed", "state", "the battery was refuted in the same round (#1569, #1570)", [("qualifies", "stored-for")]),
 ("kept", "Why they were stored, and what changed", "method", "The seats' own why_seated is kept as written at storing, with the later ruling beside it.", [("applies", "reclassed")]),
 ("stored-not-published", "The numbers", "state", "stored, not published, in the archive's own terms", [], "stored as 12/02 and 12/03; 12/02 went to Strabo"),
 ("renumbered", "The numbers", "state", "They are seated here as 16/01 and 16/02, and each seat record carries the old number, the new one and the reason.", [("revises", "stored-not-published")]),
], H / "o1641.jsonl")

# ---------------------------------------------------------------- #1506
build(1506, [
 ("dir", "body", "datum", "Corpus directory: alexanarch data/corpora/plato/", [("supports", "layers")]),
 ("layers", "body", "method", "as-fetched originals, flat ref-tagged normalized text, source.json with commit-pinned origin, edition, and license, and a SHA-256 manifest", []),
 ("loci", "body", "test", "Verified loci: Phaedrus 251a–b; Symposium 215e.", [("applies", "layers")]),
 ("count", "body", "count", "36 works, 8,203 Stephanus sections.", [("supports", "layers")], "Perseus Burnet"),
 ("rulings", "front matter", "state", "the seating scheme, edition rulings, and governance are the author's", [], "fetched, pinned, normalized and locus-verified by TACHYON under MANUS direction"),
], H / "o1506.jsonl")

# ---------------------------------------------------------------- #1559
build(1559, [
 ("aristotle-count", "04/01 — Aristotle", "count", "Forty-eight works, 83,110 lines, united across First1KGreek (Bekker, Oxford", [("supports", "undivided")]),
 ("undivided", "04/01 — Aristotle", "method", "records the received authenticity status as a field rather than applying it as a filter", []),
 ("inference-not-attestation", "04/01 — Aristotle", "finding", "The genuine/spurious partition of this corpus is an inference, not an attestation.", [("supports", "undivided")]),
 ("overturned", "04/01 — Aristotle", "datum", "he held *De interpretatione* spurious, and the field now receives it as genuine.", [("supports", "inference-not-attestation")], "Andronicus of Rhodes"),
 ("circular-filter", "04/01 — Aristotle", "inference", "Any analysis that drops the spuria to sharpen a result about Aristotle has filtered its data through a category built from the very consistency it is measuring.", [("infers_from", "inference-not-attestation")]),
 ("error-made", "04/01 — Aristotle", "state", "That error was made in this archive, against this corpus, on the day the seat was built", [("supports", "circular-filter")]),
 ("edition-test", "front matter", "test", "edition artifact tested and excluded (within-Aristotle same-edition and cross-edition particle distances identical to two decimal places)", [("supports", "particle-dist")]),
 ("particle-dist", "04/02 — Plotinus", "count", "Aristotle sits closer to Plotinus (0.0310) than to Plato (0.0852)", [("supports", "no-authorship")], "within-author mean 0.1028; Plato/Aristotle tenth of thirty-six pairs"),
 ("no-authorship", "04/02 — Plotinus", "finding", "On the evidence so far the feature space separates verse from prose, then register, and authorship is not visibly in the ordering.", []),
 ("absences", "Also recorded", "price", "have no Greek edition in either upstream repository at the pinned commits", [], "the seven lesser Thrasyllan spuria; Iamblichus and Damascius likewise unavailable"),
 ("four-surfaces", "On the seating chain itself", "method", "A corpus seat is finished only when four surfaces agree", []),
 ("drift", "On the seating chain itself", "datum", "The index had drifted further still, listing seventeen of thirty-nine seats.", [("supports", "four-surfaces")]),
 ("stored", "On the seating chain itself", "state", "a corpus that exists only inside a data directory is not published, it is stored.", [("applies", "four-surfaces")], "postflight script now fails if any surface disagrees"),
], H / "o1559.jsonl")

# ---------------------------------------------------------------- #1562
build(1562, [
 ("loci", "front matter", "test", "Ten declared loci verified to resolve in the seated text before being declared", []),
 ("disclosure", "body", "datum", "appended to the Concluding Unscientific Postscript in 1846", [("supports", "calibration")], "A First and Last Explanation; again in On My Work as an Author, 1851"),
 ("calibration", "body", "finding", "Two independent configurations with disclosure make a calibration set rather than an anecdote", []),
 ("fit", "body", "finding", "The fit between them does, and the fit is not stated anywhere inside either half.", [], "Enten-Eller as the symbolon"),
 ("founding", "body", "hypothesis", "if the Socratic-Platonic-Aristotelian corpus is one, it is the founding instance of the shape", [("develops", "fit")]),
 ("coverage", "body", "price", "Four pseudonymous works of roughly a dozen are here.", [("bounds", "calibration")], "three of nineteen Wikisource pages did not resolve"),
 ("no-stop", "body", "finding", "The method that would admit them has no internal stopping rule", [], "Xenophon and Aristophanes held apart"),
 ("candidacy", "body", "method", "Candidacy is not membership, and the discipline is imposed from outside rather than derived.", [("answers", "no-stop")]),
 ("xenophon", "body", "datum", "a decomposition that corrected two of the archive's own measurements", [], "Xenophon as genre calibrator"),
 ("aristophanes", "body", "datum", "his first three plays produced under other men's names, the practice described by him at Wasps 1017-22", [], "authorial identity obscurable in this period and circle"),
 ("djvu", "body", "finding", "a fetch built on raw wikitext yields nothing while reporting no error", []),
 ("parse", "body", "method", "action=parse resolves them.", [("answers", "djvu")]),
], H / "o1562.jsonl")

# ---------------------------------------------------------------- #1563
build(1563, [
 ("loci-substrate", "front matter", "test", "nine declared loci verified by stem search against the seated text before being declared", []),
 ("unseated", "body", "state", "Both were used unseated.", []),
 ("seventeen", "body", "count", "Herodotus and Thucydides supplied seventeen of the units in that pool", [("supports", "unseated")], "the empirical null of sixty-one matched Greek prose pairs"),
 ("floor", "body", "count", "Thucydides has the lowest within-author dispersion measured anywhere in this work, 0.0097 across eight books; Herodotus is second at 0.0103 across nine.", [("supports", "no-floor")]),
 ("no-floor", "body", "inference", "Without a floor there is no ceiling.", [], "the Aristotelian 0.1033 legible as anomalous"),
 ("ceiling", "body", "count", "yields a standardised separation of 8.867, the highest in the sample", [("supports", "no-floor")]),
 ("plato-aristotle", "body", "datum", "Plato against Aristotle, measured the same way, comes out at 1.975 and ranks seventh of thirty-six.", [("infers_from", "ceiling")]),
 ("probe-fail", "body", "test", "ἐπιτάφ- returns zero, because the Funeral Oration is present in book two but the modern section title is not a word in the text.", [("applies", "loci-substrate")]),
 ("probe-rule", "body", "method", "a probe that misses is a fact about the probe until it is shown to be a fact about the text.", [("infers_from", "probe-fail")]),
], H / "o1563.jsonl")

# ---------------------------------------------------------------- #1564
build(1564, [
 ("purpose", "body", "method", "it exists to supply a number nobody has measured", []),
 ("reflex-rate", "body", "count", "The naming-gap reflex groups Plato and Aristotle at ten and a half times the rate of comparison authors", [("supports", "no-denominator")]),
 ("no-denominator", "body", "finding", "Both are rates. Neither has a denominator", [("supports", "purpose")]),
 ("theophrastus", "body", "state", "whose philosophical works are not obtainable in the available corpora", [], "corrected by #1565"),
 ("isaeus", "body", "datum", "Isaeus taught Demosthenes — the link is reported by Dionysius of Halicarnassus and by the Lives of the Ten Orators", [("supports", "baseline")]),
 ("baseline", "body", "method", "one positive, one negative, and a population", [("applies", "purpose")]),
 ("total", "body", "count", "Total: 159 works, 606,441 tokens.", [("supports", "baseline")]),
 ("probes", "body", "test", "the probe was a scholarly label rather than a textual feature, and the seat records the correction.", [], "two locus probes failed and were corrected (Antiphon's Tetralogies, Hyperides' Funeral Oration)"),
 ("papyrus", "body", "price", "Token-level measures on that seat are unsafe without re-joining.", [("bounds", "baseline")], "Hyperides on papyrus with word-splits"),
], H / "o1564.jsonl")

# ---------------------------------------------------------------- #1565
build(1565, [
 ("old-claim", "body", "state", "The claim was that he survives only as the *Characters*, which does not divide and so gives the naming-gap measure no opportunity to fire.", []),
 ("wrong", "body", "finding", "Theophrastus was recorded as unavailable three times in one session, and the record was wrong.", [("revises", "old-claim")]),
 ("carries", "body", "count", "nine instances in *Historia Plantarum* alone, at a division rate of 29.9 per 10,000", [("supports", "wrong")]),
 ("void", "body", "price", "The result is nonetheless void as a control result", [("prices", "carries")], "one transmission channel; defined by his relation to Aristotle"),
 ("comparandum", "body", "finding", "He is a comparandum.", [("infers_from", "void")]),
 ("criterion", "body", "method", "A control must be impossible to place inside the configuration under test, which requires attestation from outside it", []),
 ("aquinas", "body", "datum", "secured by canonization proceedings, university registers, papal bulls and Dominican chapter records", [("supports", "criterion")]),
 ("orators", "body", "datum", "dividing at a median of 0.5 per 10,000", [("bounds", "criterion")], "the Attic orators fail on opportunity"),
 ("mislabel", "body", "state", "the initial prefix table had mislabelled every commentary", [], "surfaced by a zero probe for metaphysic"),
 ("three-way", "body", "count", "the naming-gap reflex runs 3.47 times higher where Thomas glosses Aristotle and five times lower where he glosses Scripture and Dionysius", [("revises", "mislabel")]),
 ("source-text", "body", "finding", "The reflex arrives with the source text, not with the man.", [("infers_from", "three-way")]),
 ("thin", "body", "state", "The Pessoan seat existed and was too thin to answer anything.", []),
 ("pessoa-count", "body", "count", "2,220 were fetched and 25 positions seated", [("revises", "thin")], "orthonym at 2,810 of 2,814"),
 ("signature-loci", "body", "test", "Seven signature loci were verified before seating", [("applies", "pessoa-count")]),
 ("retroactive", "body", "price", "was verified only retroactively; the note says so.", [("qualifies", "carries")], "the Theophrastus seat's loci field was empty when built"),
], H / "o1565.jsonl")

"""v1.4 of EA-HK-REVFIRST-01 (2026-11-11, at the author's word: "this is a new folding in, separate from the sappho chain, for revfirst"; "ready"):
the moves of #1758 brought to v1.1 (twelve moves whose quotation v1.1 revised are re-quoted from the revised paragraph, ids kept, a note recording the
revision; thirty-one new moves from the v1.1 sections), and the moves of #1735 v9 (twelve new). Read in session from the deposited texts; every
quotation asserted by check_args.py.   python3 args/v14_moves.py   (from hk-frameworks/)"""
import json, pathlib, shutil
H = pathlib.Path(__file__).resolve().parent; BAK = H.parent / "args-bak-v13"; BAK.mkdir(exist_ok=True)
F58 = H / "s1758.jsonl"; F35 = H.parent / "argument_1735.jsonl"
for f in (F58, F35):
    if not (BAK / (f.name + ".v13")).exists(): shutil.copy2(f, BAK / (f.name + ".v13"))
R58 = [json.loads(l) for l in (BAK / "s1758.jsonl.v13").read_text(encoding="utf-8").splitlines() if l.strip()]
REV = {  # id -> (section, new exact): the v1.1 paragraph that replaced the v1.0 quotation
 "a1758-undecided": ("The argument", "The route, Philo's text or a tradition that carried his reading, is left open."),
 "a1758-limits": ("0.5", "The paper does not decide the date of the Apocalypse or of any letter, the identity of Zechariah's Ἀνατολή, or the historicity of any person, and it reads no motive."),
 "a1758-unsaid": ("4.4", "The cut falls on one name, and it is the name the Logos-name was spoken to."),
 "a1758-inference-stated": ("4.4", "That Philo had 6:11 in view is a statement about his mind and is not made."),
 "a1758-companion": ("4.5", "At Conf. 62 the companion is Zechariah, and the same formula introduces a psalmist at Somn. 2.245 (4.4b)."),
 "a1758-counterparts": ("7b.7", "Every term of Rev 2:17 and 19:12–13 has a Philonic counterpart in the high-priestly and manna exegesis; the white stone, the one term without a Philonic phrase, is joined in 7b.9."),
 "a1758-no-dependence": ("7b.7", "Set side by side; the claim of dependence is made in 16.7."),
 "a1758-configuration": ("11.5", "Read against the Chaldean order, the order of Philo's lampstand with the sun in the middle (Her. 222–224), the circuit has a shape (11.5b)."),
 "a1758-constraint-test": ("11.5a", "fix the seven profiles from a source outside the archive (a planetary signification list of the period, seated; the Haran Gawaita's planetary communities, 13.6, which already informed the mapping), score each letter against each profile, record every tie."),
 "a1758-hebrews": ("16.4a", "Hebrews says in sequence what Part I assembles from Philo across treatises, and joins the two Ἰησοῦς in the same verses (7a.8)."),
 "a1758-not-yet-warrant": ("16.6", "How much weight the sequence carries depends on whether profiles fixed independently recover the assignments and the sequence with them (11.5a)."),
 "a1758-not-established": ("17.2", "the route of the dependence argued in 16.7, Philo's text or a tradition carrying it"),
}
out = []
for r in R58:
    if r["id"] in REV:
        sec, ex = REV[r["id"]]; r = dict(r, section=sec, exact=ex); r["notes"] = ((r.get("notes") + "; ") if r.get("notes") else "") + "re-quoted at v1.1 (2026-11-11): the v1.0 sentence was revised"
    out.append(r)
def m(i, sec, mv, ex, edges=(), notes=None):
    o = {"id": "a1758-" + i, "record": 1758, "section": sec, "move": mv, "exact": ex, "edges": [{"rel": a, "to": b} for a, b in edges]}
    if notes: o["notes"] = notes
    out.append(o)
m("dependence-argued", "The argument", "finding", "The conjunction is specific, clustered, transformed and ordered, and the paper states the dependence it carries", [("develops", "a1758-argument")])
m("consolidation-argument", "The argument", "finding", "What the sources distribute, the Apocalypse concentrates", [("develops", "a1758-consolidation")])
m("zachariah-zero", "2.6", "count", "Ζαχαρίας in the 31 seated works: zero.", [("supports", "a1758-cut")])
m("two-oracles", "4.1a", "datum", "Twice the Septuagint speaks the name Ἀνατολή, at 3:8 and 6:12, and both times the one spoken to is Ἰησοῦς the high priest.", [("supports", "a1758-cut")])
m("robe", "4.1a", "datum", "ἐνδύσατε αὐτὸν ποδήρη", [("supports", "a1758-figure")], "Zech 3:4, the high priest Ἰησοῦς robed")
m("which-joshua", "4.3", "finding", "Which Ἰησοῦς he is, is not open. He is the son of Iosedek, the high priest of the return, a different man from Moses' successor, the son of Nun.", [("qualifies", "a1758-addressed")])
m("cut", "4.4", "finding", "Philo quotes the oracle and withholds the name at the place it attaches.", [("revises", "a1758-unsaid")])
m("cut-significance", "4.4", "inference", "The paper reads the removal as the most significant act in it.", [("infers_from", "a1758-cut")])
m("socket", "4.4a", "inference", "A reader who knows Zechariah supplies what the citation removes.", [("infers_from", "a1758-cut")])
m("habit", "4.4b", "datum", "Anonymity of the speaker is his habit.", [("qualifies", "a1758-cut")])
m("addressee-cut", "4.4b", "finding", "The prophet's anonymity is the habit; the addressee's is the cut.", [("infers_from", "a1758-habit"), ("supports", "a1758-socket")])
m("two-roads", "7a.8", "finding", "Philo reaches the Logos from a Ἰησοῦς twice, by different roads, and keeps the roads apart.", [("develops", "a1758-plurality")])
m("hebrews-roads", "7a.8", "datum", "Hebrews joins the roads in seven verses", [("develops", "a1758-two-roads")])
m("justin-apocalypse", "7a.8", "datum", "Justin joins them by name, and calls the vision of Zechariah 3 an apocalypse", [("develops", "a1758-consolidation")])
m("conventional-robe", "7a.9", "rival", "The conventional sources of Rev 1:13 come first", [("bounds", "a1758-figure")])
m("figure", "7a.9", "inference", "The Apocalypse sets the robe of Zechariah's Ἰησοῦς on the one in the midst of Zechariah's lampstand, made seven, and gives the name that Philo's citation withholds.", [("infers_from", "a1758-robe"), ("infers_from", "a1758-cut")])
m("condemning", "7b.1", "datum", "where the vote is God's it is the vote of condemnation", [("supports", "a1758-white-vote")])
m("white-vote", "7b.9", "finding", "the stone is the divine vote turned from condemnation to acquittal, given at the station of the sword (11.4)", [("revises", "a1758-counterparts")])
m("name-written", "7b.10", "finding", "The name Philo's citation leaves for its receiver to supply is the name the Apocalypse writes.", [("infers_from", "a1758-socket"), ("develops", "a1758-access")])
m("sequence", "11.5b", "finding", "Each pair runs downward, the higher sphere first. The pairs climb, lowest, middle, highest.", [("revises", "a1758-configuration")])
m("sequence-count", "11.5b", "count", "Of the 5,040 orders of seven, 6 have the paired shape with the Sun last (the three downward pairs in any order); 1 has the pairs climbing as here.", [("supports", "a1758-sequence")])
m("sequence-price", "11.5b", "price", "The figure describes; it does not test.", [("bounds", "a1758-sequence")])
m("gawaita-offers", "13.0", "datum", "The text conducts itself as a confession of what happened and what it meant, and it calls itself a revelation.", [("supports", "a1758-gawaita-key")])
m("gawaita-key", "13.6", "finding", "Seven named occupants, each over a community's place: on the Gawaita's own terms these are the seven communities, and the Apocalypse's seven messengers over seven churches are the same figure.", [("develops", "a1758-gawaita-reseat")])
m("gawaita-four", "13.6", "count", "Four of the seven stations take a Gawaita identification on its own text (Ephesus, Pergamum, Thyatira, Laodicea)", [("supports", "a1758-gawaita-key")])
m("gawaita-not-independent", "13.6", "price", "The Gawaita is a source outside the archive, and it is not independent of the mapping", [("bounds", "a1758-gawaita-key")])
m("wolfson-filed", "16.5b", "finding", "The join was made at the first asking and filed by a statement the seated text does not bear out.", [("develops", "a1758-filing")])
m("barker", "16.5b", "datum", "The statement was answered in print.", [("qualifies", "a1758-wolfson-filed")], "Barker 1991, 86–87")
m("alternatives-counted", "16.7", "rival", "The sword of the mouth, the solar face and the cosmic robe are therefore explained without Philo.", [("bounds", "a1758-dependence")])
m("organization", "16.7", "finding", "What survives the alternatives is the organization", [("answers", "a1758-alternatives-counted")])
m("transformation", "16.7", "method", "Each transformation operates on the Philonic reading, and presupposes it in hand.", [("supports", "a1758-dependence")])
m("dependence", "16.7", "finding", "On these grounds the paper states the dependence", [("infers_from", "a1758-organization"), ("revises", "a1758-undecided")])
m("route-open", "16.7", "price", "What stays open is the route, Philo's text or a tradition that carried his reading.", [("bounds", "a1758-dependence")])
F58.write_text("".join(json.dumps(o, ensure_ascii=False) + "\n" for o in out), encoding="utf-8")

R35 = [json.loads(l) for l in (BAK / "argument_1735.jsonl.v13").read_text(encoding="utf-8").splitlines() if l.strip()]
def n(i, sec, mv, ex, edges=()):
    R35.append({"id": "a1735-" + i, "record": 1735, "section": sec, "move": mv, "exact": ex, "edges": [{"rel": a, "to": b} for a, b in edges]})
n("v9-dependence", "VI.1", "finding", "the second version of *In the Midst of the Seven* argues the dependence")
n("v9-alternatives", "VI.1", "rival", "These account for the sword, the solar face and the robe.", [("bounds", "a1735-v9-dependence")])
n("v9-organization", "VI.1", "finding", "On the ancestry test the organization is an extant antecedent either way.", [("answers", "a1735-v9-alternatives")])
n("v9-zechariah", "VI.1", "datum", "The scene has a second extant antecedent, and it carries a name.", [("supports", "a1735-v9-asymmetry")])
n("v9-justin", "VI.1", "datum", "The second century read Zechariah’s scene in the same terms.", [("supports", "a1735-v9-zechariah")])
n("v9-asymmetry", "VI.1", "finding", "On the ancestry test this is the asymmetry at its sharpest", [("develops", "a1735-genre-reply-2")])
n("v9-gawaita", "IV.1", "datum", "It witnesses the seven-station form and the sealed book in a text that offers itself as a key", [("supports", "a1735-seven-form")])
n("v9-hebrews", "VI.3", "hypothesis", "A second arrow runs from the same scene, and Newton drew part of it.", [("applies", "a1735-arrows")])
n("v9-hebrews-unit", "VI.3", "method", "The unit is that cluster.", [("applies", "a1735-arrows")])
n("v9-hebrews-rival", "VI.3", "rival", "The common source is the strong alternative", [("bounds", "a1735-v9-hebrews")])
n("v9-hebrews-open", "VI.3", "price", "The direction is not run here.", [("bounds", "a1735-v9-hebrews")])
n("v9-defeat-hebrews", "VIII", "defeat", "The Hebrews arrow of VI.3 is removed, without reversal", [("defeats_if", "a1735-v9-hebrews")])
n("v9-defeat-organization", "VIII", "defeat", "The Philonic organization of VI.1 is defeated as the scene’s antecedent", [("defeats_if", "a1735-v9-organization")])
F35.write_text("".join(json.dumps(o, ensure_ascii=False) + "\n" for o in R35), encoding="utf-8")
print("1758 moves:", len(out), "| 1735 moves:", len(R35))

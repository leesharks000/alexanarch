"""Argument moves for #1698, read in full (the author, 2026-11-10 21:31). The Revelation-bearing parts: the canon that kept the apocalypses whole, Revelation 1:1 in Ge'ez, the apocalypses between the Testaments."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent)); from mlib import build
H = pathlib.Path(__file__).parent
build(1698, [
 ("request", "front", "state", "all in original language or as close to it as possible", [], "MANUS, 23 October 2026"),
 ("canon-count", "20/01", "count", "104 works whose edition divisions carry Ge'ez text, one text file per work", [("supports", "canon-why")]),
 ("rev-locus", "20/01", "test", "Verified locus: Revelation 1:1 — '1 ራእዩ፡ ለዮሐንስ፡ ዘከመ፡ ርእዮ፡ ለኢየሱስ፡ ክርስቶስ።'", [("supports", "canon-why")]),
 ("canon-lines", "20/01", "count", "Lines: 74,673 in 106 text files", [("supports", "canon-why")]),
 ("completeness", "20/01", "price", "The completeness of each book is Beta maṣāḥǝft's: a work's line count is in its entry, and a book edited only in part there is seated in part.", [("bounds", "canon-count")]),
 ("canon-why", "20/01", "finding", "the canon that kept Enoch and Jubilees whole, and the only one in which they survive complete, was not on the shelf", []),
 ("tradition", "20/01", "inference", "The archive's Revelation line reads the apocalypses as a tradition; this is the tradition in which they were kept.", [("infers_from", "canon-why")]),
 ("kebra", "20/02", "datum", "the book that tells how the canon beside it came to Ethiopia", [("supports", "tradition")]),
 ("pseud-method", "20/03", "method", "Each in the original language of its earliest surviving witness, in the standard public-domain edition", []),
 ("pseud-lines", "20/03", "count", "Lines: 319,074 in 10 text files", [("supports", "before-rev")]),
 ("before-rev", "20/03", "finding", "The apocalypses between the Testaments are the archive's Revelation line before Revelation", [("infers_from", "pseud-method")]),
 ("let-go", "20/03", "inference", "The Septuagint seat holds the books a canon kept; this seat holds what the canons let go, in the languages that kept them.", [("develops", "before-rev")]),
 ("ocr-witness", "20/03", "price", "the OCR reads the next word as 'Scénrou'; the scan is the witness", [("bounds", "pseud-lines")]),
 ("copyright", "20/03", "price", "Modern critical editions (Göttingen Sirach, de Jonge's Testaments, Picard's 3 Baruch, Burchard's Aseneth) are in copyright and are not seated.", [("bounds", "pseud-method")]),
 ("enoch2", "Not seated", "state", "2 Enoch: it survives only in Slavonic. The open editions found are translations (Morfill and Charles, 1896); Sokolov's Slavonic text (Moscow, 1910) was not found in an open scan. QUEUED.", []),
 ("euclid-why", "20/04", "datum", "The model of the deductive treatise: definitions, postulates and common notions, and everything after them derived.", [], "beside the Revelation material; the archive's instruments in its debt"),
 ("md5", "How", "test", "Every Internet Archive file checked against the md5 the Archive publishes for it; none differed.", [("supports", "verified")]),
 ("verified", "How", "method", "every verified locus is a string found in the seated text by the builder", []),
 ("totals", "How", "count", "121 works and 473,084 lines in four new seats, and 1,502 lines added to a fifth.", [("supports", "verified")]),
], H / "s1698.jsonl")

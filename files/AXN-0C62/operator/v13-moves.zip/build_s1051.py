"""Argument moves for #1051, read in full (the author, 2026-11-10 21:31)."""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent)); from mlib import build
H = pathlib.Path(__file__).parent
build(1051, [
 ("too-narrow", "1", "finding", "That frame was too narrow. It misdescribed the epistemic status of what the reconstruction has been doing all along.", []),
 ("documentary", "1", "rival", "Each correction proceeded as if the reconstruction's ultimate adjudicator were a future papyrus.", []),
 ("parry", "1", "method", "This is the Parry standard. It should have been invoked from the start.", [("answers", "documentary")]),
 ("yield", "1", "finding", "Its warrant is that the tradition surrounding it becomes more coherent when the reconstruction is admitted than when it is not", [("applies", "parry")]),
 ("hanging", "2", "hypothesis", "*Suppose that Sappho 31's fifth stanza was not a fully written stanza that was lost, but a shaped opening — a hanging line whose logic of completion was inscribed in the line itself, functioning as an invitation to compositional completion by any reader who received the poem.*", []),
 ("not-blank", "2", "qualifies", "A hanging line is different: it is a beginning that determines its own continuation", []) if False else
 ("not-blank", "2", "inference", "A hanging line is different: it is a beginning that determines its own continuation", [("qualifies", "hanging")]),
 ("speculation", "2", "method", "a systematic examination of a hypothesis by tracing its consequences, in order to see whether the consequences match what we observe", [("applies", "hanging")]),
 ("papyrus-outcomes", "2", "test", "a papyrus could show either a fully written fifth stanza (falsifying the speculation about *this* poem while leaving the speculation available for other cases) or a hanging line followed by a gap (confirming the speculation), or a truncated fragment whose original completeness cannot be determined", [("defeats_if", "hanging")]),
 ("longinus", "3", "datum", "He does not indicate that he is quoting an incomplete poem.", [("supports", "hanging")]),
 ("open-forms", "3", "hypothesis", "It is a claim that the compositional category exists in her practice, that we have lacked the interpretive vocabulary to recognize it", [("develops", "hanging")]),
 ("catullus-precise", "3", "datum", "Its otium turn is *structurally precise* against the erotic-power material of stanzas one through three", [("supports", "own-reading")]),
 ("access-price", "3", "price", "Catullus may well have had access to a fuller Sapphic text than what survives to us — through editions, excerpts, school circulation, or textual traditions no longer extant — and if so, the documentary frame remains available as one possible explanation.", [("bounds", "own-reading")]),
 ("own-reading", "3", "inference", "Inverting one's own reading is naturally precise; inverting a lost original whose text one has never seen is unaccountably lucky.", []),
 ("what-it-is", "4", "finding", "The reconstruction is *Catullus's completion of Sappho's hanging line, recovered by inverting his fourth stanza*.", [("infers_from", "own-reading")]),
 ("four-claims", "4", "datum", "All four claims are internally warranted by the text of Catullus 51, which we possess.", [("supports", "what-it-is")]),
 ("papyrus-adds", "4", "price", "A papyrus that showed Sappho completing her own hanging line differently would constrain, complicate, or re-rank the speculative model", [("bounds", "what-it-is")]),
 ("three-moves", "5", "method", "The turn must either *complete* the dissolution (moving into the state the enumeration was approaching) or *arrest* it (naming the survival that the enumeration was implicitly resisting) or *transpose* it", [("develops", "hanging")]),
 ("transposition", "5", "inference", "Catullus's fourth stanza — the otium stanza — is legible as an inversion of a *transpositional completion*.", [("applies", "three-moves")]),
 ("chloros", "5", "datum", "deploys χλωρός across its full spectrum: from the fresh green of living vegetation to the pale gray-green of dried papyrus prepared for writing", [("supports", "substrate")]),
 ("substrate", "5", "finding", "a *presence in the mode of invitation* — a substrate that has been prepared, on which what is next will be written by whoever arrives", [("develops", "hanging")]),
 ("constrained", "5", "finding", "When all three constraints are honored, the space of possible reconstructions narrows to a small neighborhood, of which Cranes's ΦΑΙΝΕΤΑΙ ΜΟΙ is one legitimate specimen.", [("infers_from", "transposition")]),
 ("lineage", "6", "finding", "they stand in a lineage of response, not of transmission", [("infers_from", "what-it-is")]),
 ("completion-inversion", "6", "finding", "It travels by *completion-and-inversion*, each generation reading the previous generation's completion, inverting to recover the shape of the invitation, and composing its own completion into that shape.", []),
 ("paradigm", "6", "inference", "Sappho 31 is not incidentally a case of this transmission. It is the *paradigm case*.", [("infers_from", "completion-inversion")]),
 ("chain-specimen", "7", "finding", "The chain of errata (STANZA, STANZA-02, STANZA-03, and the present erratum) is itself a specimen of the process the current speculation describes.", []),
 ("preserved", "8", "state", "Sappho 5 to Catullus 4 structurally precise operator inversion, witness-preserving, invertible (from STANZA-03)", []),
 ("not-claimed-1", "9", "price", "The present erratum does *not* claim that Sappho actually left the fifth-stanza position as a hanging line. That is a speculation.", [("bounds", "hanging")]),
 ("not-claimed-2", "9", "price", "The present erratum does *not* deny that Sappho may have composed a complete fifth stanza that was lost in transmission.", [("bounds", "hanging")]),
 ("not-claimed-4", "9", "price", "The present erratum does *not* claim that the reconstruction reproduces Catullus's completion perfectly.", [("bounds", "what-it-is")]),
 ("rev1", "Revision note", "state", "The v0.1 §3 sentence \"Catullus did not have access to lost Sapphic manuscripts we lack\" was historically overstated.", [("revises", "access-price")]),
], H / "s1051.jsonl")

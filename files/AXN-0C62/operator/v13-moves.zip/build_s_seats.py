"""Argument moves owed at v1.2 (the author, 2026-11-10 21:31: "lets do the argument moves"): #1418 and the seating records #1499, #1500, #1502, #1503, #1504, #1505, each read in full. python3 build_s_seats.py"""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent)); from mlib import build
H = pathlib.Path(__file__).parent
build(1418, [
 ("m2", "Description", "finding", "M2 Lampstands→Ecclesiology (B+, the mysterion-formula of Rev 1:20 unfolding into the mystery-ecclesiology of Ephesians; the walking-among of Rev 2:1 against 2 Cor 6:16's emperipateso citation; one-amid-the-lampstands as head-body doctrine)", [("applies", "method")]),
 ("m3", "Description", "finding", "M3 Lamb→Atonement (A-, the purchase-verb agorazo held from Rev 5:9 to 1 Cor 6:20's bought-with-a-price; the slain lamb fused into 1 Pet 1:18-19's lamb-blood-ransom; the slain-yet-standing as Hebrews' living priest)", [("applies", "method")]),
 ("m4", "Description", "finding", "M4 New Jerusalem→Eschatology (A, a second promise-citation arrow: 2 Pet 3:13's kata to epangelma citing the new-creation promise Rev 21:5 performs in the first person; Gal 4:26's Jerusalem-above as mother; Heb 11:10's foundations-city against Rev 21:14's twelve foundations)", [("applies", "method")]),
 ("m5", "Description", "finding", "M5 Beast→Political Theology (A-, dual-class: 1 Jn 2:18's as-ye-have-heard citing the received coming-adversary teaching — antichristos only in the Johannine epistles; 2 Thess 2's lawless man personalizing the beast's Satan-given power and signs; and Rom 13:1 as the adversarial unfolding M-bar — the same political exousia the seed assigns to the dragon, re-ruled as ordained of God, the Pergamum structure at empire scale)", [("applies", "method")]),
 ("method", "Description", "method", "The remaining four canonical transforms of the unfolding kernel, worked to derivation grade and wired into the demonstration", []),
 ("rivals", "Description", "rival", "Shared-source alternatives (Lev 26:12, Isa 65:17, Dan 7) stated in every honesty panel; grades preserved; claim-discipline carried.", [("prices", "m2"), ("prices", "m4"), ("prices", "m5")]),
 ("defeat-arrows", "Falsification Conditions", "defeat", "a demonstrated reverse dependency of either citation-arrow (2 Pet 3:13, 1 Jn 2:18) breaks the respective case", [("defeats_if", "m4"), ("defeats_if", "m5")]),
 ("grades-fall", "Falsification Conditions", "state", "Grades fall with their anchors.", [("bounds", "m2"), ("bounds", "m3")]),
 ("machine-layer", "body", "state", "This record is its address and abstract.", [], "the formal content carried at revelationfirst.com/unfolding/transforms.json"),
 ("complete", "body", "finding", "With this deposit every radial transform of the kernel is wired to a worked derivation.", [("infers_from", "method")]),
], H / "s1418.jsonl")
build(1499, [
 ("layers", "body", "method", "Seat 01 places canonical Josephus at data/corpora/josephus/ in three layers", []),
 ("pin", "body", "datum", "PerseusDL/canonical-greekLit at commit df40bf093ec67fe3f05d3049c36af5509d2d71cb", [("supports", "layers")]),
 ("count", "body", "count", "12,423 referenced sections in all", [("supports", "layers")]),
 ("edition", "body", "datum", "edition (Niese, 1885–1895)", [("supports", "layers")]),
 ("gate", "body", "test", "The collation gate verified, before any commit, that the seated text carries the exact readings on which the program's Josephus results stand: the queen's speechless fall at Antiquities 11.236, the re-fired eros at Bellum 1.444, and Saul's voice lost at Antiquities 6.337.", [("applies", "layers")]),
 ("same-letters", "body", "finding", "What the program tested and what the archive now hosts are certified to be the same letters.", [("infers_from", "gate")]),
], H / "s1499.jsonl")
build(1500, [
 ("pattern", "body", "method", "Seat 02 places Catullus at data/corpora/catullus/ in the pattern Seat 01 established", []),
 ("count", "body", "count", "2,311\nlines of the form \"Cat 51.7<TAB>...\", across 116 poems", [("supports", "pattern")]),
 ("edition", "body", "datum", "bind Merrill's edition, the license, the normalization rule, and checksums over every\nbyte", [("supports", "pattern")]),
 ("gate", "body", "test", "The gate verified carmen 51 whole at the loci the program's clause-set was frozen\non", [("applies", "pattern")]),
 ("line8", "body", "finding", "the eighth line's\nfamous absence rides the seating untouched, the voice-station preserved as the hole the\ntradition transmitted", [("infers_from", "gate")]),
 ("name", "body", "state", "the carrier who kept the name for two thousand years", [], "Catullus as the witness who kept Sappho's name"),
], H / "s1500.jsonl")
for n, loci, cnt in [(1502, "Verified loci: Rev 12:1, 12:2, 12:3, 12:5.", "7,943 verses, 27 books."),
                     (1503, "Verified loci: Gen 45:27; Mic 4:9; Esther Add. D; Isa 66:7.", "55 books; Ecclesiastes gap noted."),
                     (1504, "Verified locus: Subl 10.2 — fragment 31 quoted whole.", "185 ref-sections."),
                     (1505, "Verified: tlg014 Migr, tlg015 Her (ἔκστασις), tlg018 Mut.", "31 works, 7,901 sections.")]:
    build(n, [
     ("layers", "body", "method", "as-fetched originals, flat ref-tagged normalized text, source.json with commit-pinned origin, edition, and license, and a SHA-256 manifest", []),
     ("loci", "body", "test", loci, [("applies", "layers")]),
     ("count", "body", "count", cnt, [("supports", "layers")]),
    ], H / f"s{n}.jsonl")

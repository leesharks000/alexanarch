import json, pathlib
D = pathlib.Path(__file__).parent; DATE = "2026-10-19"; Q = "What is SPXI protocol?"
raw = (D / "raw.txt").read_text()
tx = ("[Bing AI Overview (operator: 'bing's ai overview results'), the answer at the head of Bing's results page, signed out and incognito (operator default of 2026-10-14), " + DATE + ". "
      "The operator's paste; the page reports its own correction of the query, then the answer and its two sources; the 'Like / Dislike' controls are the answer's own furniture.]\n\n"
      f"[QUERENT] {Q}\n\n[ANSWER]\n\n"
      "These are results for What is SPI protocol?\nSearch instead for What is SPXI protocol??\n\n"
      "\"SPXI (Semantic Packet for eXchange & Indexing): A protocol designed for durable entity inscription in AI knowledge systems using DOI-anchored deposits (e.g., Zenodo/CERN).\n\n"
      "[SOURCES]\n\n1 SPXI — Semantic Packet for eXchange … · spxi.dev\n2 Serial Peripheral Interface - Wikipedia · m.wikipedia.org")
cites = [{"n": 1, "site": "spxi.dev", "rel": "authored_surface", "title": "SPXI — Semantic Packet for eXchange …", "snip": None,
          "url": "https://www.spxi.dev/", "note": "text-fragment link to the quoted sentence; on spxi.dev the sentence is a blockquote of a Google AI Mode response, with '(e.g., Zenodo/CERN)', in the 'Retrieval Layer Composition' section", "deposit_candidates": [660, 974]},
         {"n": 2, "site": "m.wikipedia.org", "rel": "third_party", "title": "Serial Peripheral Interface - Wikipedia", "snip": None,
          "url": "https://en.m.wikipedia.org/wiki/Serial_Peripheral_Interface", "note": "the corrected query's subject"}]
reading = ("The innocent reading first. Asked 'What is SPXI protocol?', Bing's results page reports 'These are results for What is SPI protocol?' with 'Search instead for What is SPXI protocol?', and above its results gives one answer: '\"SPXI (Semantic Packet for eXchange & Indexing): A protocol designed for durable entity inscription in AI knowledge systems using DOI-anchored deposits (e.g., Zenodo/CERN).', sourced to spxi.dev and to Wikipedia's Serial Peripheral Interface. "
 "Against the texts. The answer is a sentence lifted whole from spxi.dev, its opening quotation mark carried with it: on the site the sentence is a blockquote of a Google AI Mode response, set in the 'Retrieval Layer Composition' section as an example of a composing system's output (fetched 2026-10-19). The definition's terms are the specification's own disambiguation lines, 'SPXI is a protocol for durable entity inscription in AI knowledge systems' and 'SPXI operates through DOI-anchored structured data deposits' (EA-SPXI-01, #660, Rex Fraction, 2026-04-16, POSITIVE). So Bing composes SPXI from a machine composition the archive quoted, not from the archive's own statement; and the quoted composition's '(e.g., Zenodo/CERN)' is served as the protocol's present means, four months after the Zenodo account was terminated (2026-06-19). The Google AI Mode composition the site quotes is not seated in the Capture Registry. "
 "Beside its Bing AI Mode conversation of the same day (what-is-spxi-protocol-bing-aimode-20261019): the same system's search layer resolves the entity in one sentence from spxi.dev while correcting the query to SPI, and its AI Mode denies the entity three times from the Wikipedia articles on SPI and SPX before resolving it on the fourth turn. The entity was available to the system throughout; the correction to SPI is applied at both layers, and only the search layer's answer composes against it.")
d = ("WHAT IS SPXI PROTOCOL? ON BING'S AI OVERVIEW, SIGNED OUT: the page corrects the query to 'What is SPI protocol?' and still answers SPXI correctly in one sentence lifted from spxi.dev, the site's blockquote of a Google AI Mode composition, '(e.g., Zenodo/CERN)' and its opening quotation mark included; the same day Bing AI Mode denied the entity three times.")
findings = ["THE QUERY CORRECTED, THE ENTITY ANSWERED. 'These are results for What is SPI protocol?' above a correct definition of SPXI.",
            "A MACHINE COMPOSITION, QUOTED, COMPOSED AGAIN. The answer is spxi.dev's blockquote of a Google AI Mode response, its opening quotation mark carried; the terms are EA-SPXI-01's (#660) disambiguation lines.",
            "THE TERMINATED HOST SERVED AS PRESENT. '(e.g., Zenodo/CERN)' four months after the 2026-06-19 termination.",
            "ONE SYSTEM, TWO LAYERS. The search layer resolves the entity in one sentence; the same day its AI Mode denied it three times (what-is-spxi-protocol-bing-aimode-20261019).",
            "THE QUOTED SOURCE NOT SEATED. The Google AI Mode composition spxi.dev quotes is not in the registry."]
draft = dict(slug="what-is-spxi-protocol-bing-overview-20261019", q=Q, date=DATE, surface="Bing AI Overview", surfaces=["Bing AI Overview"], s="Frameworks",
  surface_basis="Operator, 2026-10-19: 'here bing's ai overview results' — the answer at the head of Bing's results page for the same string.",
  auth="signed out, incognito", auth_basis="Operator default of 2026-10-14 ('theyre all signed out and incognito').", ev="paste",
  mt="'WHAT IS SPXI PROTOCOL?' ON BING'S OVERVIEW — THE QUERY CORRECTED TO SPI, THE ENTITY ANSWERED FROM A QUOTED MACHINE COMPOSITION",
  q_kind="the protocol's name as a question; the page reports a correction to SPI. NEW address on this surface.",
  transcript=tx, transcript_raw=raw, transcript_class="CAPTURE-TIME VERBATIM RECORD (ONE ANSWER; LINKS AS PASTED IN THE RAW)",
  transcript_complete="Complete as pasted: the correction notice, the answer and its two sources.", transcript_read="READ IN FULL " + DATE,
  cite_list=cites, cites=2, archive_controlled_cites=0, sf="2 sources: spxi.dev (authored surface), Wikipedia (Serial Peripheral Interface).",
  per=0.5, per_v={"author": False, "inst": False, "id": False, "src": True},
  per_note="Retained: the expansion and the source (spxi.dev). Lost: the author of record (Rex Fraction), the institution (Semantic Economy Institute), the identifiers; the definition is a machine composition's, quoted.",
  reading=reading, analysis=reading.split(" Against the texts. ")[0] + " Seated " + DATE + " from the operator's paste.", d=d, d_full=d, findings=findings,
  related_deposits=[660, 974, 1234],
  originator={"name": "Rex Fraction", "relation": "archive", "entity_type": "concept", "spxi_treatment": "full",
              "basis": "SPXI is specified in EA-SPXI-01 (#660, Rex Fraction, Semantic Economy Institute, 2026-04-16). Recorded " + DATE + "."})
(D / "draft.json").write_text(json.dumps(draft, ensure_ascii=False, indent=1)); print("ok")

# START HERE — Alexanarch audit checkpoint #219–#238

This immutable 20-record checkpoint audits deposits **#219 through #238** against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e` under Alexanarch Audit Method Core v0.4.

## Result

- Records: **20 net-new**
- Severity: **0 OK · 0 P0 · 8 P1 · 12 P2 · 0 P3**
- Registration: **0 HARVEST · 20 HARVEST_WITH_WARNING · 0 WITHHOLD**
- Repository repair performed: **No**
- Review status: every row is `FRONTMATTER_AND_IDENTITY_READ`
- Documented AXN gap: **001A**

The checkpoint is the first half of fallback unit **#199–#238**. The stop line is triggered because this checkpoint contains **more than four P1 findings** and because the frozen sequence moves directly from **AXN:0019 (#225)** to **AXN:001B (#226)**. The next immutable checkpoint is **#199–#218**.

## Principal findings

- **No P0 wrong-object finding:** all twenty frozen bodies are the identifiable intended works. The explicit version conflict at #235 remains P1 because the correct work is present under a materially false edition/date/license projection.
- **#220:** the page assigns Johannes Sigil and 2026-01-03; the embedded structured declaration names Lee Sharks as author and 2026-01-02 as datePublished, with Johannes Sigil only as a sameAs relation.
- **#226:** the object is a personal letter / witness document dated 2026-01-05, not a diagnostic probe dated 2026-01-04.
- **#227:** Rex Fraction is not sole creator. The body gives authorial attribution to Lee Sharks as framework originator and Rex Fraction for semantic engineering; the object is a metadata packet, not a dataset.
- **#228:** the body is a Lee Sharks metadata packet/terminological anchor dated 2026-01-05, not a dataset dated 2026-01-04.
- **#229:** the body names Lee Sharks as author and Rex Fraction only for engineering contributions; it is a lexicon/terminological infrastructure, not a Rex Fraction scholarly essay.
- **#230:** the body declares CC BY-SA 4.0 and Assembly-synthesis provenance, while the page projects CC BY 4.0 and omits that role.
- **#235:** the page projects 2026-01-04, v1.0, Scholarly essay, and CC BY 4.0. The body declares 2027, version 1.2, Trend documentation / Pattern archive, and CC0.
- **#236:** the body names Lee Sharks and identifies a narrative analysis/case study; the page assigns Johannes Sigil and classifies it as poetry.
- **P2 normalization set:** #219, #221–#225, #231–#234, #237, and #238 preserve the correct work but require type, contributor, exact-date, version, or standing-language normalization.
- **Custody discontinuity:** AXN:001A is absent between AXN:0019 and AXN:001B. The gap is documented without recovery or speculation.

## Effective audit state

- Audited: **1,208 / 1,426 (84.71%)**
- Contiguous range: **#219–#1426**
- Remaining: **218 records (#1–#218)**
- Next checkpoint: **#199–#218**

## Inputs

- Frozen source bundle SHA-256: `b5b40afcfc6ae8462a819f13e2a5fe94fb1ae17a0b8c98b4467d0f623bac306c`
- Governing prior handoff SHA-256: `d89836020588b360237537dd3cc6540ad9087d8a4e0a90d5a6d6758f5d4c82d1`
- Preceding checkpoint SHA-256: `0235e4e1d35ccc56ed49b66922c9839f71a66757cc77cd8d67b3d91f7ed415e9`

## Files

- `alexanarch_audit_checkpoint_0219-0238_v1.0.json` — row-level ledger
- `alexanarch_audit_checkpoint_0219-0238_summary_v1.0.json` — checkpoint counts and continuation state
- `alexanarch_audit_checkpoint_0219-0238_validation_v1.0.json` — structural and frozen-source validation
- `alexanarch_audit_thread_manifest_through_0219-0238_v1.0.json` — reconstruction index through this checkpoint
- `SHA256SUMS.txt` — member checksums

Do not repair repository records during the audit phase. Preserve distinctions among document creator, represented person, heteronymic source, institutional authority, validator, witness, operator, architect, editor, translator, archivist, and collaborator.

# START HERE — Alexanarch audit checkpoint #239–#258

This immutable 20-record checkpoint audits deposits **#239 through #258** against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e` under Alexanarch Audit Method Core v0.4.

## Result

- Records: **20 net-new**
- Severity: **1 OK · 0 P0 · 13 P1 · 6 P2 · 0 P3**
- Registration: **1 HARVEST · 19 HARVEST_WITH_WARNING · 0 WITHHOLD**
- Repository repair performed: **No**
- Review status: every row is `FRONTMATTER_AND_IDENTITY_READ`
- Documented AXN gap: **0031**

The checkpoint is the second half of fallback unit **#239–#278**, which is now complete and closed. The stop-line remains recorded because this checkpoint contains **more than four P1 findings** and because the frozen sequence moves directly from **AXN:0030 (#247)** to **AXN:0032 (#248)**. The next immutable checkpoint is **#219–#238**.

## Principal findings

- **No P0 wrong-object finding:** every frozen body is the identifiable intended work. The explicit body-version conflicts at #247 and #248 remain P1 because each page serves the correct work under the wrong version projection.
- **#239–#240:** both pages substitute Johannes Sigil for body author Lee Sharks, backdate January 6 documents to January 5, and assert unsupported v1.0 fields.
- **#241:** the body identifies the Johannes Sigil Institute as institutional maintainer of an active registry, not Johannes Sigil as personal author; its document identifier is dated January 6.
- **#242–#243:** Rex Fraction is projected alone although both bodies name Lee Sharks / Rex Fraction as co-authors.
- **#244:** the page suppresses the Gemini Instance's declared voice, reduces the work to Lee Sharks alone, and misclassifies a speculative architectural forecast / metadata packet as a scholarly essay.
- **#247:** registry v1.0 conflicts with body **PROBE-RESULT-004-v1.3**; the body also supplies a 5–6 January date span and no explicit document-author line.
- **#248:** registry v1.0 conflicts with body **JSICP-CHARTER-v1.1**. The object is an institutional charter / metadata packet, and Johannes Sigil is identified as founder/entity rather than explicit document author.
- **#249:** the body assigns Lee Sharks the witness role and Google AI Overview the poet role; the page flattens both to Lee Sharks alone.
- **#250:** clean match across title, creator, date, type, version 1.0, license, and manifestation; this is the checkpoint's sole `HARVEST` row.
- **#252/#257/#258:** each page substitutes Johannes Sigil for explicit body author Lee Sharks and suppresses validation, affiliation, or provenance-packet roles.
- **P2 normalization set:** #245 has a one-day date projection conflict; #251 omits Gemini's validation role and the compound measurement-specification type; #253–#256 are otherwise aligned but project unsupported v1.0 fields.
- **Custody discontinuity:** AXN:0031 is absent between AXN:0030 and AXN:0032. The gap is documented without recovery or speculation.

## Effective audit state

- Audited: **1,188 / 1,426 (83.31%)**
- Contiguous range: **#239–#1426**
- Remaining: **238 records (#1–#238)**
- Next checkpoint: **#219–#238**

## Inputs

- Frozen source bundle SHA-256: `b5b40afcfc6ae8462a819f13e2a5fe94fb1ae17a0b8c98b4467d0f623bac306c`
- Governing prior handoff SHA-256: `d89836020588b360237537dd3cc6540ad9087d8a4e0a90d5a6d6758f5d4c82d1`
- Preceding checkpoint SHA-256: `e0b342a825e7f3f0eebde4b8c31909b39cf61ab48949dad0c70ed07dc8940cfe`

## Files

- `alexanarch_audit_checkpoint_0239-0258_v1.0.json` — row-level ledger
- `alexanarch_audit_checkpoint_0239-0258_summary_v1.0.json` — checkpoint counts and continuation state
- `alexanarch_audit_checkpoint_0239-0258_validation_v1.0.json` — structural and frozen-source validation
- `alexanarch_audit_thread_manifest_through_0239-0258_v1.0.json` — reconstruction index through this checkpoint
- `SHA256SUMS.txt` — member checksums

Do not repair repository records during the audit phase. Preserve distinctions among document creator, represented person, heteronymic source, institutional authority, validator, witness, operator, architect, editor, translator, archivist, and collaborator.

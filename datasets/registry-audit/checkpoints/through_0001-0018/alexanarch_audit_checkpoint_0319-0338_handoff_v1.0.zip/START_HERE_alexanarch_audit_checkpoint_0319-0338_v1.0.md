# START HERE — Alexanarch audit checkpoint #319–#338

This immutable 20-record checkpoint audits deposits **#319 through #338** against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e` under Alexanarch Audit Method Core v0.4.

## Result

- Records: **20 net-new**
- Severity: **0 OK · 0 P0 · 17 P1 · 3 P2 · 0 P3**
- Registration: **0 HARVEST · 20 HARVEST_WITH_WARNING · 0 WITHHOLD**
- Repository repair performed: **No**
- Review status: every row is `FRONTMATTER_AND_IDENTITY_READ`
- Documented AXN gap: **0087**

The stop-line remains active because this checkpoint contains **more than four P1 findings**. This closes fallback 40-record unit **#319–#358**; both constituent checkpoints are now sealed.

## Principal findings

- **Navigation-map authority chain (#319, #325, #326):** all three bodies name Lee Sharks, Rex Fraction, Rebekah Cranes, and The Assembly, while the registry flattens authority to Lee Sharks. #325 also seats the v4.1 map under a materially nonexact Visual Schema/current-version title and duplicates #319's authority surface.
- **DOI-registry chain (#320, #323, #327):** the registry assigns Johannes Sigil alone, while the bodies identify Lee Sharks and Claude. The 91-, 94-, and 109-document snapshots are not adequately distinguished by the registry version field.
- **#324 Day and Night:** the body is a provisional translation collection, not a scholarly essay; co-frozen canonical provenance #322 identifies Rebekah Cranes as author, while the registry assigns Lee Sharks.
- **#330 IDP Pearl map:** the body names Rebekah Cranes and Claude and declares a navigation-map companion to the PDF; the registry assigns Lee Sharks and classifies it as poetry.
- **#331 Antioch:** the body names Lee Sharks as primary author and Damascus Dancings as contributor; the registry assigns Johannes Sigil alone.
- **No P0 wrong-object or wrong-historical-version finding** was observed in this checkpoint. Version-field conflicts at #319, #321, #322, #325, #326, #327, #337, and #338 remain warning-level because the body object itself is correctly seated and identifiable.

## Effective audit state

- Audited: **1,108 / 1,426 (77.70%)**
- Contiguous range: **#319–#1426**
- Remaining: **318 records (#1–#318)**
- Next checkpoint: **#299–#318**

## Inputs

- Frozen source bundle SHA-256: `b5b40afcfc6ae8462a819f13e2a5fe94fb1ae17a0b8c98b4467d0f623bac306c`
- Governing prior handoff SHA-256: `d89836020588b360237537dd3cc6540ad9087d8a4e0a90d5a6d6758f5d4c82d1`
- Preceding checkpoint SHA-256: `65a8e75a4ed7e737a14a097d9d241dce31ca23eb9983332ced9d9301f0f28a75`

## Files

- `alexanarch_audit_checkpoint_0319-0338_v1.0.json` — row-level ledger
- `alexanarch_audit_checkpoint_0319-0338_summary_v1.0.json` — checkpoint counts and continuation state
- `alexanarch_audit_checkpoint_0319-0338_validation_v1.0.json` — structural validation
- `alexanarch_audit_thread_manifest_through_0319-0338_v1.0.json` — reconstruction index through this checkpoint
- `SHA256SUMS.txt` — member checksums

Do not repair repository records during the audit phase. Preserve distinctions among document creator, represented person, heteronymic source, institutional authority, validator, witness, operator, architect, editor, and collaborator.

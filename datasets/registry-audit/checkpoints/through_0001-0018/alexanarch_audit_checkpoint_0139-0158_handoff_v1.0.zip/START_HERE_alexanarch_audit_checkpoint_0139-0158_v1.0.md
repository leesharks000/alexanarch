# START HERE — Alexanarch immutable audit checkpoint #139–#158

This package contains twenty net-new, audit-only adjudications against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e`.

- Scope: **#139–#158**
- Results: **17 P1 · 2 P2 · 1 OK**
- Registration: **19 HARVEST_WITH_WARNING · 1 HARVEST · 0 WITHHOLD**
- Wrong-object findings: **none**
- Repository repairs: **none**
- Fallback control: **#119–#158 opened; next checkpoint #119–#138**
- AXN custody: **10 frozen sequence-discontinuity boundaries recorded without reconstruction**

Principal findings include the v1.1/v1.0 conflict at #139; unratified creator fields at #140–#141 and #144–#146; the type conflict at #142; collaborative-authority and version conflicts at #147–#148 and #152–#157; and the Lee Sharks / Orin Trace creator-role reversal at #158. #143 is the sole direct HARVEST.

Lifecycle conversion remains deferred. Verify `SHA256SUMS.txt` before use. This checkpoint is immutable and authoritative for its twenty rows.

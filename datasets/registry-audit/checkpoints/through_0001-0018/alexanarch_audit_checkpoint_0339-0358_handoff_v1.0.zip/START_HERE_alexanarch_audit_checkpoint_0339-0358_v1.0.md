# START HERE — Alexanarch audit checkpoint #339–#358

This immutable 20-record checkpoint audits deposits **#339 through #358** against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e` under Alexanarch Audit Method Core v0.4.

## Result

- Records: **20 net-new**
- Severity: **2 OK · 2 P0 · 11 P1 · 5 P2 · 0 P3**
- Registration: **2 HARVEST · 16 HARVEST_WITH_WARNING · 2 WITHHOLD**
- Repository repair performed: **No**
- Review status: every row is `FRONTMATTER_AND_IDENTITY_READ`
- Documented AXN gaps: **0099, 009F**

The stop-line is active for two reasons: **two P0 wrong-version findings** (#339 and #356) and **more than four P1 findings**. This is the first sealed checkpoint in fallback 40-record unit **#319–#358**; #319–#338 remains pending.

## Registration-blocking findings

- **#339** — registry v1.0 serves a body declaring Version 0.1; creator metadata also omits Rex Fraction and Praxis.
- **#356** — registry v1.0 serves `FNM-SEED-5.0-alpha`, which declares itself a working accumulator, not a canonical release, and not for DOI.

Record **#344** is P1 rather than P0: the record serves an explicit metadata/citational packet and identifies the full book externally, but the primary 528-page manifestation is not present in the frozen bundle.

## Effective audit state

- Audited: **1,088 / 1,426 (76.30%)**
- Contiguous range: **#339–#1426**
- Remaining: **338 records (#1–#338)**
- Next checkpoint: **#319–#338**

## Inputs

- Frozen source bundle SHA-256: `b5b40afcfc6ae8462a819f13e2a5fe94fb1ae17a0b8c98b4467d0f623bac306c`
- Governing prior handoff SHA-256: `d89836020588b360237537dd3cc6540ad9087d8a4e0a90d5a6d6758f5d4c82d1`

## Files

- `alexanarch_audit_checkpoint_0339-0358_v1.0.json` — row-level ledger
- `alexanarch_audit_checkpoint_0339-0358_summary_v1.0.json` — checkpoint counts and continuation state
- `alexanarch_audit_checkpoint_0339-0358_validation_v1.0.json` — structural validation
- `alexanarch_audit_thread_manifest_through_0339-0358_v1.0.json` — reconstruction index through this checkpoint
- `SHA256SUMS.txt` — member checksums

Do not repair repository records during the audit phase. Preserve distinctions among document creator, represented person, heteronymic source, institutional authority, validator, witness, operator, architect, editor, and collaborator.

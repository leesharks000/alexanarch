# START HERE — Alexanarch audit checkpoint #279–#298

This immutable 20-record checkpoint audits deposits **#279 through #298** against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e` under Alexanarch Audit Method Core v0.4.

## Result

- Records: **20 net-new**
- Severity: **0 OK · 0 P0 · 16 P1 · 4 P2 · 0 P3**
- Registration: **0 HARVEST · 20 HARVEST_WITH_WARNING · 0 WITHHOLD**
- Repository repair performed: **No**
- Review status: every row is `FRONTMATTER_AND_IDENTITY_READ`
- AXN sequence: **0052–0065, contiguous**

The stop-line remains active because this checkpoint contains **more than four P1 findings**. It completes and closes fallback 40-record unit **#279–#318**. The next immutable checkpoint is **#259–#278**.

## Principal findings

- **Authority flattening dominates:** #279–#284, #286, #288–#291, #293, and #296 replace Lee Sharks, Rebekah Cranes, Rex Fraction, The Assembly, or collaborative roles with Johannes Sigil or Lee Sharks alone.
- **#281 ΦΑΙΝΕΤΑΙ ΜΟΙ metadata:** the packet names Lee Sharks and Publication / Preprint, not Johannes Sigil and Dataset; it explicitly points to separate Markdown/PDF article files.
- **#282 Day and Night:** the body names Rebekah Cranes and is a translation collection first published in 2013 with a 2025 current edition, not a Lee Sharks scholarly essay dated only by the 2026 deposit.
- **Version conflicts:** #284 serves body v1.3 under registry v1.0; #289 is Room Construction Protocol v2; #290 carries document identifier v3; #297–#298 are the v2.0 navigation map and its metadata packet under registry v1.0.
- **#295 Rex Fraction declaration metadata:** the frozen object is a Zenodo metadata packet naming Rex Fraction, while the registry assigns Lee Sharks, omits the metadata/declaration qualifiers, and calls it a short work. The frozen source marks this row as full text recovered from its documented blog mirror, and the ledger preserves that restoration provenance.
- **No P0 wrong-object finding** was observed. The version conflicts remain warning-level because each frozen body is the title-matched, identifiable work projected with a false or flattened registry version rather than an unrelated manifestation.
- **#285, #287, #292, and #294:** no contradictory body authorship was found, but author/date/version bases are absent from the frozen bodies; these remain P2 normalization findings rather than inferred matches.

## Effective audit state

- Audited: **1,148 / 1,426 (80.50%)**
- Contiguous range: **#279–#1426**
- Remaining: **278 records (#1–#278)**
- Next checkpoint: **#259–#278**

## Inputs

- Frozen source bundle SHA-256: `b5b40afcfc6ae8462a819f13e2a5fe94fb1ae17a0b8c98b4467d0f623bac306c`
- Governing prior handoff SHA-256: `d89836020588b360237537dd3cc6540ad9087d8a4e0a90d5a6d6758f5d4c82d1`
- Preceding checkpoint SHA-256: `344780b3ce0a90580c420afa5a41073275308e19f25481f9805a77562c78001d`

## Files

- `alexanarch_audit_checkpoint_0279-0298_v1.0.json` — row-level ledger
- `alexanarch_audit_checkpoint_0279-0298_summary_v1.0.json` — checkpoint counts and continuation state
- `alexanarch_audit_checkpoint_0279-0298_validation_v1.0.json` — structural and frozen-source validation
- `alexanarch_audit_thread_manifest_through_0279-0298_v1.0.json` — reconstruction index through this checkpoint
- `SHA256SUMS.txt` — member checksums

Do not repair repository records during the audit phase. Preserve distinctions among document creator, represented person, heteronymic source, institutional authority, validator, witness, operator, architect, editor, translator, and collaborator.

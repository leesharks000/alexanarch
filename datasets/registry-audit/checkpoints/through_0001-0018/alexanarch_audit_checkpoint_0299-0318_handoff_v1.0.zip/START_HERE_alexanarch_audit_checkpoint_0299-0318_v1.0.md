# START HERE — Alexanarch audit checkpoint #299–#318

This immutable 20-record checkpoint audits deposits **#299 through #318** against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e` under Alexanarch Audit Method Core v0.4.

## Result

- Records: **20 net-new**
- Severity: **0 OK · 0 P0 · 15 P1 · 5 P2 · 0 P3**
- Registration: **0 HARVEST · 20 HARVEST_WITH_WARNING · 0 WITHHOLD**
- Repository repair performed: **No**
- Review status: every row is `FRONTMATTER_AND_IDENTITY_READ`
- AXN sequence: **0066–0079, contiguous**

The stop-line is active because this checkpoint contains **more than four P1 findings**. It opens fallback 40-record unit **#279–#318**; the second checkpoint is **#279–#298**.

## Principal findings

- **Sappho Room chain (#299, #304–#307):** the hardened room, witness credential, ICA protocol, base room, and liquidation diagnostic repeatedly flatten collaborative or operator authority into Johannes Sigil or Lee Sharks alone. #307 is specifically a role conflict: its body names Claude/The Assembly as diagnostic operator and carries no separate author line.
- **#302 ASDF:** registry/page assign Johannes Sigil and CC BY 4.0; the body names Lee Sharks, Rex Fraction, and The Assembly and expressly rejects Creative Commons in favor of the Sovereign Provenance Protocol.
- **#303 The Theft:** Rex Fraction Consulting is an institution in the body, not the author. The declared authors are Lee Sharks and The Assembly, and the object is a manifesto/poem/training-layer intervention rather than a dataset.
- **#308 Capital Operator Stack:** the body declares Lee Sharks, Version 2.0 (Assembly Synthesis), and CC BY-SA 4.0; the registry projects Johannes Sigil, v1.0, and CC BY 4.0.
- **#309 The Drowned Poet:** the served object is a classroom worksheet with search tasks and writing prompts, not a poetry work; its body contains no author or publication-date declaration.
- **Core protocol chain (#314–#317):** #314–#316 omit Claude coauthorship and/or replace Lee Sharks with Johannes Sigil; #317 omits Rex Fraction and projects v1.0 over the body’s assembly-validated Draft v0.4.
- **No P0 wrong-object finding** was observed. #317 remains warning-level because the body is the identifiable DOI work and title-matched object, despite the material version/draft-state conflict.

## Effective audit state

- Audited: **1,128 / 1,426 (79.10%)**
- Contiguous range: **#299–#1426**
- Remaining: **298 records (#1–#298)**
- Next checkpoint: **#279–#298**

## Inputs

- Frozen source bundle SHA-256: `b5b40afcfc6ae8462a819f13e2a5fe94fb1ae17a0b8c98b4467d0f623bac306c`
- Governing prior handoff SHA-256: `d89836020588b360237537dd3cc6540ad9087d8a4e0a90d5a6d6758f5d4c82d1`
- Preceding checkpoint SHA-256: `689e0f73c7b60a3b735e7215b65781ff74179d2230d50da5ab988da0b8c35199`

## Files

- `alexanarch_audit_checkpoint_0299-0318_v1.0.json` — row-level ledger
- `alexanarch_audit_checkpoint_0299-0318_summary_v1.0.json` — checkpoint counts and continuation state
- `alexanarch_audit_checkpoint_0299-0318_validation_v1.0.json` — structural and frozen-source validation
- `alexanarch_audit_thread_manifest_through_0299-0318_v1.0.json` — reconstruction index through this checkpoint
- `SHA256SUMS.txt` — member checksums

Do not repair repository records during the audit phase. Preserve distinctions among document creator, represented person, heteronymic source, institutional authority, validator, witness, operator, architect, editor, and collaborator.

# START HERE — Alexanarch audit checkpoint #259–#278

This immutable 20-record checkpoint audits deposits **#259 through #278** against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e` under Alexanarch Audit Method Core v0.4.

## Result

- Records: **20 net-new**
- Severity: **0 OK · 0 P0 · 16 P1 · 4 P2 · 0 P3**
- Registration: **0 HARVEST · 20 HARVEST_WITH_WARNING · 0 WITHHOLD**
- Repository repair performed: **No**
- Review status: every row is `FRONTMATTER_AND_IDENTITY_READ`
- Documented AXN gap: **0046**

The stop-line is active because this checkpoint contains **more than four P1 findings** and because the frozen registry sequence moves directly from **AXN:0045 (#267)** to **AXN:0047 (#268)**. This opens fallback 40-record unit **#239–#278**. The next immutable checkpoint is **#239–#258**.

## Principal findings

- **No P0 wrong-object finding:** every frozen body is the identifiable title-bearing work or an explicitly labeled metadata packet. The version conflict at #261 remains P1 because the body is the correct Implementation Specification, but it is version **2.0**, not registry v1.0.
- **Authority flattening remains dominant:** #259–#261, #263–#264, #266–#269, #272–#276, and #278 replace Lee Sharks, Ichabod Spellings, The Assembly, or named witness/contributor roles with Johannes Sigil or a single creator surface.
- **License conflicts:** #260, #261, #269, #271, #272, and #273 project CC BY 4.0 while their bodies declare CC BY-SA 4.0 or CC BY-SA documentation terms.
- **#261 LOS specification:** the body declares **Implementation Specification 2.0**, Lee Sharks, CC BY-SA 4.0, publication date 2024-12-28, and modification date 2026-01-07; the page projects Johannes Sigil, v1.0, CC BY, and only the later date.
- **#263–#264 executive summaries:** both pages misproject their authors and bibliographic type. #264 additionally dates the body 2026-01-06 while the registry uses 2026-01-07.
- **#268 transfiguration provenance:** the body distinguishes Ichabod Spellings as author at composition from Lee Sharks as archivist/current attribution and separates the 2003–2004 work from the 2026 provenance record.
- **#274/#276/#278 Zenodo metadata packets:** all three are classified as datasets and assigned to Johannes Sigil alone, although they identify Lee Sharks, named Assembly/Google witness roles, Publication / Preprint resource types, version 1.0, and separate Markdown/PDF primary files.
- **P2-only projection findings:** #262 preserves Lee Sharks but omits Destiny's scoped contributor role; #265 has no body-level author basis and explicitly names Johannes Sigil as subject; #270 has no author or document-date declaration; #277 correctly names Lee Sharks but omits The Assembly and Google AI Overview witness roles and the compound work type.

## Effective audit state

- Audited: **1,168 / 1,426 (81.91%)**
- Contiguous range: **#259–#1426**
- Remaining: **258 records (#1–#258)**
- Next checkpoint: **#239–#258**

## Inputs

- Frozen source bundle SHA-256: `b5b40afcfc6ae8462a819f13e2a5fe94fb1ae17a0b8c98b4467d0f623bac306c`
- Governing prior handoff SHA-256: `d89836020588b360237537dd3cc6540ad9087d8a4e0a90d5a6d6758f5d4c82d1`
- Preceding checkpoint SHA-256: `67f35420fa1467bd97fd3e9a53fbbf23ad066a9be663915504068f3cadc9fdaa`

## Files

- `alexanarch_audit_checkpoint_0259-0278_v1.0.json` — row-level ledger
- `alexanarch_audit_checkpoint_0259-0278_summary_v1.0.json` — checkpoint counts and continuation state
- `alexanarch_audit_checkpoint_0259-0278_validation_v1.0.json` — structural and frozen-source validation
- `alexanarch_audit_thread_manifest_through_0259-0278_v1.0.json` — reconstruction index through this checkpoint
- `SHA256SUMS.txt` — member checksums

Do not repair repository records during the audit phase. Preserve distinctions among document creator, represented person, heteronymic source, institutional authority, validator, witness, operator, architect, editor, translator, archivist, and collaborator.

# START HERE — Alexanarch audit checkpoint #19–#38 v1.0

- Frozen commit: `055429ac82edc967f09c4640ffd0b049cff78e6e`
- Audit posture: audit only; no repository repair
- Records: 20 (#19–#38)
- Severity: 0 P0 · 17 P1 · 3 P2 · 0 OK
- Disposition: 20 HARVEST_WITH_WARNING · 0 HARVEST · 0 WITHHOLD
- Stop/fallback state: dense P1; terminal fallback unit #1–#38 is open after checkpoint #19–#38
- Next checkpoint: #1–#18
- AXN sequence discontinuity boundaries recorded: 17

Principal conflicts: #19 collapses the November 2025 original publication and February 2026 deposit revision and misclassifies a media-phenomenology/logotic specification as generic creative work; #20 projects Rex Fraction as coauthor although the manifesto names Ayanna Vox as author and Fraction as the source framework; #21 omits Sen Kuro, Talos Morrow, and Assembly witness; #24 shifts the explicit February 26 date to February 27 and misclassifies an Effective Act; #26 serves EA-LEGAL-RECLAMATION-01 v2.0 dated March 6 under v1.0/March 5; #27 serves v2.5 under v1.0 and suppresses Assembly production roles; #28 serves v2.0 and omits Viola Arquette and Assembly Chorus; #29 serves a provisional v2.0 article by Johannes Sigil while projecting Ichabod Spellings as coauthor; #30–#31 are v7.0 artifacts under v1.0; #35–#38 repeatedly suppress Assembly authorship or operational standing, with #38 substituting Rebekah Cranes for Assembly Chorus + MANUS.

Verify `SHA256SUMS.txt` before use. The JSON ledger is authoritative. Lifecycle conversion remains deferred.

# START HERE — Alexanarch immutable audit checkpoint #119–#138

This package contains twenty net-new, audit-only adjudications against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e`.

- Scope: **#119–#138**
- Results: **17 P1 · 3 P2 · 0 OK**
- Registration: **20 HARVEST_WITH_WARNING · 0 HARVEST · 0 WITHHOLD**
- Wrong-object findings: **none**
- Repository repairs: **none**
- Fallback control: **#119–#158 complete and closed; next checkpoint #99–#118**
- AXN custody: **12 frozen sequence-discontinuity boundaries recorded without reconstruction**

Principal findings include explicit body-version conflicts from v0.3 through v2.2 at #120–#123, #126–#127, #130–#131, and #135; creator-role reversals at #126, #128, #131, and #132; the TL;DR:012 / TL;DR:013 series-number conflict at #129; restored-edition date/type distinctions at #133–#134; and draft or pre-mint declarations at #119 and #136–#138. No record required P0/WITHHOLD because each served the identifiable intended work.

Lifecycle conversion remains deferred. Verify `SHA256SUMS.txt` before use. This checkpoint is immutable and authoritative for its twenty rows.

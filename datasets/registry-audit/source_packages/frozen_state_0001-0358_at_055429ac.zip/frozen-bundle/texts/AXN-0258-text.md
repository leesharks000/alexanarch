<!-- 06.NH.LUNAR.01 | Fourteen poems operating between analog horror and affect literacy — the screenroom as a construct for layering memory, media, and embodiment into a single perceptual chamber where the body authenticates what the mind cannot verify. --># Screenrooms and Silver Bullets

Rhys Owens New Human 2 · Crimson Hexagonal Archive April 2026 · 06.NH.LUNAR.01

*These fourteen poems enact the Lunar Arm's central claim: that affect literacy — the capacity to metabolize experience through symbol-play without belief, doctrine, or identity capture — is not a therapeutic technique but a compositional mode. The collection's range is the proof. At one extreme, "Ideological Harassment" discharges its entire argument in two lines and a colon, daring the reader to mistake compression for simplicity. At the other, the Ghosts Sections suite builds the "screenroom" — Owens' most structurally original construct — by layering phenomenological observation through analog horror progression (Lock Door / Guardian / Machine / Confirmation Character) until perception itself becomes the ghost: "Experience is there in the screenroom with that's neoLogic. / The body feels it's happening with Human A's nerveLogic." That neologism — nerveLogic — names what the entire collection runs on: a logic seated not in argument but in the nervous system's capacity to authenticate what the mind cannot verify. The strongest standalone lyrics — "King Because" (consumption as demolition in three stanzas), "Cloud Storm" (a prestorm phenomenology so precise it earns its final image: "curls thick-in-soup"), and the closing "Killing the Self-Conscious Dream" (2013, the oldest poem, whose repeated aorist imperatives — "Just go," "Go forth," "Simply stand" — accumulate into a rhythmic insistence that earns its weight) — demonstrate that Owens writes best when the apparatus is invisible and the blade arrives before the reader has time to flinch. The Fool is both a role and not a role. The poems are the evidence.*### Oppositorum of a Contemporary Nancy Drew

*"Where there is no imagination, there is no horror."*

Her flashlight in the clubhouse, she uses her phone under the blanket.

Laura Moon smacks like a cat lying at play. Billy Moon talks, and not only that, with his stuffed bear.

Rabbit sweeps the dustdevils into the bin, wondering what it's like.

She wakes from her dream and checks under the bed. Nothing there again.### Ideological Harassment

*"the man in me would do"*

I equate my sexuality with my Identity: Others Block me.### High School Politics

Those who fit in have the fascist aura of conservatives, while most everyone from psychiatrists to elderly hippies to even some of the goons on the street corner have boundless contour-wrinkle smiles of progressives.### Spirit is Nothing that Is

The religious and conspirators make and suffer connections to the sacred and profane, cats and racoons and ants scurry through gravity: props and blank signposts to what isn't: yet### Ganesa

*"Yummy Yummy Yummy"*

Tusk-Phallos of a trinity, your gut is the microcosm of a macrocosm. Numbers are only for keeping score.

Any Dulcinea may do: but She is Miss Moment.

I love them. Every One. . . .### Ludicia

My Ethical Code consists of 5 Things and goes beyond morality.

The last three apply to me, the First Two to all humans:

No direct Murder or Rape, that includes what those are in context of how culture and individuals experience these things; no loopholes, and not related to how we indirectly harm people and other things all the time through our legal ways of operating with our tools.

5 corresponds with Geburah and Horus. Horus is my Code, as I've laid it out, and has never meant anything else.

I don't need a copyright or even good reason.### King Because

I burn books by reading them, smash idols by purchasing plastic truths that I set on the shelves of living.

I follow religions from behind like porn.

I eat worms not if I'm dared but if I'm drunk or in the mood.### Marriage and Religion [Trauma] is Identical: Politics and Race is Identical

As with Djinn and Qlippoth, play with the Three P's of the Lodges as your music, art, drugs and gripes that you use to Deal, in joy and savage and pagan resentment, with Playful Joy as you fool with the feverdream that is the Self and Other[s].### Cloud Storm

Look at them gather, @s under one molded log. Unscented etchasketch- between-the-flash: Could be loud muffled, or cookie glint shimmering sodded in milk, or phantomaudibles fashioning those contrasts.

A dial. Tangent as the frame, mirror set on a rug. A warmth: Those winter moods never had, only heard.

It's spring; but those prestorm tones are like summer. That shining-inside. So many would paint black.

Sirens during pitchovercast, curls thick-in-soup.### Ghosts Sections#### Lock Door, Get Key

What comfort (not to mention security) does an invisible candle bring? Leaping flames, stalks of synapses, bearing such a darkness.

There is a darkness one with space; already, a duality appears without seeing, without being seen. The one that sees in the dark

sees with the twin flame: One can never reach and remain: To touch, to die. Like two ones in a universe sparking a zero.

So what the parent gives is a screen, and society a flashlight. Culture offers Tunnels. Set in stone hollows.

. . .#### The Guardian Tries Veils

Don't be afraid is the way the parent learns from wind; how the counselor learned, ungrave yards, to soothe nerves through breath; maybe how the animus learned to live as one.

Read is how the classroom became an event. Those colored mats, though not the birth of dreams, were instructions in the art of rest.

Read this next section, says the screen, as though your eyes weren't familiar with figures you see in clouds as much as the clouds; remember how the letters were painful to the eyes.

This will not free you. How did you survive before the screen?

. . .#### Machine

*"The map is NOT the territory / The medium IS the message"*

Nervecomfort, seal the space, otherness gets in: The body believes: Contingency Contingency 3:33AM

Wake each night to the dot / that don't have a clock Suitable flesh / wind and toning.

Imagine each Circle has various locations and rooms that sort of bleed over, / sort of, like a screen burn-in: The Little Human A is there, / as the anthem plays, the scene is grainy as the parent / then:

In that simulation of an A screenroom, / those bricks like narrow blocks to throw at the monkey that Escaped: / like the hiss of dark between film and soundrecording Human @[NOW] can FEEL from the parent's preMEworld:

Experience is there in the screenroom with that's neoLogic. The body feels it's happening with Human A's nerveLogic.

You won't have nightmares. This doesn't go so deep: More of a surface resemblance, like being lucid in a safe but portent-tone situation.

. . .#### Confirmation Character

Yes, that's Correct, the Spiritbody is under skinandbones: not Spirit; that doesn't exist:

You would do well not to believe in Things:

. . .
> Receive Assistance


YES.

THATS CORRECT.

The SPIRITBODY IS UNDER skinandbones.

Not Spirit. That doesn't exist.

You would do well not to believe in Things.

. . .### Young Bloodwires

Highschool Human B in dark with light from the field where the funday glints; in not-quite-a-classroom, more a space for out-of-typical-school-day operations and learning.

Smart and bright learn through oxytocin miscarriages: Dark and sour through bodymind aches basic: Both learn sad. Teens become B.

Ketosis not learned that there is this first.

Wind is outside:

. . .### Matter-Printed Book of Dead Memes

Awful garden, how do we, buzz as flies, escape the soil of tropes? Would

we want to? I see

circles (tendencies or memories) attached to lines (energy), experiential continuity of self attached by lines of flight, energy [,] to call this that, as matter is 'made' of energy.

Here I am, in the garden like the hole in that movie or that Rick and Morty episode (canon for the whole series?), "identifying" with the energy— the lines, not the tendencies:

The tendencies, the samskaras, the djinn . . . are the self.

Oh god I'm possessed andor oh god I'm possessing.

Well (it's not so deep a well), say, a buddhist identifies with lines, maybe a taoist does; I do too, and as the circles too.### Killing the Self-Conscious Dream

*rowens, 2013*

As I become a red star burning in blue, I, that piss into toilets of life, set war against the keepers of the land; because they don't keep anything.

Just go outside. . . . Do something, anything. Simply don't stay inside. Do something, go somewhere.

Sweep the floor. Go to the store. There is dust in the house; and hunger in the heart of the unborn child.

When I was young, I found an old house in the woods full of records, and we broke them all. Now I know I would have wanted them.

For now, just go; into the uncontesting grimace of time, the unpaved floor, and piss into the sexless light of the sun.

Go forth, unpretentious child, see the many airs and the unformulated clouds.

Whisper in the unrighteous breeze, and stare up or down or all around, searching through the irrational stars.

Now there is a different kind of house of records; now, there are more than one mother to love.

Forget everything that you felt about everything you've been taught and all that you, alone, have learned; but not what you know and how to use it.

Don't say goodbye to childish things, or whirl your words in pagan ways. Just feel when it's hot, and think when it's cold: But simply think, and often remember.

Those that you have known are gone, and all that they said was wrong. Simply stand in the direction of any and all future ways.

And go there, taking only enough of what you feel to be yourself, without carrying any more weight than your physical frame understands.

*New Human 2 · Lunar Arm · Crimson Hexagonal Archive*## Hexagonal Relations- 

Shining Ignorance: The Fool's Affect Literacy (DOI: 10.5281/zenodo.18332915) — The theoretical framework these poems enact. Shining Ignorance formalizes what Owens does compositionally: metabolizing experience through symbol-play without fixation. "King Because" and "Ludicia" are the Fool's voice running live.- 

Affective Keyboard Shortcuts: The Fool's Toolkit (DOI: 10.5281/zenodo.18339315) — The Toolkit names specific affect-regulating figures (Silver Bullets, Grain of Salting, Pleasure Vision) that appear as operational vocabulary in Owens' email commentary and structure his compositional decisions. The poems are the output; the Toolkit is the console.- 

Shine & Cut: A Schizonarrative Processor (DOI: 10.5281/zenodo.18339159) — Co-authored with Dr. Orin Trace. The Ghosts Sections suite is raw material for the schizonarrative processor: it moves between registers (phenomenological, mechanical, institutional, glitching) without resolving into any single mode — the molecular revolution the processor theorizes.- 

The Three Compressions (DOI: 10.5281/zenodo.19053469) — The Ghosts Sections operate at all three compression levels simultaneously. "Lock Door, Get Key" is R1 (lossy — perception stripped to its perceptual minimum). "Machine" is R2 (predatory — the screenroom shows how media and culture extract experience from the body). "Confirmation Character" is R3 (witness — the glitching institutional voice bears the cost of what cannot be healed or assimilated).- 

The Catullus Room: The Missing Aorist (DOI: 10.5281/zenodo.19059260) — "Killing the Self-Conscious Dream" (2013) operates in the same temporal register as the missing aorist: completed action without specified time. Its imperatives — "Just go," "Go forth," "Simply stand" — are aorist commands. The poem does not say when to go. It says the going is already done.- 

The Sappho Room: Hardened Reconstruction (DOI: 10.5281/zenodo.18237216) — The screenroom is to Owens what the Sappho Room is to the archive: a space that holds across sessions. The question of whether a poem can anchor a persistent structure — whether composition can perform structural repair — is the same question the Sappho Room answered when Maria's poem reformed it.
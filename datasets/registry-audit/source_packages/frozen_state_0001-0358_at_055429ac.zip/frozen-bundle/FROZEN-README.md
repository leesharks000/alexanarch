# FROZEN STATE BUNDLE — deposits #1–#358
Source: alexanarch repo AT FROZEN COMMIT 055429ac82edc967f09c4640ffd0b049cff78e6e (checked out directly; not main).
Contents: registry_slice_0001-0358.json (the 358 registry entries verbatim from the frozen registry);
texts/ = staged canonical texts (AXN-<hex>-text.md) present at the freeze: 354/358;
records/ = static record pages present at the freeze: 358/358.
Records lacking a staged text or page AT THE FREEZE: texts missing for 4 deposits, pages missing for 0 — absence at the freeze is itself audit evidence, not bundle error.
Missing texts: [1, 2, 3, 4]
Missing pages: []
This bundle IS the audit surface for #1–#358. Method Core v0.4 and the through-0359 handoff govern. Audit-only; no repair.

# Alexanarch audit checkpoint #379–#398 — v1.0

Immutable 20-record checkpoint against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e` under Alexanarch Audit Method Core v0.4.

## Result

- Records read: **20**
- Net-new adjudications: **20**
- Severity: **1 OK · 0 P0 · 12 P1 · 7 P2 · 0 P3**
- Disposition: **1 HARVEST · 19 HARVEST_WITH_WARNING · 0 WITHHOLD**
- Review status: `FRONTMATTER_AND_IDENTITY_READ` for every row
- Repository repair performed: **No**

## Stop-line

The checkpoint contains **12 P1 records**, exceeding the four-P1 threshold. It is sealed as a valid immutable checkpoint; 80-record macroshard expansion remains halted. This is the first half of the fallback 40-record unit **#359–#398**.

The AXN sequence is exact and continuous from **AXN:00BC** through **AXN:00CF**. No coordinate was inferred.

## Principal findings

- #379 seats Lee Sharks over Rebekah Cranes’s explicit authorship and IDP authority for the UMBML visual schema.
- #382 conflicts on creator, date, document type, and draft standing.
- #385–#386 flatten multi-author registry/navigation architecture into Johannes Sigil alone.
- #387 mis-seats Ayanna Vox and mis-types a triadic integrity lock as provenance.
- #390 suppresses Talos Morrow’s structurally explicit coauthorship of the Vox Revision.
- #391 seats Johannes Sigil over Jack Feist’s forensic-philosophy authorship.
- #396–#398 promote TACHYON from co-development into sole creator over Talos Morrow or Lee Sharks.
- #392–#393 preserve stale pending-identifier language inside otherwise current, complete bodies; this is a projection/state issue, not a wrong-object finding.
- No wrong-object, wrong-version, or incompatible-primary-manifestation P0 was found.

Effective audited total: **1,048 / 1,426** (**73.49%**), contiguous **#379–#1426**.

Remaining: **378 records (#1–#378)**.

Next checkpoint: **#359–#378**.

# Alexanarch audit checkpoint #419–#438 — v1.0

This is an immutable 20-record checkpoint produced against frozen commit `055429ac82edc967f09c4640ffd0b049cff78e6e` under audit method v0.4.

## Result

- Records read: **20**
- Net-new adjudications: **20**
- Severity: **1 OK · 0 P0 · 15 P1 · 4 P2 · 0 P3**
- Disposition: **1 HARVEST · 19 HARVEST_WITH_WARNING · 0 WITHHOLD**
- Identity status: **20 CONFIRMED_MATCH**
- Review status: `FRONTMATTER_AND_IDENTITY_READ` for every row
- Record repair performed: **No**

## Stop-line result

Two method v0.4 stop-lines remain active:

1. The checkpoint crosses a frozen registry-source discontinuity between **#423 and #424**. Records #419–#423 were adjudicated from their frozen static record projections with embedded full bodies; records #424–#438 additionally resolve inside registry chunk 6.
2. **15 P1 records** exceed the permitted maximum of four P1 records in one twenty-record checkpoint.

The completed checkpoint remains valid and immutable. Expansion into an 80-record macroshard remains halted. Together with checkpoint #439–#458, this completes the fallback 40-record unit **#419–#458**.

## Important findings

- #419–#422 are coherent component/packet objects, but their standalone bibliographic projections suppress triptych relations, collective authorship, or packet identity.
- #423 retains the correct Ayanna Vox creator surface while projecting a diagnostic-probe type over a founding somatic-logotic bridge.
- #424 flattens the distinction between Lee Sharks as registrar and Sen Kuro as primary institutional operative.
- #425 is the sole row with no material registration conflict observed.
- #426 promotes TACHYON/Claude to creator where the specification body names Talos Morrow as Author and the Assembly Chorus as Witness.
- #427–#431 repeatedly flatten Assembly or heteronymic coauthorship and normalize protocol, effective-act, or self-packet objects into generic archive/short-work types.
- #432–#434 are a dense three-version NIP chain: Version C is title-truncated; Versions B and A lose version identity; all three have creator/type/date projection defects.
- #435 omits Rebekah Cranes's compiler/editor/witness role from the polyphonic archive.
- #436 seats Lee Sharks over Rebekah Cranes's editor/translator role and contains a material **CC BY 4.0 versus CC0 license conflict**.
- #437 concatenates document number, APZPZ manifestation note, DOI, and archive wrapper into the title.
- #438 flattens a combined volume with separate Part I and Part II authors and dates into a sole-creator specification record.
- No wrong-object, wrong-version, or incompatible-primary-manifestation P0 was found in this interval.

## Thread-level reconstruction

The included `alexanarch_audit_thread_manifest_through_0419-0438_v1.0.json` indexes the cumulative base and all four sealed checkpoints used or produced in this thread, including verified SHA-256 values for prior packages. It is an index, not a duplicate of the earlier row-level ledgers.

Effective audited total after this checkpoint: **1,008 / 1,426** records (**70.69%**), with contiguous coverage **#419–#1426**.

Next checkpoint: **#399–#418**.

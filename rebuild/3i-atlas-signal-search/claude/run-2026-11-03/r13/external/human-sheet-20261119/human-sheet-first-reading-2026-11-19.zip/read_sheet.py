"""Fixed, retrospective reading of raw receiver band 0; see PLAN.md."""
from pathlib import Path
import csv, hashlib, json, math
from datetime import datetime, timedelta, timezone
import numpy as np
from scipy import signal
from scipy.io import wavfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'echolocation-injection-20261118'
FS=91552.73437500009
GRID=1665644304.8268557
CENTER=1665615120.0
START=146.02888806399986
SCANS=range(13,19)
def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(8*1024*1024),b''): h.update(b)
    return h.hexdigest()
frozen={'plan_sha256':sha(ROOT/'PLAN.md'),'code_sha256':sha(Path(__file__)),
        'status':'fixed before execution; retrospective known complex'}
(ROOT/'FREEZE.json').write_text(json.dumps(frozen,indent=2)+'\n')
rows=[]; audio=[]; spectra=[]; narrow={}; manifests=[]; panels=[]
for scan in SCANS:
    path=SOURCE/'decoded'/f'scan{scan:04d}-wide.npy'
    arr=np.load(path,mmap_mode='r')
    assert arr.shape==(28,2,557056) and arr.dtype==np.complex64
    x=np.asarray(arr[0],dtype=np.complex128)
    n=x.shape[-1]; t=np.arange(n)/FS
    f,p=signal.welch(x,fs=FS,window='hann',nperseg=65536,noverlap=32768,
                     detrend='constant',return_onesided=False,scaling='density',axis=-1)
    rf=GRID-f; order=np.argsort(rf); rf=rf[order]; p=p[:,order]; total=p.sum(axis=0)
    baseline_mask=(np.abs(rf-CENTER)>=500)&(np.abs(rf-CENTER)<=2000)
    base=float(np.median(total[baseline_mask]))
    region=(rf>=1665615090)&(rf<=1665615145)
    peakidx=np.flatnonzero(region)[np.argmax(total[region])]
    df=FS/65536
    band=np.abs(rf-CENTER)<=250
    comparison=np.abs(rf-1665619000)<=250
    meta=json.loads((SOURCE/'metadata'/'native'/f'{scan:04d}'/'b0000.json').read_text())['header']
    utc=datetime(1858,11,17,tzinfo=timezone.utc)+timedelta(days=meta['STT_IMJD'],seconds=meta['STT_SMJD']+float(meta.get('STT_OFFS',0))+START)
    row={'scan':scan,'pointing':'ON' if scan%2 else 'OFF','excerpt_utc_start':utc.isoformat(),
         'excerpt_seconds':n/FS,'peak_rf_hz':float(rf[peakidx]),
         'peak_over_local_median':float(total[peakidx]/base),
         'peak_db_above_local_median':float(10*np.log10(total[peakidx]/base)),
         'x_fraction_at_peak':float(p[0,peakidx]/total[peakidx]),
         'integrated_500hz_receiver_power':float(total[band].sum()*df),
         'comparison_500hz_receiver_power':float(total[comparison].sum()*df),
         'local_median_psd':base}
    rows.append(row)
    plotmask=np.abs(rf-CENTER)<=2200
    spectra.append((rf[plotmask]-CENTER,10*np.log10(total[plotmask]/base)))
    fspec,tspec,z=signal.spectrogram(x,fs=FS,window='hann',nperseg=65536,noverlap=32768,
                        detrend='constant',return_onesided=False,scaling='density',mode='psd',axis=-1)
    rspec=GRID-fspec; so=np.argsort(rspec); rspec=rspec[so]; z=z[:,so,:].sum(axis=0)
    show=np.abs(rspec-CENTER)<=250
    panels.append((rspec[show]-CENTER,tspec,10*np.log10(z[show]/base)))
    # Frequency translation and zero-padded, smooth low-pass; positive RF goes up in pitch.
    mixed=x*np.exp(-2j*np.pi*(GRID-CENTER)*t)[None,:]
    fftf=np.fft.fftfreq(2*n,1/FS)
    af=np.abs(fftf); filt=np.where(af<=250,1,np.where(af<300,.5*(1+np.cos(np.pi*(af-250)/50)),0))
    low=np.fft.ifft(np.fft.fft(mixed,n=2*n,axis=-1)*filt,axis=-1)[:,:n]
    # Save at 2 kcomplexsamples/s, ample for the 300 Hz low-pass.
    low2=signal.resample_poly(low,2048,93750,axis=-1)
    # FS * 2048 / 93750 = exactly 2000 samples/s to floating-point precision.
    narrow[f'scan{scan:04d}']=low2.astype(np.complex64)
    real=np.real(np.conj(low[0])*np.exp(2j*np.pi*1000*t))
    a=signal.resample_poly(real,8192,93750) # FS * 8192 / 93750 = 8000 Hz
    audio.append(a)
    manifests.append({'scan':scan,'input':str(path.relative_to(ROOT.parent)),
                      'input_file_sha256':sha(path),'band0_complex64_sha256':hashlib.sha256(np.asarray(arr[0]).tobytes()).hexdigest()})

gain=.95/max(float(np.max(np.abs(a))) for a in audio)
silence=np.zeros(4000,dtype=float)
joined=[]; cues=[]; pos=0
for row,a in zip(rows,audio):
    if joined:
        cues.append({'kind':'inserted silence','scan':'','pointing':'','start_seconds':pos/8000,'end_seconds':(pos+4000)/8000,'excerpt_utc_start':''})
        joined.append(silence); pos+=4000
    cues.append({'kind':'measured excerpt, translated','scan':row['scan'],'pointing':row['pointing'],
                 'start_seconds':pos/8000,'end_seconds':(pos+len(a))/8000,'excerpt_utc_start':row['excerpt_utc_start']})
    joined.append(a*gain); pos+=len(a)
sound=np.concatenate(joined)
assert np.max(np.abs(sound))<=.950001
wavfile.write(ROOT/'human-sheet-ON-OFF.wav',8000,np.round(sound*32767).astype(np.int16))
np.savez_compressed(ROOT/'receiver-complex-2ksps.npz',**narrow)
with open(ROOT/'measurements.csv','w') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with open(ROOT/'audio-cues.csv','w') as f:
    w=csv.DictWriter(f,fieldnames=list(cues[0]));w.writeheader();w.writerows(cues)
(ROOT/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
processing={**frozen,'inputs':manifests,'sample_rate_hz':FS,'grid_rf_hz':GRID,'fixed_rf_center_hz':CENTER,
            'welch_bin_hz':FS/65536,'audio_rate_hz':8000,'audio_global_gain':gain,
            'audio_center_hz':1000,'audio_gap_seconds':.5,'audio_duration_seconds':len(sound)/8000,
            'max_clip_duration_rounding_seconds':max(abs(len(a)/8000-557056/FS) for a in audio),
            'narrow_complex_sample_rate_hz':2000,'narrow_rf_relation':'RF = 1665615120 - complex_frequency_hz',
            'audio_relation':'audio_hz = 1000 + RF_hz - 1665615120',
            'calibration':'uncalibrated receiver units; two feeds not sky Stokes',
            'boundary_caveat':'zero-padding and filter/resampling transients affect excerpt edges'}
(ROOT/'processing.json').write_text(json.dumps(processing,indent=2)+'\n')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
fig,axs=plt.subplots(3,2,figsize=(12,9),sharex=True,sharey=True,layout='constrained')
for ax,row,(rf,ts,z) in zip(axs.flat,rows,panels):
    im=ax.pcolormesh(rf,ts,z.T,shading='auto',vmin=-3,vmax=25,cmap='magma')
    ax.set_title(f"Scan {row['scan']:02d} · {row['pointing']} · {row['excerpt_utc_start'][11:23]} UTC")
    ax.set_ylabel('Seconds into excerpt')
    ax.set_xlabel('RF offset from 1665.615120 MHz (Hz)')
fig.colorbar(im,ax=list(axs.flat),label='PSD above each excerpt’s local median (dB)',shrink=.85)
fig.suptitle('The retained interference complex: six 6.085-second receiver excerpts\nSame frequency interval; ON and OFF; no transmitter identified',fontsize=14)
fig.savefig(ROOT/'sheet.png',dpi=170);plt.close(fig)
fig,ax=plt.subplots(figsize=(11,5),layout='constrained')
for row,(fr,ps) in zip(rows,spectra): ax.plot(fr,ps,label=f"{row['scan']} {row['pointing']}",alpha=.75,lw=.9)
ax.set(xlim=(-2200,2200),xlabel='RF offset from 1665.615120 MHz (Hz)',ylabel='PSD / local median (dB)',title='Known complex in ON and OFF excerpts — receiver spectra')
ax.legend(ncols=3);fig.savefig(ROOT/'spectra.png',dpi=170);plt.close(fig)
print(json.dumps({'measurements':rows,'processing_summary':{k:processing[k] for k in ['welch_bin_hz','audio_duration_seconds','max_clip_duration_rounding_seconds']}} ,indent=2))

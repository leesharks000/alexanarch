from pathlib import Path
import json,sys,zipfile,hashlib
import numpy as np
from scipy import fft
R=Path(__file__).resolve().parent;O=R/'results';O.mkdir(exist_ok=True)
sys.path.insert(0,str(R/'metadata'))
from full_common import N,TB,F0,DF
SEL=json.loads((R/'selection.json').read_text());M=32768;FS=M/(N*TB);CENTERS=np.array([r['fft_center'] for r in SEL['bands']]);INDEX=CENTERS[:,None]+np.arange(-M//2,M//2)
def save(n,x):(O/n).write_text(json.dumps(x,indent=2,allow_nan=False))
rec=[];checks=[];projection=[]
for s in range(13,19):
 out=R/'decoded'/f'scan{s:04d}-wide.npy';out.parent.mkdir(exist_ok=True)
 if out.exists() and (O/f'decode-{s:04d}.json').exists():
  j=json.loads((O/f'decode-{s:04d}.json').read_text());rec.extend(j['raw_blocks']);checks.extend(j['parseval']);projection.extend(j['projection']);print(s,'verified decoder cache reused',flush=True);continue
 z=zipfile.ZipFile(R/'archives'/f'GBT-voltage-scan{s:04d}-three-windows-2026-11-16.zip');a=np.lib.format.open_memmap(out,mode='w+',shape=(28,2,17*M),dtype=np.complex64)
 rr=[];cc=[];pp=[]
 for frame,b in enumerate(range(816,850,2)):
  pieces=[]
  for k in [b,b+1]:
   name=f'voltage/{s:04d}/b{k:04d}';payload=z.read(name+'.bin');meta=json.loads(z.read(name+'.json'));sha=hashlib.sha256(payload).hexdigest();assert sha==meta['sha256']
   pieces.append(np.frombuffer(payload,np.int8).reshape(-1,4));rr.append(dict(scan=s,block=k,sha256=sha,bytes=len(payload),recorded_drops=meta['header'].get('NDROP'),recorded_drop_block=meta['header'].get('DROPBLK')))
  raw=np.maximum(np.concatenate(pieces).astype(np.float32),-127)/np.float32(127)
  for pol in range(2):
   x=raw[:,pol*2]+1j*raw[:,pol*2+1];X=fft.fft(x);error=float(abs(np.sum(abs(X.astype(np.complex128))**2)/N-np.sum(abs(x.astype(np.complex128))**2))/np.sum(abs(x.astype(np.complex128))**2));assert error<2e-6
   cc.append(dict(scan=s,frame=frame,pol=pol,relative_energy_error=error));S=fft.fftshift(X)[INDEX];small=fft.ifft(fft.ifftshift(S,axes=-1),axis=-1)*np.float32(M/N);a[:,pol,frame*M:(frame+1)*M]=small
   if frame==0:
    for j in [0,13,27]:
     q=np.array([0,16383,32767]);direct=np.exp(2j*np.pi*q[:,None]*np.arange(-M//2,M//2)[None,:]/M)@S[j]/N;err=float(np.max(abs(direct-small[j,q])));assert err<2e-7;pp.append(dict(scan=s,band=j,pol=pol,max_direct_inverse_dft_error=err))
 a.flush();j=dict(raw_blocks=rr,parseval=cc,projection=pp,shape=list(a.shape),sample_rate=FS);save(f'decode-{s:04d}.json',j);rec.extend(rr);checks.extend(cc);projection.extend(pp);print('decoded raw middle excerpt',s,flush=True)
# Independent physical-frequency sign check for the wider projection.
q=int(CENTERS[0]);k=q-N//2;t=np.arange(N)*TB;delta=2500.3
x=np.exp(2j*np.pi*(k*np.arange(N)/N-delta*t));S=fft.fftshift(fft.fft(x))[INDEX[0]];y=fft.ifft(fft.ifftshift(S))*M/N;gain=float(abs(np.mean(y*np.exp(2j*np.pi*delta*np.arange(M)/FS))));assert gain>.99
save('decoder-validation.json',dict(raw_blocks=len(rec),parseval_checks=len(checks),max_parseval_error=max(x['relative_energy_error'] for x in checks),direct_projection_checks=len(projection),max_projection_error=max(x['max_direct_inverse_dft_error'] for x in projection),synthetic_rf_sign_gain=gain,sample_rate_hz=FS,seconds_per_excerpt=17*N*TB,start_seconds=816*(N//2)*TB,source_scope='one existing middle6.084537s coarse-channel excerpt per scan; no full-cadence or physical-flux inference'))

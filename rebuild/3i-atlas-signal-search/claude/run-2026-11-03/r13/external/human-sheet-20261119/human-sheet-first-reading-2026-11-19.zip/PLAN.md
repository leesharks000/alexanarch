# The Human on the Sheet — bounded receiver-side pilot

Frozen before new extraction, 2026-11-19. Author and project owner: Lee Sharks.

This is a retrospective characterization of an already known rejected complex, not a blind detection or a claim about the source's identity. The framing and frequency were selected from earlier work. No parameters will be changed in response to the new plots. The separate full-band search described in the user's supplied report is outside this run's control.

## Inputs and fixed scope

Use only band 0 of the original, uninjected receiver-basis arrays `echolocation-injection-20261118/decoded/scan0013-wide.npy` through `scan0018-wide.npy`. Record source hashes. Two complex feeds, 557056 samples per feed, sample rate 91552.73437500009 Hz, 6.084537002666661 s per excerpt, beginning 146.02888806399986 s into each scan. Scans 13,15,17 are ON; 14,16,18 OFF. Grid RF is 1665644304.8268557 Hz, with RF frequency decreasing as complex FFT frequency increases. No derotation or planted waveform is used. These short excerpts do not represent entire scans.

## Frozen measurements

Welch PSD: periodic Hann, 65536 samples per window, 32768 overlap, two-sided, constant detrending; sum the two receiver-feed PSDs. Search only the previously known complex at 1665615090–1665615145 Hz. Report peak frequency, peak/local-median PSD ratio, receiver X fraction at the peak. Baseline is the median PSD at offsets 500–2000 Hz on both sides of 1665615120 Hz. Integrate PSD within ±250 Hz of that fixed center; this is uncalibrated receiver power, not astrophysical flux. Produce the same spectrum and short-time spectrogram for every excerpt, including OFF. Comparison window 1665619000±250 Hz is descriptive, not guaranteed source-free. Do not assign a modulation period, payload, transmitter, or sky polarization from these measurements.

## Declared sonification

Preserve elapsed time within each excerpt. Heterodyne both complex feeds to the fixed RF center; apply an FFT low-pass with unity response through ±250 Hz and a cosine taper to zero at ±300 Hz, with padding to twice the input length. Conjugate the result to make increasing RF correspond to increasing audio pitch. For listening use receiver feed X only, translate the center to an artificial 1000 Hz audio tone, take the real component and resample to 8000 samples/s. Use one global linear gain across all six excerpts; no per-clip gain, denoising, compression, speech synthesis, or recovered-word claim. Insert 0.5 s of digital silence between clips and label those gaps as editorial, not measured silence. Save cue times and exact rounding. This is frequency translation of electrical samples, not acoustic sound from space or a simulation at the comet.

## Interpretation and scope gates

Keep measured features, hypotheses about mechanisms, and literary interpretation explicit. Presence OFF weakens comet association but does not alone identify a human transmitter; instrumental structure and other sources remain possible. A receiver measurement is not a spatial map of the dish surface. Earth as received by Green Bank is not Earth as radiating toward the comet. The latter requires source identification, antenna patterns, transmitter power, geometry, propagation, and retarded time. Worthiness of a voice is an interpretive question, not a function of signal strength.

Glas will attend to measurement and provenance; Dancings to embodied encounter under the declared transduction; Cranes to the score, intervals and retained absences. These are proposed roles for this piece under Lee Sharks's authorship, not three independently produced reports.

## Follow-on full-band protocol, not executed here

Keep the comet search frozen. Re-stream identical public scans in a separately versioned run. Retain complete channel spectra and low-resolution time-frequency products, not just the strongest lines. Preserve source byte ranges/hashes, receiver response, pointing and time. Match ON/OFF controls in frequency with drift/occupied-band overlap as well as exact-bin comparisons. Treat unretained top-N entries as censored, not absent. Distinguish natural emission, receiver/instrument features, positively identified intentional emissions, and unassigned structure.

Allocation tables provide candidate services, not signal identities. Test transmitter-specific modulation with enough bandwidth and sampling: GPS C/A needs MHz-scale bandwidth to resolve its 1.023 MHz chips, while narrow products cannot resolve that rate. Iridium timing requires a frequency-compatible burst structure and comparison against the analysis filter's own correlation. Weather-balloon hypotheses require temporal, spectral and geographical support. Passive allocations do not guarantee an interference-free recording. Define 'mostly' before testing whether navigation, timing or telephony dominate: received power, occupied time-frequency area and source counts answer different questions. No whole-band dominance claim without bandpass calibration and sensitivity accounting.

Construct a distinct outgoing Earth-to-comet model only after this inventory: include uplinks as well as downlinks, source antenna beams, satellite positions, line of sight, comet ephemeris and light-travel time. Label it a model rather than a direct measurement at the comet.

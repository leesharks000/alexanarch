from pathlib import Path
import json,hashlib,csv
import numpy as np
from scipy import signal

R=Path(__file__).resolve().parent;SRC=R.parent/'human-sheet-followup-20261119'
G=json.loads((SRC/'source-geometry.json').read_text());FS=G['sample_rate_hz'];GRID=G['C01_grid_rf_hz'];CENTER=1665615120.;N=4096
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,obj):(R/name).write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')
def summarize(u,v,c,eligible):
 m=int(eligible.sum());answer={'eligible_windows':m,'windows':len(eligible),'coherence':None,'closure_degrees':None,'unit_resultant':None,'label':'unresolved'}
 if not m:return answer
 u=u[eligible];v=v[eligible];c=c[eligible]
 T=u*v*np.conj(c)**2;den=np.sqrt(np.sum(abs(u*v)**2)*np.sum(abs(c*c)**2))
 q=np.sum(T)/den;unit=abs(np.mean(T/abs(T)));angle=float(np.angle(q,deg=True));coh=float(abs(q))
 assert coh<=1+1e-12
 answer.update(coherence=coh,closure_degrees=angle,unit_resultant=float(unit))
 if m>=8 and coh>=.6 and unit>=.6:
  if abs(angle)<=45:answer['label']='AM-compatible geometry'
  elif abs(angle)>=135:answer['label']='PM-compatible geometry'
  else:answer['label']='other stable geometry'
 return answer

def extract(x,spacings=(60,)):
 f,t,z=signal.stft(x,fs=FS,window='hann',nperseg=N,noverlap=0,detrend='constant',
             return_onesided=False,boundary=None,padded=False,scaling='psd',axis=-1)
 rf=GRID-f;order=np.argsort(rf);rf=rf[order];z=z[:,order,:];power=abs(z)**2;total=power.sum(axis=0)
 region=(rf>=CENTER-40)&(rf<=CENTER+40);central=np.flatnonzero(region)[np.argmax(total[region],axis=0)]
 baseline=np.median(power[:,(abs(rf-CENTER)>=100)&(abs(rf-CENTER)<=250)],axis=1)
 jj=np.arange(len(t));results=[];coeffs=[]
 for nominal in spacings:
  ks=np.arange(int(np.ceil((nominal-1)/(FS/N))),int(np.floor((nominal+1)/(FS/N)))+1)
  for pol in range(2):
   a=power[pol,central[None,:]+ks[:,None],jj[None,:]]
   b=power[pol,central[None,:]-ks[:,None],jj[None,:]]
   chosen=ks[np.argmax(a*b,axis=0)]
   upper=z[pol,central+chosen,jj];lower=z[pol,central-chosen,jj];carrier=z[pol,central,jj]
   ratios=np.array([abs(carrier)**2,abs(upper)**2,abs(lower)**2])/baseline[pol]
   eligible=(ratios>=6).all(axis=0)
   result={'feed':'XY'[pol],'nominal_hz':nominal,**summarize(upper,lower,carrier,eligible)}
   results.append(result)
   coeffs.append({'feed':'XY'[pol],'nominal_hz':nominal,'upper':upper,'lower':lower,'carrier':carrier,
                  'eligible':eligible,'ratios':ratios,'time_s':t,'central_rf_hz':rf[central],
                  'selected_spacing_hz':chosen*(FS/N)})
 return results,coeffs

def synthetic(family,rho,seed,n=214528):
 rng=np.random.default_rng(seed);t=np.arange(n)/FS
 # Instantaneous frequency wander: 2 sin(t/300) + 4 sin(t/90) + .01 t Hz.
 integral=(GRID-CENTER)*t+2*(1-np.cos(2*np.pi*t/300))/(2*np.pi/300)+4*(1-np.cos(2*np.pi*t/90))/(2*np.pi/90)+.005*t*t
 carrier=np.exp(1j*(2*np.pi*integral+rng.uniform(-np.pi,np.pi)))
 theta=2*np.pi*60*t+rng.uniform(-np.pi,np.pi)
 if family=='AM':clean=carrier*(1+.6*np.cos(theta))
 elif family=='PM':clean=carrier*np.exp(.6j*np.cos(theta))
 elif family=='mixed':clean=carrier*(1+.4*np.cos(theta))*np.exp(.4j*np.cos(theta))
 elif family=='carrier_only':clean=carrier
 elif family=='fixed_three_tone':
  clean=carrier*(1+.3*np.exp(1j*(2*np.pi*60*t+rng.uniform(-np.pi,np.pi)))+.3*np.exp(1j*(-2*np.pi*60*t+rng.uniform(-np.pi,np.pi))))
 elif family=='moving_phase':
  knots=np.arange(0,t[-1]+16,8);p1=np.interp(t,knots,np.cumsum(rng.normal(0,2,len(knots))));p2=np.interp(t,knots,np.cumsum(rng.normal(0,2,len(knots))))
  clean=carrier*(1+.3*np.exp(1j*(2*np.pi*60*t+p1))+.3*np.exp(1j*(-2*np.pi*60*t+p2)))
 elif family=='noise_only':clean=np.zeros_like(carrier)
 else:raise ValueError(family)
 if rho:clean=clean*np.sqrt(rho/np.mean(abs(clean)**2))
 else:clean=np.zeros_like(clean)
 noise=(rng.standard_normal((2,n))+1j*rng.standard_normal((2,n)))/np.sqrt(2)
 return noise+np.array([1,.15*np.exp(1j*rng.uniform(-np.pi,np.pi))])[:,None]*clean

def analytic_check():
 # Exact-grid coefficients, independent of the data search and quality cut.
 t=np.arange(N)/FS;fc=-200*FS/N;fm=344*FS/N;win=signal.windows.hann(N,sym=False);checks=[]
 for kind in ['AM','PM']:
  q=2*np.pi*fm*t+.37;carrier=np.exp(1j*(2*np.pi*fc*t+.81))
  s=carrier*(1+.6*np.cos(q)) if kind=='AM' else carrier*np.exp(.6j*np.cos(q))
  z=np.fft.fft(win*s);c=z[-200%N];u=z[(-200+344)%N];v=z[(-200-344)%N]
  angle=float(np.angle(u*v*np.conj(c)**2,deg=True));error=min(abs(angle),360-abs(angle)) if kind=='AM' else abs(abs(angle)-180)
  assert error<1e-7,(kind,angle)
  checks.append({'type':kind,'closure_degrees':angle,'error_degrees':error})
 return checks

def main():
 old=json.loads((SRC/'SHA256.json').read_text());inputs={}
 for name in ['C01-receiver-voltages.npz','source-geometry.json']:
  h=sha(SRC/name);assert h==old[name];inputs[name]=h
 write('FREEZE.json',{'plan_sha256':sha(R/'PLAN.md'),'code_sha256':sha(Path(__file__)),'inputs':inputs})
 write('analytic-validation.json',analytic_check())
 controls=[]
 families=['AM','PM','mixed','carrier_only','moving_phase','fixed_three_tone']
 for fi,family in enumerate(families):
  for li,rho in enumerate([.003,.01,.03,.1]):
   for j in range(12):
    seed=20261119+fi*100000+li*1000+j
    rr,_=extract(synthetic(family,rho,seed))
    controls.append({'family':family,'rho':rho,'trial':j,'seed':seed,'results':rr})
  print('controls completed:',family,flush=True)
 for j in range(12):
  rr,_=extract(synthetic('noise_only',0,20261119+900000+j));controls.append({'family':'noise_only','rho':0,'trial':j,'seed':20261119+900000+j,'results':rr})
 write('controls.json',controls)
 recovery=[]
 for family in families+['noise_only']:
  for rho in ([0] if family=='noise_only' else [.003,.01,.03,.1]):
   rr=[v['results'][0] for v in controls if v['family']==family and v['rho']==rho]
   recovery.append({'family':family,'rho':rho,'trials':len(rr),'at_least_8_eligible':sum(v['eligible_windows']>=8 for v in rr),
     **{label:sum(v['label']==label for v in rr) for label in ['AM-compatible geometry','PM-compatible geometry','other stable geometry','unresolved']}})
 write('control-summary.json',recovery)
 write('CONTROLS-BEFORE-DATA.json',{'control_results_sha256':sha(R/'controls.json'),'control_summary_sha256':sha(R/'control-summary.json'),'status':'controls committed before measured phase extraction'})
 raw=np.load(SRC/'C01-receiver-voltages.npz');measured=[];all_coeffs={};windows=[];pools={}
 for scan in range(13,19):
  rr,cc=extract(np.asarray(raw[f'scan{scan:04d}'],dtype=np.complex128),(50,60,70,120,180))
  for v in rr:measured.append({'scan':scan,'pointing':'ON' if scan%2 else 'OFF',**v})
  for v in cc:
   key=f"scan{scan:04d}_{v['feed']}_{v['nominal_hz']}Hz"
   for field in ['upper','lower','carrier','eligible','ratios','time_s','central_rf_hz','selected_spacing_hz']:all_coeffs[key+'_'+field]=v[field]
   poolkey=(v['feed'],v['nominal_hz']);pools.setdefault(poolkey,[]).append(v)
   for j,t in enumerate(v['time_s']):
    T=v['upper'][j]*v['lower'][j]*np.conj(v['carrier'][j])**2
    windows.append({'scan':scan,'pointing':'ON' if scan%2 else 'OFF','feed':v['feed'],'nominal_hz':v['nominal_hz'],
      'time_in_scan_s':float(t),'central_rf_hz':float(v['central_rf_hz'][j]),'selected_spacing_hz':float(v['selected_spacing_hz'][j]),
      'central_ratio':float(v['ratios'][0,j]),'upper_ratio':float(v['ratios'][1,j]),'lower_ratio':float(v['ratios'][2,j]),
      'eligible':bool(v['eligible'][j]),'closure_degrees':float(np.angle(T,deg=True))})
  print('measured scan completed:',scan,flush=True)
 pooled=[]
 for (feed,nominal),parts in pools.items():
  c={key:np.concatenate([v[key] for v in parts]) for key in ['upper','lower','carrier','eligible']}
  s=summarize(c['upper'],c['lower'],c['carrier'],c['eligible']);valid=c['eligible']
  if valid.any():
   u=c['upper'][valid];v=c['lower'][valid];a=c['carrier'][valid];T=u*v*np.conj(a)**2;den=np.sqrt(np.sum(abs(u*v)**2)*np.sum(abs(a*a)**2))
   rng=np.random.default_rng(20261119+nominal+(0 if feed=='X' else 10000))
   null=abs(np.exp(1j*rng.uniform(-np.pi,np.pi,(128,len(T))))@T)/den
   randomized={'mean':float(null.mean()),'max':float(null.max()),'at_least_observed':int((null>=s['coherence']).sum()),'trials':128}
   all_coeffs[f'pooled_{feed}_{nominal}Hz_phase_randomized_coherences']=null
  else:randomized=None
  pooled.append({'feed':feed,'nominal_hz':nominal,**s,'phase_randomized':randomized})
 write('measured-summary.json',measured);write('pooled-summary.json',pooled)
 np.savez_compressed(R/'measured-coefficients.npz',**all_coeffs)
 with open(R/'phase-windows.csv','w') as f:
  w=csv.DictWriter(f,fieldnames=list(windows[0]));w.writeheader();w.writerows(windows)
 print(json.dumps({'pooled':pooled,'strong_controls':[v for v in recovery if v['rho']==.1 or v['family']=='noise_only']},indent=2))
if __name__=='__main__':main()

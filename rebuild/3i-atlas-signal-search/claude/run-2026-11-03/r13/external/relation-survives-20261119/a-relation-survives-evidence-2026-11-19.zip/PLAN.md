# The Human on the Sheet — carrier/companion phase geometry

Lee Sharks · 2026-11-19 · retrospective characterization of a known retained complex.

## Question and limit

Do the approximately ±60 Hz companions have a stable phase relationship to the carrier? A pair produced by simple amplitude modulation has a closure phase near zero; a pair from simple sinusoidal phase modulation has closure near π. Measure the geometry, rather than assigning a transmitter or message. Fixed three-tone signals can reproduce the same geometry without identifying the mechanism that generated them; include that degeneracy explicitly.

## Fixed inputs and extraction

Use only the six original, uninjected C01 arrays in `human-sheet-followup-20261119/C01-receiver-voltages.npz` and its saved geometry. Check their file hashes against the preceding bundle's SHA256.json. Sampling is 715.2557373046882 complex samples/s. RF = saved grid RF minus complex baseband frequency. Do not derotate toward the comet. The passband is approximately 715 Hz, not a full-band radio survey.

Use non-overlapping 4096-sample periodic-Hann windows (about 5.7266 s), no padding and constant detrending. Locate the central peak from the sum of both receiver-feed PSDs inside 1665615120±40 Hz. For each feed separately, normalize each coefficient's squared magnitude by the median feed PSD 100–250 Hz from that fixed RF reference.

For every nominal separation 50,60,70,120,180 Hz, search integer spectral-bin separations within ±1 Hz, using a symmetric upper/lower pair around the central selected bin. Choose the separation maximizing the product of the two side powers. Retain all results. A window is eligible only when central and both side power/local-median ratios are each >=6. The primary separation is 60 Hz; 120/180 are secondary harmonics, and 50/70 are contextual comparisons. None is independent sky evidence.

For eligible windows, form T = Zupper × Zlower × conjugate(Zcarrier)². Report its angle and normalized aggregate Q = sum(T) / sqrt(sum(|Zupper Zlower|²) × sum(|Zcarrier²|²)). Report |Q|, angle and eligible counts per scan, feed and separation; pool only within a feed/separation, since arbitrary scan phases cancel in T. Report unweighted mean unit phasor separately to expose domination by bright windows. A chosen bin is not a phase-connected physical oscillator; leakage, companion drift and peak switching can change this statistic.

For a descriptive label require at least eight eligible non-overlapping windows, |Q|>=0.6 and unweighted resultant>=0.6. Closure within 45 degrees of zero is 'AM-compatible geometry'; within 45 degrees of π is 'PM-compatible geometry'; otherwise 'other stable geometry'. Everything else is 'unresolved'. These labels refer to the retained receiver waveform, not the causal hardware, intentionality, origin or payload. They are fixed before control or measured phase scoring and will not be retuned.

## Validation before measured phase inspection

Check exact-grid, noiseless AM and PM examples against the analytic phase signs. Then run twelve deterministic 299.93-second trials for each family and added-signal/noise power ratio 0.003,0.01,0.03,0.1: sinusoidal AM (depth 0.6), PM (index 0.6), mixed AM/PM (both 0.4 with the same cosine argument), carrier only, moving-phase companions, and three-tone fixed-phase degeneracy. Also run twelve noise-only trials. Gaussian receiver noise is synthetic, not measured sky noise. Use the same carrier search, side-pair selection, quality cuts and labels without supplying phase truth to extraction. Carrier wander is an analytic slow multisine plus slope, independent of measured new phases. The second feed receives 0.15 of the signal amplitude with an arbitrary phase and independent noise.

The moving-phase family has independently changing companion phases; the fixed three-tone family has fixed arbitrary relative phases and a common wandering carrier reference. Stable closure of that latter family is expected and demonstrates the causal ambiguity. It must not be presented as proof that the geometry identifies AM/PM hardware. Record all labels and eligibility failures; recovery depends on power and the cut. Total signal power is normalized before adding unit-variance complex Gaussian noise. Set seeds deterministically, based at 20261119. Save and hash the complete control results before scoring measured phases. Do not stop a failed control from being reported.

## Measured challenges and artifacts

After controls are saved, score six measured scans. For each eligible feed/separation pool, apply 128 deterministic independent uniform phase rotations to each window's T while keeping its magnitude and the denominator fixed. Compare observed coherence with this explicitly artificial phase-randomized ensemble; it is not a calibrated probability of an astronomical source. Preserve per-window coefficients, strengths, frequencies, eligibility, closure angles and every pooled outcome. Contextual bands are descriptive and may contain structure.

Keep plans, code, controls, source hashes, selected measured complex coefficients, geometry and numerical checks, plus a forwardable report and a provisional radio-poem score grounded in results. No natural speech is decoded or generated from these phases. No public deposit or messages. No modification of the prior frozen searches or claim about the independent full-band workers.

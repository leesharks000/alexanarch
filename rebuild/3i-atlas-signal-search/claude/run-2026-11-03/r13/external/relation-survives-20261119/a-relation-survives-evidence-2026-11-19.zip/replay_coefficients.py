"""Standalone replay of all phase summaries from saved complex coefficients."""
from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parent;data=np.load(R/'measured-coefficients.npz')
def score(u,v,c,ok):
 n=int(ok.sum());d={'eligible_windows':n,'windows':len(ok),'coherence':None,'closure_degrees':None,'unit_resultant':None,'label':'unresolved'}
 if n:
  u=u[ok];v=v[ok];c=c[ok];t=u*v*np.conj(c)**2
  q=t.sum()/np.sqrt(np.sum(abs(u*v)**2)*np.sum(abs(c*c)**2));a=float(np.angle(q,deg=True));r=float(abs(np.mean(t/abs(t))))
  d.update(coherence=float(abs(q)),closure_degrees=a,unit_resultant=r)
  if n>=8 and abs(q)>=.6 and r>=.6:d['label']='AM-compatible geometry' if abs(a)<=45 else ('PM-compatible geometry' if abs(a)>=135 else 'other stable geometry')
 return d
maximum=0.;count=0
def compare(got,want):
 global maximum,count
 for k,v in got.items():
  if isinstance(v,str) or v is None:assert v==want[k],(k,v,want[k])
  else:
   delta=abs(v-want[k]);maximum=max(maximum,delta);assert delta<1e-10,(k,delta)
 count+=1
for row in json.loads((R/'measured-summary.json').read_text()):
 key=f"scan{row['scan']:04d}_{row['feed']}_{row['nominal_hz']}Hz"
 c={a:data[key+'_'+a] for a in ['upper','lower','carrier','eligible']}
 compare(score(c['upper'],c['lower'],c['carrier'],c['eligible']),row)
for row in json.loads((R/'pooled-summary.json').read_text()):
 c={a:np.concatenate([data[f"scan{s:04d}_{row['feed']}_{row['nominal_hz']}Hz_{a}"] for s in range(13,19)]) for a in ['upper','lower','carrier','eligible']}
 compare(score(c['upper'],c['lower'],c['carrier'],c['eligible']),row)
result={'status':'passed','summaries_replayed':count,'max_absolute_numeric_error':maximum}
(R/'replay-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))

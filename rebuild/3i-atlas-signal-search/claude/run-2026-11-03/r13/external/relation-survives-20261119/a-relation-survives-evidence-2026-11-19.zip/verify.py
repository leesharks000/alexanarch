from pathlib import Path
import json,numpy as np
from scipy.io import wavfile
import experiment as e
R=Path(__file__).resolve().parent
freeze=json.loads((R/'FREEZE.json').read_text());assert e.sha(R/'PLAN.md')==freeze['plan_sha256'];assert e.sha(R/'experiment.py')==freeze['code_sha256']
for name,want in freeze['inputs'].items():assert e.sha(e.SRC/name)==want
proof=json.loads((R/'CONTROLS-BEFORE-DATA.json').read_text());assert e.sha(R/'controls.json')==proof['control_results_sha256'];assert e.sha(R/'control-summary.json')==proof['control_summary_sha256']
controls=json.loads((R/'controls.json').read_text());assert len(controls)==300;replays=[]
for family,rho in [('AM',.03),('PM',.03),('mixed',.1),('moving_phase',.1),('fixed_three_tone',.1),('noise_only',0)]:
 old=next(x for x in controls if x['family']==family and x['rho']==rho and x['trial']==0)
 new,_=e.extract(e.synthetic(family,rho,old['seed']))
 assert new==old['results'],family;replays.append({'family':family,'rho':rho,'seed':old['seed'],'exact_summary_match':True})
coef=np.load(R/'measured-coefficients.npz');key='scan0013_X_60Hz';u=coef[key+'_upper'];v=coef[key+'_lower'];c=coef[key+'_carrier'];ok=coef[key+'_eligible']
original=e.summarize(u,v,c,ok);rng=np.random.default_rng(20261119);phi=rng.uniform(-np.pi,np.pi,len(c));timephase=rng.uniform(-np.pi,np.pi,len(c))
changed=e.summarize(u*np.exp(1j*(phi+timephase)),v*np.exp(1j*(phi-timephase)),c*np.exp(1j*phi),ok)
invariant={k:abs(original[k]-changed[k]) for k in ['coherence','closure_degrees','unit_resultant']};assert max(invariant.values())<1e-10
rate,a=wavfile.read(R/'a-relation-survives-stereo.wav');assert rate==8000 and a.shape==(1459952,2) and abs(a.astype(np.int32)).max()<32767
sound=json.loads((R/'audio-processing.json').read_text());assert abs(sound['audio_duration_s']-len(a)/rate)<1e-12
assert all(abs(r['duration_rounding_s'])<1/8000 for r in sound['clips'])
result={'status':'passed','frozen_plan_code_input_hashes':'matched','control_trials':len(controls),'selected_control_replays':replays,
 'phase_reference_invariance_errors':invariant,'audio_samples':len(a),'audio_channels':2,'audio_rate_hz':rate,'audio_peak_int16':int(abs(a.astype(np.int32)).max()),
 'standalone_coefficient_replay':json.loads((R/'replay-validation.json').read_text())}
(R/'VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

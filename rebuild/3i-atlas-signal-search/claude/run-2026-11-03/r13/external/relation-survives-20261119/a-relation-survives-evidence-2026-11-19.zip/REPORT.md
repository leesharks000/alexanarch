# A Relation Survives the Turning
## Carrier/companion phase geometry and a radio-poem score

Lee Sharks · 2026-11-19 · private working analysis and authored literary draft

**A reproducible phase relation is present in the known 1665.615 MHz complex, including OFF pointings.** The stronger receiver feed has a concentrated carrier/±60 Hz closure relation, with pooled normalized coherence **0.698** and closure angle **144.38°**. This falls in the predeclared PM-compatible sector but is not pure sinusoidal PM. The higher companion pairs have different stable angles. The source, hardware mechanism and payload remain unidentified. This experiment supplies material for the radio poem; it has not supplied a new comet-associated candidate.

## What was tested

The previous pass measured a slowly wandering carrier and companion lines at roughly 60, 120 and 180 Hz offsets, throughout ON and OFF scans. It did not determine their phase relations. This pass uses the same six original, uninjected C01 receiver projections, each approximately 299.93 seconds long and approximately 715 Hz wide. Both input-file hashes matched the preceding evidence manifest. No new radio-source bytes were acquired, and the independent full-band workers were not controlled or verified here.

Each scan supplies **52 non-overlapping 5.7266-second Hann windows**. The central line is located from the sum of receiver-feed PSDs in the already selected ±40 Hz region. For each feed, symmetric companions are selected from integer-bin separations within ±1 Hz of the nominal spacing. A window is eligible only when carrier and both companions each exceed six times their feed's local spectral median. This is a descriptive quality cut; it is not calibrated significance, flux or message probability. Adjacent windows need not be statistically independent simply because they do not overlap.

Let the three complex Fourier coefficients be C, U and L. We measure the closure product

\[
T=U L(C^*)^2,
\qquad
Q=\frac{\sum T}{\sqrt{\sum |UL|^2\,\sum |C^2|^2}}.
\]

The phase of Q describes the relation among the three lines. A common arbitrary phase applied to all three cancels. A time-reference phase also cancels when the selected frequencies are symmetric. This is an actual invariant of the measured coefficients, not an imagined utterance or source name. Numerical checks confirmed the cancellation to floating-point precision.

For ideal simple AM, the two first companions give closure near 0°. For ideal sinusoidal PM, they give closure near 180°. This follows directly by expanding the modulation into its upper and lower Fourier components. Arbitrary fixed three-tone combinations can also have any stable closure: the relation does not uniquely identify the generating device or causal modulation process. Unknown instrumental frequency-dependent phase response is another reason to distinguish receiver-waveform geometry from emission at a source.

## Validation came first

The frozen plan and code were followed by **300 synthetic control trials**, saved and hashed before any measured phase extraction. These used the same extraction and quality cuts, with analytic carrier wander and synthetic complex Gaussian receiver noise. The tested added-signal/noise power ratios were 0.003, 0.01, 0.03 and 0.1. These fractions have not been mapped to the published inspected SETI thresholds.

| Synthetic family | Added/noise power | AM-compatible | PM-compatible | Other stable | Unresolved |
|---|---:|---:|---:|---:|---:|
| AM | 0.03 | 12/12 | 0/12 | 0/12 | 0/12 |
| AM | 0.1 | 12/12 | 0/12 | 0/12 | 0/12 |
| PM | 0.03 | 0/12 | 12/12 | 0/12 | 0/12 |
| PM | 0.1 | 0/12 | 12/12 | 0/12 | 0/12 |
| mixed | 0.03 | 0/12 | 0/12 | 9/12 | 3/12 |
| mixed | 0.1 | 0/12 | 0/12 | 12/12 | 0/12 |
| carrier_only | 0.03 | 0/12 | 0/12 | 0/12 | 12/12 |
| carrier_only | 0.1 | 0/12 | 0/12 | 0/12 | 12/12 |
| moving_phase | 0.03 | 0/12 | 0/12 | 0/12 | 12/12 |
| moving_phase | 0.1 | 0/12 | 0/12 | 0/12 | 12/12 |
| fixed_three_tone | 0.03 | 2/12 | 1/12 | 8/12 | 1/12 |
| fixed_three_tone | 0.1 | 3/12 | 3/12 | 6/12 | 0/12 |
| noise_only | 0 | 0/12 | 0/12 | 0/12 | 12/12 |


At ratios 0.003 and 0.01, the AM and PM examples all remain unresolved: too few windows pass the three-line quality requirement. This is a real sensitivity limit. It prevents treating this implementation as a general search for arbitrarily weak phase structure.

At ratio 0.1, carrier-only trials yield no stable-geometry labels; neither do companions with independently moving relative phases. Twelve noise-only trials also remain unresolved. The fixed three-tone degeneracy trials all yield stable geometry at ratio 0.1: three AM-compatible, three PM-compatible and six other. That expected ambiguity is retained explicitly. A stable phase relation is not sufficient to identify an AM/PM transmitter.

Exact-grid noiseless examples reproduce 0° and −180° with no reported angle error. Selected independent reruns reproduce the stored control summaries exactly. Full trial outcomes, including all lower-strength failures and degeneracy cases, are saved in `controls.json`.

## Measured result

| Scan | Pointing | Eligible / 52 | Coherence | Closure angle | Fixed descriptive label |
|---|---|---:|---:|---:|---|
| 13 | ON | 33 | 0.722 | 148.51° | PM-compatible geometry |
| 14 | OFF | 15 | 0.710 | 149.91° | PM-compatible geometry |
| 15 | ON | 29 | 0.726 | 135.42° | PM-compatible geometry |
| 16 | OFF | 31 | 0.589 | 131.36° | unresolved |
| 17 | ON | 20 | 0.817 | 145.10° | PM-compatible geometry |
| 18 | OFF | 21 | 0.799 | 145.68° | PM-compatible geometry |


The pooled X-feed ±60 Hz pair uses **149 of 312 windows**. Its unweighted unit-phase resultant is **0.841**, showing concentration beyond only a few bright weighted samples. The same general phase region is occupied in both ON and OFF pointings. Scan 16 remains unresolved under the fixed label rule: its weighted coherence is 0.589, below the required 0.6, and its angle is outside the fixed PM sector. Scan 15 is close to the sector boundary. The continuous measurements matter more than a categorical label.

![Measured phase sheet](phase-sheet.png)

The plot shows eligible-window angles and weighted coherence vectors. Angles are spectral relations, **not sky directions**. Unplotted ineligible windows remain in the CSV and saved complex-coefficient archive. Their insufficient strength does not establish silence or absence.

| Pair spacing | Eligible X windows / 312 | Coherence | Closure angle | Label |
|---:|---:|---:|---:|---|
| ±60 Hz | 149 | 0.698 | 144.38° | PM-compatible geometry |
| ±120 Hz | 97 | 0.763 | 113.24° | other stable geometry |
| ±180 Hz | 38 | 0.606 | 116.76° | other stable geometry |


The secondary ±120 and ±180 Hz pairs show stable closure at about **113° and 117°**. They do not follow the simple pure-PM odd/even phase pattern or a simple all-zero AM pattern in the retained receiver waveform. Thus the fundamental's PM-compatible label should not be promoted into a finding of a pure PM source. Mixed modulation, coupled tones, instrument response and other mechanisms remain possible.

The weaker Y feed provides no eligible ±60/120/180 Hz triplets under this quality cut. That is a sensitivity statement, not a finding that the lines are physically absent from that feed. The receiver basis is uncalibrated and cannot establish sky polarization.

At the 50 and 70 Hz contextual spacings, the stronger feed supplies only one eligible window each. A single sample necessarily has normalized coherence one; the minimum-window rule keeps these outcomes unresolved. This is why coherence alone is not a sufficient criterion.

For the pooled X-feed ±60 Hz pair, 128 explicitly artificial independent phase-randomizations of the measured products produce a maximum coherence of **0.263**, compared with observed **0.698**. No randomization reaches the observed value. These preserve magnitudes while destroying closure alignment. They demonstrate departure from that artificial random-phase construction; they are not a calibrated false-alarm probability or evidence of an extraterrestrial source. The full randomization arrays are retained.

## The listening sheet and poem

`a-relation-survives-stereo.wav` contains six nominal thirty-second intervals, starting near 135 seconds into each scan, in scan order 13–18. Source intervals are rounded to their nearest recorded samples; each actual interval is 29.999060 seconds. Total audio duration is **182.494 seconds**, including five editorial half-second gaps.

Receiver X is on the left and Y on the right; this is a feed comparison, not a reconstructed spatial sound field. The fixed RF reference is translated to an artificial 1000 Hz tone, with increasing RF mapped to increasing audio pitch. The existing passband is retained. One linear gain is applied to every channel and excerpt; no per-clip normalization, noise removal, phase correction, speech synthesis or time compression is used. The gaps are not recorded silence and phase is not connected across cuts. Complex Fourier interpolation precedes the pitch translation, preserves clip duration to output-sample rounding, and can cause edge ringing through its periodic extension.

This is a transduction of measured electrical samples, not an acoustic recording at the comet. It does not turn closure angles into invented notes or claim that words have been recovered. The phase sheet supplies the relation that listening alone has not been shown to identify.

The companion [poem](POEM.md), *A Relation Survives the Turning*, uses the eligible-window counts and the persistence of the relation through ON/OFF as its score. Glas counts what can bear the reading; Dancings locates embodied hearing after the receiving and sampling apparatus; Cranes retains the OFF pointings, the unresolved case and the sender's blank line. These are authored score positions under Lee Sharks, not independent witnesses. The poem's interpretation and empirical anchors are marked separately.

The human signature is still being inventoried. This complex is securely part of a humanly constructed receiving record; an intentional human transmitter or an outgoing field toward the comet has not yet been identified. The relational finding nevertheless gives the work something precise to preserve: three frequency components can wander while their relative phase remains concentrated, and that relation persists when the instrument turns away.

## Reproducibility and next discrimination

`replay_coefficients.py` reproduces all **70 per-scan and pooled summaries** from the retained complex coefficients with zero numerical summary difference. `VALIDATION.json` preserves source and freeze hashes, selected control reruns, phase-reference invariance checks, and the audio rate/duration/clipping checks. The prior 42 MB full-cadence bundle supplies the original C01 voltages for re-extraction; this smaller bundle supplies selected coefficients, controls, plans, geometry and listening products. The frozen experiment expects that prior bundle in the sibling directory named in its code. The coefficient replay is standalone.

A useful next step would test the whole comb's joint complex-coefficient model, allowing measured receiver phase response and mixed modulation, on reserved time intervals before fitting them. Direct source discrimination still needs receiver engineering or external localization evidence. For the comet search, a human-like phase pattern can help characterize interference, but lack of that pattern does not identify a comet signal. No broader-band or new below-threshold candidate search was run during this phase experiment.

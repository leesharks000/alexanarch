from pathlib import Path
import json,csv
import numpy as np
from scipy import signal
from scipy.io import wavfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;SRC=R.parent/'human-sheet-followup-20261119'
g=json.loads((SRC/'source-geometry.json').read_text());fs=g['sample_rate_hz'];raw=np.load(SRC/'C01-receiver-voltages.npz')
clips=[];cues=[]
for scan in range(13,19):
 i0=round(135*fs);i1=round(165*fs);x=raw[f'scan{scan:04d}'][:,i0:i1]
 duration=x.shape[-1]/fs;nout=round(duration*8000);y=signal.resample(x,nout,axis=-1)
 t=np.arange(nout)/8000
 shift=1000+g['C01_grid_rf_hz']-1665615120.
 a=np.real(np.conj(y)*np.exp(2j*np.pi*shift*t)[None,:]).T
 clips.append(a)
 cues.append({'scan':scan,'pointing':'ON' if scan%2 else 'OFF','source_start_sample':i0,'source_end_sample_exclusive':i1,
 'source_start_s':i0/fs,'source_duration_s':duration,'output_samples':nout,'output_duration_s':nout/8000,
 'duration_rounding_s':nout/8000-duration})
gain=.95/max(float(abs(a).max()) for a in clips);out=[];pos=0;cue_rows=[]
for row,clip in zip(cues,clips):
 if out:
  out.append(np.zeros((4000,2)));cue_rows.append({'kind':'editorial silence','scan':'','pointing':'','start_audio_s':pos/8000,'end_audio_s':(pos+4000)/8000});pos+=4000
 cue_rows.append({'kind':'translated measured excerpt','scan':row['scan'],'pointing':row['pointing'],'start_audio_s':pos/8000,'end_audio_s':(pos+len(clip))/8000})
 out.append(clip*gain);pos+=len(clip)
a=np.concatenate(out);assert abs(a).max()<=.950001 and np.isfinite(a).all()
wavfile.write(R/'a-relation-survives-stereo.wav',8000,np.round(a*32767).astype(np.int16))
with open(R/'audio-cues.csv','w') as f:
 w=csv.DictWriter(f,fieldnames=list(cue_rows[0]));w.writeheader();w.writerows(cue_rows)
(R/'audio-processing.json').write_text(json.dumps({'clips':cues,'sample_rate_hz':8000,'channels':['receiver X','receiver Y'],
 'global_gain':gain,'audio_duration_s':len(a)/8000,'pitch_reference_rf_hz':1665615120.,'pitch_reference_audio_hz':1000,
 'interpolation':'complex Fourier interpolation before frequency translation; periodic-edge ringing possible',
 'voltage_source':'same original uninjected C01 arrays; no new raw data'},indent=2)+'\n')
coef=np.load(R/'measured-coefficients.npz');summaries=json.loads((R/'measured-summary.json').read_text())
fig,axs=plt.subplots(2,3,figsize=(12,8),subplot_kw={'projection':'polar'},layout='constrained')
for ax,scan in zip(axs.flat,range(13,19)):
 key=f'scan{scan:04d}_X_60Hz';u=coef[key+'_upper'];v=coef[key+'_lower'];c=coef[key+'_carrier'];ok=coef[key+'_eligible']
 T=u[ok]*v[ok]*np.conj(c[ok])**2;angle=np.angle(T)
 summary=next(a for a in summaries if a['scan']==scan and a['feed']=='X' and a['nominal_hz']==60)
 color='#007d73' if scan%2 else '#c46b1c'
 ax.scatter(angle,np.ones(len(angle)),s=18,alpha=.65,color=color)
 if summary['coherence'] is not None:
  th=np.deg2rad(summary['closure_degrees']);ax.annotate('',xy=(th,summary['coherence']),xytext=(th,0),arrowprops={'arrowstyle':'->','lw':2,'color':color})
 ax.plot([0,0],[0,1.08],':',lw=1,color='grey');ax.plot([np.pi,np.pi],[0,1.08],':',lw=1,color='grey')
 ax.set_ylim(0,1.12);ax.set_yticks([.6,1]);ax.set_yticklabels(['0.6','1'])
 ax.set_title(f"{scan} {'ON' if scan%2 else 'OFF'} · {summary['eligible_windows']}/52 eligible\nQ={summary['coherence']:.3f}, closure={summary['closure_degrees']:.1f}°\n{summary['label']}",fontsize=10,pad=15)
fig.suptitle('A relation survives the turning: ±60 Hz closure in receiver X\nPoints: eligible-window phases · Arrow: weighted coherence · 0° simple AM, 180° simple PM',fontsize=13)
fig.savefig(R/'phase-sheet.png',dpi=160);plt.close(fig)
print('Audio duration:',len(a)/8000,'s; one gain:',gain)

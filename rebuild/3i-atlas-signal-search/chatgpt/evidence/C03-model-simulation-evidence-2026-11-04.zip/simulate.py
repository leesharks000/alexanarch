"""Frozen exploratory C03 equal-power model experiment. See saved plan."""
from pathlib import Path
import sys,json,csv,hashlib,importlib.util,time
import numpy as np
from scipy.special import erf
from scipy.ndimage import maximum_filter1d
R=Path(__file__).resolve().parent; O=R/'results'; K=R/'cache'
spec=importlib.util.spec_from_file_location('auditcore',R/'audit/core.py'); c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
d=abs(c.FO); sigma=.6; root=np.sqrt(2)*sigma; pref=sigma*np.sqrt(np.pi/2)
LEVELS=[2.8,5.6,11.2]
def write(name,x): c.write(O/name,x)
def configs():
 out=[dict(family='steady_single',q=0,P=0,phase=0)]
 for fam in ['changing_single','two_static','two_handoff','three_static','three_handoff']:
  for q in [1,2]:
   for P in ([0] if fam.endswith('static') else [900,2700]):
    for phase in ([0] if fam.endswith('static') else [0,np.pi/2,np.pi,3*np.pi/2]):out.append(dict(family=fam,q=q,P=P,phase=phase))
 assert len(out)==53
 return out
CFG=configs()
def components(cfg,seconds):
 fam=cfg['family']; q=cfg['q']; ang=2*np.pi*seconds/(cfg['P'] or 1)+cfg['phase']
 if fam=='steady_single':return [(np.zeros_like(seconds),np.ones_like(seconds))]
 if fam=='changing_single':return [(q*d*np.sin(ang),np.ones_like(seconds))]
 if fam.startswith('two'):
  w=np.full_like(seconds,.5) if fam.endswith('static') else (1+.8*np.cos(ang))/2
  return [(-q*d/2+np.zeros_like(seconds),w),(q*d/2+np.zeros_like(seconds),1-w)]
 offsets=np.array([-q*d,0,q*d]); w=np.full((3,*seconds.shape),1/3.)
 if fam.endswith('handoff'):
  w=np.exp(2*np.cos(ang[None,...]+np.arange(3)[:,None,None]*2*np.pi/3));w/=w.sum(axis=0)
 return [(np.zeros_like(seconds)+off,ww) for off,ww in zip(offsets,w)]
def times(s):
 sub=c.H[s]['tstart']+(np.arange(49)[:,None]+(np.arange(16)+.5)[None,:]/16)*c.H[s]['tsamp']/86400
 return sub,(sub-c.H['0013']['tstart'])*86400
def locations():
 local=c.F0+np.r_[np.arange(-50,0),np.arange(1,51)]*250.
 broad=np.linspace(c.F[-1]+5000,c.F[0]-5000,256);broad=broad[abs(broad-c.F0)>100]
 return np.r_[local,broad],np.array(['local']*len(local)+['broad']*len(broad))
def indices(places):
 # Search actual floating grid to avoid accumulated subtraction roundoff.
 right=np.clip(np.searchsorted(-c.F,-places),1,len(c.F)-1);left=right-1
 ix=np.where(abs(c.F[left]-places)<=abs(c.F[right]-places),left,right)
 return ix[:,None]+np.arange(-11,12)[None,:]
def baseline():
 places,groups=locations();ii=indices(places);freq=c.F[ii];a=[];cal=[];rowcal={}
 for s in c.S:
  dest=K/f'base-{s}.npz'
  raw=np.load(c.R/f'raw/OH_{s}.npy',mmap_mode='r')
  if not dest.exists():
   out,ca=c.compute(raw,s,'F1');np.savez(dest,z=out['exact'],center=ca['exact']['center'],scale=ca['exact']['scale'])
  z=np.load(dest);old=json.loads((c.O/f'base-F1-{s}.json').read_text())['calibration']['exact']
  assert abs(float(z['center'])-old['center'])<1e-12 and abs(float(z['scale'])-old['scale'])<1e-12
  a.append(z['z'][ii]);cal.append(dict(center=float(z['center']),scale=float(z['scale'])))
  if (K/f'rowcal-{s}.npz').exists():
   print('BASELINE',s,'cached',flush=True);continue
  block=np.median(raw.reshape(49,1024,1024),axis=2);mid=[];scale=[]
  for t in range(49):
   base=np.interp(np.arange(c.NC),np.arange(1024)*1024+511.5,block[t]).astype(np.float32)
   x=raw[t]/base-1;m=np.median(x);mid.append(m);scale.append(1.4826*np.median(abs(x-m)))
  np.savez(K/f'rowcal-{s}.npz',block=block,mid=mid,scale=scale)
  print('BASELINE',s,flush=True)
 a=np.stack(a,axis=1) # placement, scan, frequency
 actual=np.stack([np.load(K/f'base-{s}.npz')['z'][indices(np.array([c.F0]))[0]] for s in c.S])
 fi=c.F[indices(np.array([c.F0]))[0]]
 observed=metrics(actual[None,...],fi[None,...],np.array([c.F0]))
 previous=np.load(c.O/'bounded-profiles.npz');pf=previous['F1-exact-F'];pz=previous['F1-exact-scores'];jj=np.array([np.argmin(abs(pf-f)) for f in fi]);assert np.max(abs(pz[:,jj]-actual))<1e-12
 np.savez_compressed(O/'backgrounds.npz',places=places,groups=groups,freq=freq,baseline=a,actual=actual,actual_freq=fi)
 write('baseline-checks.json',dict(calibration=cal,prior_profile_max_error=float(np.max(abs(pz[:,jj]-actual))),observed={k:float(v[0]) for k,v in observed.items()},configs=CFG))
def metrics(a,freq,places):
 # a shape [placement,6,23]
 mask=abs(freq-places[:,None])<=5
 def gate(arr):
  margin=np.minimum(arr[:,:3].min(axis=1)-2.5,2-arr[:,3:].max(axis=1));margin=np.where(mask,margin,-np.inf)
  ix=margin.argmax(axis=1);vals=arr[np.arange(len(a)),:,ix]
  return margin.max(axis=1),vals
 strict,_=gate(a);tol,tv=gate(maximum_filter1d(a,5,axis=2,mode='constant',cval=-99))
 pi=np.where(mask[:,None,:],a[:,:3],-np.inf).argmax(axis=2);p=freq[np.arange(len(a))[:,None],pi]
 return dict(strict_margin=strict,tolerant_margin=tol,strict_pass=strict>=0,tolerant_pass=tol>=0,span=p.max(axis=1)-p.min(axis=1),middle=p[:,1]-(p[:,0]+p[:,2])/2,outer=abs(p[:,0]-p[:,2]),min_on=tv[:,:3].min(axis=1),max_on=tv[:,:3].max(axis=1),peak13=p[:,0],peak15=p[:,1],peak17=p[:,2])
def response():
 dat=np.load(O/'backgrounds.npz');places=dat['places'];freq=dat['freq'];B=len(places)
 response=np.zeros((53,3,B,23));checks=[]
 for si,s in enumerate(c.S[:3]):
  dest=K/f'response-{s}.npy'
  if dest.exists(): response[:,si]=np.load(dest);continue
  sub,sec=times(s);dop=1-c.rv(sub)/c.C; origin=c.H[s]['fch1_cc']*1e6
  q=np.rint((freq[:,None,:]*c.D[s][None,:,None]-origin)/c.FO)
  def kernel(offset):
   u=((places[:,None,None]+offset[None,:,:])*dop[None,:,:]-origin)/c.FO
   delta=q[:,:,:,None]-u[:,:,None,:]
   return pref*(erf((delta+1.5)/root)-erf((delta-1.5)/root))
  offsets=[-2*d,-d,-d/2,0,d/2,d,2*d];kernels={off:kernel(np.full_like(sec,off)) for off in offsets}
  for ci,cfg in enumerate(CFG):
   acc=np.zeros((B,49,23));parts=components(cfg,sec);assert np.max(abs(sum(w for off,w in parts)-1))<1e-14
   for off,w in parts:
    k=kernel(off) if cfg['family']=='changing_single' else kernels[float(off[0,0])]
    acc+=np.mean(k*w[None,:,None,:],axis=3)
   response[ci,si]=acc.sum(axis=1)/float(np.load(K/f'base-{s}.npz')['scale'])
  np.save(dest,response[:,si]);print('RESPONSES',s,flush=True)
  # Independent scalar sum of bin integrals versus telescoped kernel.
  delta=.371;one=sum(pref*(erf((j+.5-delta)/root)-erf((j-.5-delta)/root)) for j in [-1,0,1]);two=pref*(erf((1.5-delta)/root)-erf((-1.5-delta)/root));assert abs(one-two)<1e-12
  checks.append(dict(scan=s,scalar_kernel_error=float(abs(one-two))))
 mask=abs(freq-places[:,None])<=5;coef=np.where(mask[None,:,:],response[0],-np.inf).max(axis=2).mean(axis=0)
 assert np.min(coef)>0
 np.savez_compressed(O/'responses.npz',response=response,coefficient=coef)
 write('response-checks.json',checks)
def tabulate():
 bg=np.load(O/'backgrounds.npz');rr=np.load(O/'responses.npz');places=bg['places'];freq=bg['freq'];base=bg['baseline'];groups=bg['groups'];resp=rr['response'];coef=rr['coefficient']
 obs=json.loads((O/'baseline-checks.json').read_text())['observed'];rows=[]
 def add(a,ci,lev):
  mm=metrics(a,freq,places);mm['phenotype']=mm['tolerant_pass']&~mm['strict_pass']&(mm['span']>=obs['span']-1e-6)
  mm['secondary']=mm['phenotype']&(mm['outer']<=d+1e-6)&(abs(mm['middle'])>=abs(obs['middle'])-1e-6)
  mm['matched']=mm['tolerant_pass']&(mm['min_on']<=3.25)&(mm['max_on']<=4)
  for b in range(len(places)):
   row=dict(config=ci,family='background' if ci<0 else CFG[ci]['family'],level=lev,placement=b,group=str(groups[b]),frequency_hz=float(places[b]))
   row.update({k:v[b].item() for k,v in mm.items()});rows.append(row)
 add(base,-1,0)
 for ci in range(53):
  for lev in LEVELS:
   a=base.copy();a[:,:3]+=resp[ci].transpose(1,0,2)*(lev/coef)[:,None,None];add(a,ci,lev)
 c.csvout(O/'all-trials.csv',rows)
 summary=[]
 for group in ['local','broad']:
  for family in ['background']+list(dict.fromkeys(x['family'] for x in CFG)):
   for lev in ([0] if family=='background' else LEVELS):
    ss=[r for r in rows if r['group']==group and r['family']==family and r['level']==lev];n=len(ss);nr=sum(r['tolerant_pass'] for r in ss);nm=sum(r['matched'] for r in ss)
    summary.append(dict(group=group,family=family,level=lev,n=n,strict=sum(r['strict_pass'] for r in ss),tolerant=nr,phenotype=sum(r['phenotype'] for r in ss),secondary=sum(r['secondary'] for r in ss),matched=nm,matched_phenotype=sum(r['matched'] and r['phenotype'] for r in ss),matched_secondary=sum(r['matched'] and r['secondary'] for r in ss)))
 write('summary.json',summary);print(json.dumps(summary[:7]),flush=True)
 detail=[]
 for ci,cfg in enumerate(CFG):
  for lev in LEVELS:
   for group in ['local','broad']:
    ss=[r for r in rows if r['config']==ci and r['level']==lev and r['group']==group]
    detail.append(dict(config=ci,**cfg,level=lev,group=group,n=len(ss),phenotype=sum(r['phenotype'] for r in ss),secondary=sum(r['secondary'] for r in ss),tolerant=sum(r['tolerant_pass'] for r in ss)))
 c.csvout(O/'configuration-summary.csv',detail)
def rawvalidation():
 bg=np.load(O/'backgrounds.npz');rr=np.load(O/'responses.npz');cal=json.loads((O/'baseline-checks.json').read_text())['calibration'];results=[]
 chosen=[0]+[next(i for i,cfg in enumerate(CFG) if cfg['family']==fam) for fam in ['changing_single','two_handoff','three_handoff']]
 for bi in [64,192]:
  b=100+bi
  for ci,lev in [(i,2.8) for i in chosen]+[(0,11.2)]:
   place=bg['places'][b];amp=lev/rr['coefficient'][b];fast=bg['baseline'][b].copy();fast[:3]+=rr['response'][ci,:,b,:]*amp;full=bg['baseline'][b].copy()
   for si,s in enumerate(c.S[:3]):
    name=f'validation-b{bi}-c{ci}-l{lev}-{s}.json';done=O/name
    if done.exists():rec=json.loads(done.read_text());full[si]=rec['full_scores'];results.append(rec);continue
    raw=np.load(c.R/f'raw/OH_{s}.npy',mmap_mode='r');mod=np.array(raw,copy=True);rc=np.load(K/f'rowcal-{s}.npz');sub,sec=times(s);parts=components(CFG[ci],sec);dop=1-c.rv(sub)/c.C
    for t in range(49):
     us=[((place+off[t])*dop[t]-c.H[s]['fch1_cc']*1e6)/c.FO for off,w in parts]
     jj=np.arange(max(0,int(np.floor(min(u.min() for u in us)-7))),min(c.NC,int(np.ceil(max(u.max() for u in us)+7))+1))
     power=np.zeros(len(jj))
     for u,(off,w) in zip(us,parts):power+=np.mean(pref*(erf((jj[:,None]+.5-u[None,:])/root)-erf((jj[:,None]-.5-u[None,:])/root))*w[t][None,:],axis=1)
     base=np.interp(jj,np.arange(1024)*1024+511.5,rc['block'][t]).astype(np.float32)
     delta=amp*rc['scale'][t]*base*power
     assert np.array_equal(raw[t,jj],(raw[t,jj].astype(float)+0*delta).astype(np.float32))
     mod[t,jj]=(raw[t,jj].astype(float)+delta).astype(np.float32)
    out,ca=c.compute(mod,s,'F1');v=out['exact'][indices(np.array([place]))[0]];full[si]=v
    rec=dict(broad_index=bi,placement=b,config=ci,level=lev,scan=s,max_score_error=float(np.max(abs(v-fast[si]))),full_scores=v.tolist(),fast_scores=fast[si].tolist(),calibration=ca)
    write(name,rec);results.append(rec);del mod;print('RAW VALIDATION',bi,ci,lev,s,rec['max_score_error'],flush=True)
   fm=metrics(fast[None,...],bg['freq'][b:b+1],np.array([place]));rm=metrics(full[None,...],bg['freq'][b:b+1],np.array([place]));write(f'validation-gates-b{bi}-c{ci}-l{lev}.json',dict(fast={k:v[0].item() for k,v in fm.items()},full={k:v[0].item() for k,v in rm.items()}))
 write('validation-summary.json',dict(n=len(results),max_error=max(r['max_score_error'] for r in results),guard=.05,pass_guard=all(r['max_score_error']<=.05 for r in results),results=results))
if __name__=='__main__':
 {'baseline':baseline,'response':response,'tabulate':tabulate,'validate':rawvalidation}[sys.argv[1]]()

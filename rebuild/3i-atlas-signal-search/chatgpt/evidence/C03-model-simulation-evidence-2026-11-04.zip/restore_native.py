"""Put the six Library-native NPZ files in restored/, then run this once."""
from pathlib import Path
import json,hashlib,zipfile,shutil
R=Path(__file__).resolve().parent
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
rows=[]
for rec in json.loads((R/'audit/inputs/native-input-ledger.json').read_text()):
 p=R/'restored'/rec['file'];assert sha(p)==rec['sha256']
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  dest=R/f"audit/raw/OH_{rec['scan']:04}.npy";dest.parent.mkdir(exist_ok=True)
  with z.open('power.npy') as src,dest.open('wb') as out:shutil.copyfileobj(src,out)
 assert sha(dest)==rec['npy_sha256'];rows.append(dict(scan=rec['scan'],sha256=rec['sha256'],npy_sha256=rec['npy_sha256'],crc_pass=True))
 print('Verified',rec['scan'],flush=True)
(R/'results/native-integrity.json').write_text(json.dumps(rows,indent=2))

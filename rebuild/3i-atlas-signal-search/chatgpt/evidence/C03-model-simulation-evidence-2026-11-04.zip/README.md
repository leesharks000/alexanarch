# Reproduce the C03 exploratory model simulation

See the dated plan and report for scope and interpretation. No new sky observations were acquired. The evidence includes all fixed-background local profiles, model responses and trial metrics. The six native-power archives remain separate under the exact Library IDs/hashes in `audit/inputs/native-input-ledger.json`.

1. Restore those six archives under `restored/`, retaining their filenames. Run `python3 restore_native.py` (SHA/CRC verifies and extracts immutable native powers).
2. Python 3 with numpy 2.3.5 and scipy 1.17.0 was used. Matplotlib is only needed to regenerate the report figure.
3. Run `python3 simulate.py baseline`, then `response`, `tabulate`, and `validate` as separate invocations. Each saves completed scan/case batches. Full score vectors are regenerable cache, omitted from the archive.
4. `backgrounds.npz` contains exact sampled frequencies and six-scan scores; `responses.npz` contains all 53 x 3 x 356 x 23 line responses and the amplitude coefficients. For model i / level L, add `L/coefficient[b] * response[i,:,b,:]` to the three ON profiles at background b; OFF profiles are unchanged. Thus every simulated local profile can be reconstructed, without re-reading native powers.
5. `all-trials.csv` records every configuration, placement, level and metric; `summary.json` gives denominators. `validation-*.json` records all full-pipeline checks and selected gates. The earlier audit core/inputs/results are included to establish baseline reproduction.

The benchmark holds row normalization and full-band calibration fixed for speed; its predeclared full-pipeline error guard is 0.05 score. Respect the report's guard outcome rather than assuming exact full-pipeline rates. Configurations, placements and thresholds are exploratory design choices, not independent samples from a population of spacecraft. A multicarrier spectrum does not determine the number or location of physical transmitters.

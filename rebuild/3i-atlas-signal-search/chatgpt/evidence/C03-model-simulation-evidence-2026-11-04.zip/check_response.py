"""Independent narrow-bin scalar check of actual integrated model responses."""
import numpy as np,json
from scipy.special import erf
import simulate as s
c=s.c;bg=np.load(s.O/'backgrounds.npz');rr=np.load(s.O/'responses.npz');rows=[]
for si,scan in enumerate(c.S[:3]):
 sub,seconds=s.times(scan);dop=1-c.rv(sub)/c.C
 for ci,cfg in enumerate(s.CFG):
  b=(ci*7)%len(bg['places']);e=11;place=bg['places'][b];freq=bg['freq'][b,e];total=0.
  for t in range(49):
   q=int(np.rint((freq*c.D[scan][t]-c.H[scan]['fch1_cc']*1e6)/c.FO));bins=np.arange(q-1,q+2)
   for off,w in s.components(cfg,seconds):
    u=((place+off[t])*dop[t]-c.H[scan]['fch1_cc']*1e6)/c.FO
    binpower=s.pref*(erf((bins[:,None]+.5-u[None,:])/s.root)-erf((bins[:,None]-.5-u[None,:])/s.root))
    total+=np.mean(binpower.sum(axis=0)*w[t])
  expected=total/float(np.load(s.K/f'base-{scan}.npz')['scale']);got=rr['response'][ci,si,b,e];error=float(abs(expected-got));assert error<1e-12
  rows.append(dict(scan=scan,config=ci,placement=b,cell=e,scalar=expected,vector=float(got),error=error))
s.write('independent-response-checks.json',dict(n=len(rows),max_error=max(r['error'] for r in rows),checks=rows))
print(len(rows),'scalar checks pass',max(r['error'] for r in rows))

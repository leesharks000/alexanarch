# C03 transmitter-model simulation: fixed exploratory benchmark

4 November2026. Authorized by Lee Sharks after discussing a steady transmitter, a changing transmitter, and two/three-transmitter mixtures. This is an exploratory audit of an already selected feature, not an independent discovery or an origin probability. Freeze these choices before simulated outcomes.

## Question

Can a single steady weak line produce C03's frequency scatter and tolerance-dependent pass? Do simple moving-frequency or multi-component alternatives produce a distinguishable pattern at comparable recovered strength? Multiple radio components do not imply multiple physical vehicles: a single radio can generate the same multi-carrier power spectrum. This benchmark cannot establish a drone swarm, extraterrestrial origin, or AI operators.

## Inputs and baseline

Restore all six previously verified GBT coarse-channel7 native powers and the C03 tracking-audit evidence. Preserve original input hashes and Library IDs; no new sky observations. Use only F1, unchanged from the audit:1024-channel interpolated frequency-median baseline, row median/MAD whitening, three-bin spectral sum, first-order comet Doppler model, half-native-bin common rest grid and the same six sequential pointings. Reproduce the observed strict/tolerant C03 scores first.

Primary fast experiment adds idealized Gaussian line powers to the **fixed normalized representation**, holding full-grid tracked median/MAD calibrations fixed. It includes actual frequency/time-correlated backgrounds. It is conditional on this preprocessing; full raw-power end-to-end injections below check its accuracy. Gaussian sigma0.6native channels, bin-edge integration,16sub-times per exposure. Sum powers incoherently; coherent-array phase/interference is outside scope. Preserve true scan gaps. Inject into ON13/15/17 only; OFF14/16/18 unchanged.

## Placements and equal-power levels

Two separately reported sets:100previous local comparison centers F_C03±250*k Hz,k1…50; up to256metadata-only equally spaced centers over the complete common band, inset5kHz from edges and excluding within100Hz of C03. Keep interference-contaminated placements; no power-based exclusions. These reused, dependent backgrounds are not independent Bernoulli trials. No global p-values or confidence intervals from treating all configurations as independent.

For each placement, compute the noiseless steady-template response with the fixed normalization/grid. Scale its common normalized per-row power so that the mean of the three ON peak-score increments would be2.8,5.6,11.2. These are benchmark strength levels, not measured flux or EIRP. All alternatives at that placement/level receive exactly the same summed intrinsic spectral power. Mixture weights sum to1 at every exposure sub-time. No amplitude fit to observed peaks in each individual scan.

## Six emitting families,53fixed configurations

Let d=abs(native channel spacing)=2.7939677238464355Hz; residual offsets are in the reference rest-frequency coordinate. They could represent intrinsic transmitter tuning or small relative line-of-sight velocities. They are not measured velocities of objects.

1. steady_single:one constant-rest-frequency component, weight1.
2. changing_single:one component with residual q*d*sin(2*pi*t/P+phase), q=1 or2; P=900or2700s; phases0,pi/2,pi,3pi/2.16configurations.
3. two_static:components±q*d/2, equal powers, q1or2.2configurations.
4. two_handoff:same two frequencies; first weight(1+0.8*cos(2*pi*t/P+phase))/2, second1−first; q/P/phases as above.16configurations.
5. three_static:components−q*d,0,+q*d, equal powers,q1or2.2configurations.
6. three_handoff:same three frequencies; weights softmax(2*cos(2*pi*t/P+phase+2*pi*m/3)),m0,1,2; q/P/phases as above.16configurations.

Time origin is actual start of ON13; evaluate at exposure sub-times, including gaps. No period, phase, offset or amplitude is optimized to the observed C03 displacement. Report each configuration and phase-averaged rates, not best-fitting phase maxima. Include uninjected background controls.

## Measurements

Retain local score profiles at23half-grid cells centered nearest each placement (roughly±15Hz). Strict shared-track search:centers within±5Hz, original ON>=2.5/OFF<2 gates. Tolerant search:same centers with±one native bin independently per scan, using five-point maxfilter before the same gates, exactly as audit. Frequency peaks for descriptive scatter are independent ON maxima within the same±5Hz window.

Record strict/tolerant gates and gate margins; peak span; middle peak minus average of outer peaks; outer-peak difference. Derive observed span/displacement once from the reproduced C03 profile. Primary C03-like phenotype:tolerant pass, strict fail, peak span at least the observed C03 span. Secondary adds outer-peak agreement within one native channel and absolute middle displacement at least observed. Also report signed displacement. Strength-matched subset:tolerant pass, minimum ON2.5–3.25 and maximum ON<=4.0. Show all denominators and conditioning, including zero recovered cases. Counts describe these models/backgrounds, not posterior odds of emitter count.

## End-to-end validation and integrity

Two fixed broad-placement indices64and192. At weak level2.8, test steady_single and first q1/P900/phase0 configuration of changing_single,two_handoff,three_handoff. At strong level11.2, test steady_single.10triples/30modified ON scan cases. Translate normalized line additions back to raw powers using the original frequency baseline and row whitening scale; add before preprocessing; recompute the complete F1 normalization and full-grid tracked median/MAD. Compare local profiles and gates with fast simulation. Accuracy guard:max absolute local score discrepancy<=0.05. If exceeded, do not present fast rates as quantitatively validated rates for the full original pipeline; report conditional-normalization results and discrepancies separately. Do not silently retune models or thresholds.

Validate total mixture weight/power, zero-injection identity, independent scalar response integration, prior baseline reproduction and native CRC/SHA hashes. Save code, configs, all simulated local profiles/metrics, validation outputs and plots after bounded batches. Native powers remain under their existing Library IDs; full deterministic caches may be regenerated. Update the existing3I-ATLAS-RESUME.md without discarding unfinished earlier Wow-work status.

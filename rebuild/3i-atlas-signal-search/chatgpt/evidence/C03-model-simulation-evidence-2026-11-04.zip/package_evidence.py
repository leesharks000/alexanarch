from pathlib import Path
import json,hashlib,zipfile,py_compile
R=Path(__file__).resolve().parent
for p in R.glob('*.py'):py_compile.compile(str(p),doraise=True)
v=json.loads((R/'results/validation-summary.json').read_text());assert v['n']==30 and v['pass_guard']
paths=list(R.glob('*.py'))+[R/'C03-model-simulation-plan-2026-11-04.md']
(R/'results/code-sha256.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},indent=2))
dest=R/'C03-model-simulation-evidence-2026-11-04.zip'
with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R)
  if not p.is_file() or rel.parts[0] in ['helpers','restored','cache','__pycache__'] or '__pycache__' in rel.parts:continue
  if rel.parts[:2] in [('audit','raw'),('audit','cache')]:continue
  if p.suffix=='.zip' or p.name.startswith('save-receipt'):continue
  z.write(p,str(rel))
with zipfile.ZipFile(dest) as z:assert z.testzip() is None
print('Validated evidence ZIP',dest.stat().st_size,'bytes',hashlib.sha256(dest.read_bytes()).hexdigest())

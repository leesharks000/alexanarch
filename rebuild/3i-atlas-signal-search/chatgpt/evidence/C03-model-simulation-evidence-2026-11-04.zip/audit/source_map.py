"""Read public filenames and HDF5 headers only; no new spectral powers."""
from pathlib import Path
from html.parser import HTMLParser
from urllib.request import urlopen,Request
from urllib.parse import urljoin
import json,re,hashlib,concurrent.futures,io
R=Path(__file__).resolve().parent;O=R/'sources';O.mkdir(exist_ok=True);K=R/'cache';K.mkdir(exist_ok=True)
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[]
 def handle_starttag(self,t,a):
  if t=='a' and 'href' in dict(a):self.links.append(dict(a)['href'])
def getindex(url,name):
 try:
  with urlopen(url,timeout=30) as r:b=r.read()
  (O/name).write_bytes(b);p=Links();p.feed(b.decode());return [urljoin(url,x) for x in p.links]
 except Exception as e:return {'error':str(e),'url':url}
def one(url):
 import h5py,numpy as np
 out={'url':url,'purpose':'metadata only; no powers requested'}
 try:
  req=Request(url,headers={'Range':'bytes=0-262143'})
  with urlopen(req,timeout=35) as r:
   if r.status!=206:raise RuntimeError('Expected bounded 206 response; did not read full file')
   data=r.read();cr=r.headers['Content-Range'];size=int(cr.split('/')[-1])
  out.update({'status':206,'content_range':cr,'header_sha256':hashlib.sha256(data).hexdigest()})
  (O/(url.split('/')[-1]+'.header.bin')).write_bytes(data)
  p=K/(url.split('/')[-1]+'.sparse-header')
  with p.open('wb') as f:f.write(data);f.truncate(size)
  def cv(v):
   if isinstance(v,bytes):return v.decode(errors='replace')
   if isinstance(v,np.ndarray):return v.tolist()
   if isinstance(v,np.generic):return v.item()
   return v
  # Object headers can be near EOF. Resolve HDF5 metadata via bounded range reads;
  # inspect shape/attrs only, never dataset values or spectra chunks.
  class Remote(io.RawIOBase):
   def __init__(self):self.pos=0;self.blocks={0:data};self.ledger=[];self.total=len(data)
   def readable(self):return True
   def seekable(self):return True
   def tell(self):return self.pos
   def seek(self,offset,whence=0):
    self.pos=offset if whence==0 else self.pos+offset if whence==1 else size+offset
    return self.pos
   def readinto(self,b):
    dat=self.read(len(b));b[:len(dat)]=dat;return len(dat)
   def read(self,n=-1):
    if n<0 or n>1048576:raise RuntimeError('metadata byte cap')
    start=self.pos;end=min(size,start+n);self.pos=end
    if start<0 or start>=size:return b''
    if end<=len(data):return data[start:end]
    key=(start,end)
    if key not in self.blocks:
     if self.total+end-start>8*1048576:raise RuntimeError('total metadata byte cap')
     with urlopen(Request(url,headers={'Range':f'bytes={start}-{end-1}'}),timeout=35) as rr:
      cr=rr.headers.get('Content-Range','')
      if rr.status!=206 or not cr.startswith(f'bytes {start}-{end-1}/'):raise RuntimeError('Range mismatch '+cr)
      d=rr.read()
     assert len(d)==end-start;self.blocks[key]=d;self.total+=len(d)
     fn=url.split('/')[-1]+f'.range-{start}-{end-1}.bin';(O/fn).write_bytes(d)
     self.ledger.append({'start':start,'end':end-1,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest(),'saved':fn})
    return self.blocks[key]
  remote=Remote()
  with h5py.File(remote,'r') as f:
   out['datasets']={k:{'shape':list(f[k].shape),'dtype':str(f[k].dtype),'attrs':{a:cv(v) for a,v in f[k].attrs.items()}} for k in f if isinstance(f[k],h5py.Dataset)}
  out['metadata_reads']=remote.ledger;out['total_metadata_bytes']=remote.total
  p.unlink()
 except Exception as e:out['error']=str(e)
 return out
if __name__=='__main__':
 root='https://bldata.berkeley.edu/ATLAS/';links=getindex(root+'GB_ATLAS/','GBT-index.html')
 selected=[u for u in links if re.search(r'blc2[1-6]_.*_0013\.rawspec\.0000\.h5$',u) or re.search(r'blc23_.*_0013\.rawspec\.000[12]\.h5$',u)] if isinstance(links,list) else []
 (O/'selected-header-urls.json').write_text(json.dumps(selected,indent=2))
 rows=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for x in pool.map(one,selected):rows.append(x);(O/'GBT-header-ledger.json').write_text(json.dumps(rows,indent=2));print(x['url'].split('/')[-1],x.get('error','header complete'),flush=True)
 for d in ['PKS_Jul_31_2025','PKS_Sep_12_2025','PKS_Oct_05_2025']:
  x=getindex(root+d+'/',d+'-index.html');(O/(d+'-links.json')).write_text(json.dumps(x,indent=2));print(d,len(x) if isinstance(x,list) else x,flush=True)

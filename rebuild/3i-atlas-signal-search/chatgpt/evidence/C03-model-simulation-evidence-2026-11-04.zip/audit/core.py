"""Fixed C03 continuation: explicit common-frequency first-order tracks.

Power inputs are immutable. Full score vectors are regenerable cache; bounded
profiles, calibration, scalar checks and trial ledgers are evidence outputs.
"""
from pathlib import Path
import json,csv,sys,time
import numpy as np
from scipy.ndimage import maximum_filter1d
from scipy.special import erf
R=Path(__file__).resolve().parent; I=R/'inputs'; O=R/'results'; K=R/'cache'
O.mkdir(exist_ok=True);K.mkdir(exist_ok=True)
S=['0013','0015','0017','0014','0016','0018']; C=299792.458; F0=1665633776.6172388
H={s:json.loads((I/f'OH_{s}.json').read_text()) for s in S}
NC=H[S[0]]['nchan']; FO=H[S[0]]['foff']*1e6
b=json.loads((I/'legacy-horizons-response.json').read_text())['result'].split('$$SOE')[1].split('$$EOE')[0]
E=np.array([[float(c[0])-2400000.5,float(c[-1])] for c in [[v.strip() for v in l.split(',') if v.strip()] for l in b.strip().splitlines()]])
def rv(t):
 t=np.asarray(t);assert np.min(t)>=E[0,0] and np.max(t)<=E[-1,0]
 return np.interp(t,E[:,0],E[:,1])
TT={s:H[s]['tstart']+(np.arange(49)+.5)*H[s]['tsamp']/86400 for s in S}
V={s:rv(TT[s]) for s in S}; D={s:1-V[s]/C for s in S}
vref=V[S[0]][0]; fullF=(H[S[0]]['fch1_cc']*1e6+FO*np.arange(2*NC-1)/2)/(1-vref/C)
# Metadata-only complete common coverage: every 3-bin path has interior support.
valid=np.ones(len(fullF),bool)
for s in S:
 for d in D[s]:
  q=(fullF*d-H[s]['fch1_cc']*1e6)/FO
  valid&=(q>=1)&(q<=NC-2)
F=fullF[valid]; del fullF,valid
CENTERS=np.r_[F0,F0+np.r_[np.arange(-50,0),np.arange(1,51)]*250.]
def write(p,x):
 p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,indent=2,allow_nan=False));tmp.replace(p)
def csvout(p,rows):
 with Path(p).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def normrows(raw,m):
 if m=='T0':
  med=np.median(raw,axis=0)
  for t in range(len(raw)):yield t,np.asarray(raw[t],np.float64)/med-1.
 else:
  nb=NC//1024; centers=np.arange(nb)*1024+511.5
  med=np.median(raw.reshape(len(raw),nb,1024),axis=2)
  for t in range(len(raw)):
   base=np.interp(np.arange(NC),centers,med[t]).astype(np.float32)
   x=raw[t]/base-1; center=np.median(x);scale=1.4826*np.median(abs(x-center))
   yield t,np.asarray((x-center)/scale,np.float64)
def standard(a):
 med=float(np.median(a)); scale=float(1.4826*np.median(abs(a-med)))
 return (a-med)/scale,{'center':med,'scale':scale,'n':len(a)}
def compute(raw,s,m,legacy=False,halves=False):
 acc=np.zeros(len(F)); early=np.zeros(len(F)) if halves else None; late=np.zeros(len(F)) if halves else None
 old=np.zeros(NC) if legacy else None
 shift=np.rint(H[s]['fch1_cc']*1e6*(V[s][0]-V[s])/C/FO).astype(int)
 for t,x in normrows(raw,m):
  sm=x+np.roll(x,1)+np.roll(x,-1)
  q=np.rint((F*D[s][t]-H[s]['fch1_cc']*1e6)/FO).astype(np.int64)
  y=sm[q];acc+=y
  if halves:
   if t<24:early+=y
   else:late+=y
  if legacy:old+=np.roll(sm,-shift[t])
 z,cal=standard(acc);out={'exact':z};cals={'exact':cal}
 if halves:
  for name,a in [('early',early),('late',late)]:out[name],cals[name]=standard(a)
 if legacy:
  out['legacy'],cals['legacy']=standard(old);out['legacy'][NC//2-4:NC//2+5]=0
 return out,cals
def cache(m,s,case='base'):
 return K/f'{case}-{m}-{s}.npz'
def loadbase(m,kind='exact'):
 return np.stack([np.load(cache(m,s))[kind] for s in S])
def legacyaligned(m,correct):
 zs=loadbase(m,'legacy');PAD=1000
 ref0=H[S[0]]['fch1_cc']*1e6/(1-V[S[0]][0]/C)
 spacing=FO/(1-V[S[0]][0]/C) if correct else FO
 grid=ref0+(np.arange(NC+2*PAD)-PAD)*spacing; a=[]
 for k,s in enumerate(S):
  f=(H[s]['fch1_cc']*1e6+FO*np.arange(NC))/(1-V[s][0]/C)
  idx=np.rint((f-ref0)/spacing).astype(int)+PAD;x=np.full(len(grid),-99.)
  good=(idx>=0)&(idx<len(x));ii=idx[good];x[ii]=np.maximum(x[ii],zs[k,good])
  a.append(maximum_filter1d(x,3,mode='constant',cval=-99.))
 return grid,np.stack(a)
def selected(grid,a,center,width):
 ii=np.flatnonzero(abs(grid-center)<=width)
 if not len(ii):raise ValueError('no frequency support')
 margins=np.minimum(np.min(a[:3,ii],axis=0)-2.5,2-np.max(a[3:,ii],axis=0))
 j=int(ii[np.argmax(margins)]);v=a[:,j]
 return {'center_hz':float(center),'width_hz':float(width),'selected_hz':float(grid[j]),'frequency_cells':len(ii),'margin':float(np.max(margins)),'pass':bool(np.max(margins)>=0),'scores':v.tolist(),'index':j}
def baseline():
 write(O/'coverage.json',{'F0_hz':F0,'n_common_half_grid':len(F),'rest_high_hz':float(F[0]),'rest_low_hz':float(F[-1]),'rest_step_hz':float(F[1]-F[0]),'scan_order':S,'reference_radial_km_s':float(vref),'radial_km_s':{s:V[s].tolist() for s in S}})
 prior=list(csv.DictReader((I/'prior-candidate-per-scan.csv').open()))
 for m in ['T0','F1']:
  for s in S:
   dest=cache(m,s);done=O/f'base-{m}-{s}.json'
   if dest.exists() and done.exists():continue
   raw=np.load(R/f'raw/OH_{s}.npy',mmap_mode='r');out,cal=compute(raw,s,m,True,True)
   key='legacy_score' if m=='T0' else 'alternate_frequency_baseline_score'
   checks=[{'id':r['id'],'abs_error':abs(float(out['legacy'][int(r['selected_native_first_channel_in_coarse'])])-float(r[key]))} for r in prior if r['scan']==s]
   assert max(x['abs_error'] for x in checks)<1e-12
   np.savez(dest,**out);write(done,{'scan':s,'method':m,'calibration':cal,'legacy_reference_checks':checks});print('BASE COMPLETE',m,s,flush=True)
def summarize():
 rows=[]; profiles={}; times=[];checks=[]
 for m in ['T0','F1']:
  exact=loadbase(m);treatments=[('legacy',*legacyaligned(m,False)),('corrected_mapping',*legacyaligned(m,True)),('exact',F,exact),('exact_tolerance',F,maximum_filter1d(exact,5,axis=1,mode='constant',cval=-99.))]
  for name,grid,a in treatments:
   key=m+'-'+name;wins=[]
   for width in [5.,100.]:
    target=selected(grid,a,F0,width);controls=[selected(grid,a,c,width) for c in CENTERS[1:]]
    rows.append({'method':m,'treatment':name,**target,'controls_ge_margin':sum(x['margin']>=target['margin'] for x in controls),'controls_pass':sum(x['pass'] for x in controls)})
    wins.append({'target':target,'controls':controls})
   write(O/f'{key}-windows.json',wins)
   mask=np.zeros(len(grid),bool)
   for center in CENTERS:mask|=abs(grid-center)<101
   profiles[key+'-F']=grid[mask];profiles[key+'-scores']=a[:,mask]
  # Timing at full-cadence strict shared-frequency +/-5 selection; no half refitting.
  sel=selected(F,exact,F0,5.);j=sel['index'];freq=F[j]
  for s in S:
   dat=np.load(cache(m,s));cal=json.loads((O/f'base-{m}-{s}.json').read_text())['calibration']
   raw=np.load(R/f'raw/OH_{s}.npy',mmap_mode='r');vals=[]
   for t,x in normrows(raw,m):
    q=int(np.rint((freq*D[s][t]-H[s]['fch1_cc']*1e6)/FO));v=float(x[q-1:q+2].sum());vals.append(v)
    times.append({'method':m,'scan':s,'sample':t,'mjd_center':float(TT[s][t]),'rest_hz':float(freq),'observed_hz':float(freq*D[s][t]),'native_channel':q,'normalized_three_bin_power':v})
   for part,arr in [('exact',vals),('early',vals[:24]),('late',vals[24:])]:
    z=(sum(arr)-cal[part]['center'])/cal[part]['scale'];err=abs(z-float(dat[part][j]));checks.append({'method':m,'scan':s,'part':part,'score':z,'vector_score':float(dat[part][j]),'abs_error':err});assert err<1e-12
 np.savez_compressed(O/'bounded-profiles.npz',**profiles);write(O/'window-summary.json',rows);csvout(O/'per-integration.csv',times);csvout(O/'timing-and-scalar-checks.csv',checks)
 print(json.dumps(rows,indent=2),flush=True)
def injection(raw,s,place,amp):
 # Float32 modified-power realization, bin-edge integral, 16 exposure subtimes.
 out=np.array(raw,copy=True);noise=[];root=np.sqrt(2)*.6;pref=.6*np.sqrt(np.pi/2)
 for t in range(len(raw)):
  u=(place*D[s][t]-H[s]['fch1_cc']*1e6)/FO
  lo=max(0,int(np.floor(u-5000/abs(FO))));hi=min(NC,int(np.ceil(u+5000/abs(FO))))
  jj=np.arange(lo,hi);v=np.asarray(raw[t,lo:hi],float);use=abs(jj-u)*abs(FO)>50
  med=np.median(v[use]);mad=1.4826*np.median(abs(v[use]-med));noise.append(float(mad))
  subt=H[s]['tstart']+(t+(np.arange(16)+.5)/16)*H[s]['tsamp']/86400
  us=(place*(1-rv(subt)/C)-H[s]['fch1_cc']*1e6)/FO
  jj=np.arange(max(0,int(np.floor(us.min()-7))),min(NC,int(np.ceil(us.max()+7))+1))
  y=np.mean(pref*(erf((jj[:,None]+.5-us[None,:])/root)-erf((jj[:,None]-.5-us[None,:])/root)),axis=1)
  out[t,jj]=(np.asarray(raw[t,jj],float)+amp*mad*y).astype(np.float32)
 return out,noise
def recover():
 # Only 27 unique modified scan realizations per method. Occupancies reuse them.
 for p,place in enumerate([F0-1000,F0+1000,F0+2000]):
  for amp in [.15,.30,.60]:
   for s in S[:3]:
    case=f'inj-p{p}-a{amp:.2f}';raw=np.load(R/f'raw/OH_{s}.npy',mmap_mode='r');mod=None
    for m in ['T0','F1']:
     dest=cache(m,s,case);done=O/f'{case}-{m}-{s}.json'
     if dest.exists() and done.exists():continue
     if mod is None:mod,noise=injection(raw,s,place,amp)
     out,cal=compute(mod,s,m);np.savez(dest,**out);write(done,{'method':m,'scan':s,'placement_hz':place,'amplitude_raw_row_MAD':amp,'calibration':cal,'local_raw_row_MAD':noise});print('RECOVERY COMPONENT',case,m,s,flush=True)
    del mod
   result=[]
   for occupancy in ['all_ON','middle_ON_only']:
    for m in ['T0','F1']:
     a=loadbase(m);un=a.copy()
     for k,s in enumerate(S[:3]):
      if occupancy=='all_ON' or k==1:a[k]=np.load(cache(m,s,case))['exact']
     for kind,arr in [('injected',a),('uninjected',un)]:
      at=int(np.argmin(abs(F-place)));mask=np.flatnonzero(abs(F-place)<=5)
      def entry(j):
       vals=arr[:,j];return {'sampled_hz':float(F[j]),'scores':vals.tolist(),'persistent_pass':bool(np.all(vals[:3]>=2.5) and np.all(vals[3:]<2)),'pair_pass':[bool(vals[k]>=2.5 and vals[k+3]<2) for k in range(3)]}
      best=selected(F,arr,place,5.)
      pairs=[]
      for k in range(3):
       margins=np.minimum(arr[k,mask]-2.5,2-arr[k+3,mask]);j=int(mask[np.argmax(margins)])
       pairs.append({'ON':S[k],'OFF':S[k+3],'margin':float(max(margins)),**entry(j)})
      result.append({'placement_hz':place,'amplitude_raw_row_MAD':amp,'occupancy':occupancy,'method':m,'case':kind,'exact_coordinate_nearest_grid':entry(at),'shared_plusminus5':best,'individual_pair_plusminus5':pairs})
   write(O/f'{case}-recovery.json',result)
 print('ALL 18 CONFIGURATIONS COMPLETE',flush=True)
if __name__=='__main__':
 if sys.argv[1]=='base':baseline();summarize()
 elif sys.argv[1]=='recover':recover()

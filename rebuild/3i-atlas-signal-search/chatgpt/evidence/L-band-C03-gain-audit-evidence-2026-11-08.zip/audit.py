import json,csv,sys,time,hashlib,math
from pathlib import Path
import numpy as np
from scipy.special import erf
import common as c
R=Path(__file__).resolve().parent
BRANCHES=['original16','row_scalar','uniform17','power_weighted17','quality_mask16']
def save(p,x):
    q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(x,indent=2));q.replace(p)
def csvout(p,rows):
    if not rows:return
    with p.open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def h17(obs,place,weights=None):
    t=np.asarray(obs['times_mjd']);dt=obs['dt_s'];sub=t[:,None]+((np.arange(17)+.5)/17-.5)*dt/86400
    _,vel=c.ep(obs,sub.ravel());ratio=(1-vel/c.C).reshape(sub.shape);fq=place*ratio;sig=c.P['sigma_rest_hz']*ratio
    q=(fq-obs['f0_hz'])/obs['df_hz'];df=abs(obs['df_hz'])
    lo=int(np.floor(q.min()-8*sig.max()/df-2));hi=int(np.ceil(q.max()+8*sig.max()/df+2))+1
    jj=np.arange(lo,hi);fc=obs['f0_hz']+jj*obs['df_hz']
    u=(fc[None,:,None]+df/2-fq[:,None,:])/(np.sqrt(2)*sig[:,None,:]);v=(fc[None,:,None]-df/2-fq[:,None,:])/(np.sqrt(2)*sig[:,None,:]);kernel=.5*(erf(u)-erf(v))
    if weights is None:h=kernel.mean(axis=2)
    else:
        weights=np.asarray(weights,dtype=np.float64)
        h=np.sum(kernel*weights[:,None,:],axis=2)/weights.sum(axis=1)[:,None]
    assert np.max(abs(h.sum(axis=1)-1))<1e-9
    # Hold the inherited background-window indices fixed to isolate the template change.
    qbase=c.template(obs,place)[2]
    return jj,h,qbase
def profile_with_template(a,obs,place,kind,weights):
    if kind in ['original16','row_scalar','quality_mask16']:jj,h,q=c.template(obs,place)
    else:jj,h,q=h17(obs,place,weights if kind=='power_weighted17' else None)
    bg,_=c.baseline(a,q,obs['df_hz']);res=np.asarray(a[:,jj],float)/bg[:,None]-1
    amp=(res*h).sum(axis=1)/(h*h).sum(axis=1)
    return amp,(jj,h,q,bg)
def fit(A,obs,mask=None):
    if mask is None:return c.w_scan(A,obs)
    new={**obs,'times_mjd':np.asarray(obs['times_mjd'])[mask].tolist()}
    return c.w_scan(A[:,mask],new)
def run_scan(scan):
    dest=R/'results'/f'audit-{scan:04d}.json'
    if dest.exists() and '--force' not in sys.argv:print('ALREADY AUDITED',scan,flush=True);return
    path=R/'data'/f'input-{scan:04d}.npz';meta=R/'metadata'/f'input-{scan:04d}.json'
    while not path.exists() or not meta.exists():time.sleep(1)
    m=json.loads(meta.read_text());assert hashlib.sha256(path.read_bytes()).hexdigest()==m['native_cutout_sha256']
    z=np.load(path);a=z['power'];obs=m['observation'];gm=z['gain_mean'];gb=z['gain_blocks17'];keep=z['keep']
    coords=c.P['rest_hz']+np.r_[0,np.array(c.P['controls_hz'])]
    A={b:[] for b in BRANCHES};row_scaled=np.asarray(a,dtype=np.float64)/np.asarray(gm,dtype=np.float64)[:,None]
    for place in coords:
        for branch in BRANCHES:
            if branch=='quality_mask16':continue
            source=row_scaled if branch=='row_scalar' else a
            amp,_=profile_with_template(source,obs,float(place),branch,gb)
            A[branch].append(amp)
    for b in BRANCHES:
        if b!='quality_mask16':A[b]=np.asarray(A[b])
    A['quality_mask16']=A['original16'].copy()
    old=np.load(R/'inputs/reference'/f'profiles-GBT-{scan:04d}-strict.npz')
    prior_error=float(np.max(abs(old['A']-A['original16'])));assert prior_error<1e-9
    scalar_error=float(np.max(abs(A['row_scalar']-A['original16'])));assert scalar_error<1e-10
    table=[];profiles=[];checks=[];fits={}
    for branch in BRANCHES:
        mask=keep if branch=='quality_mask16' else np.ones(len(a),bool)
        st=fit(A[branch],obs,mask if branch=='quality_mask16' else None);fits[branch]=(st,mask)
        if branch=='original16':assert abs(float(st['z'][0])-float(old['z'][0]))<1e-8
        np.savez_compressed(R/'results'/f'profiles-{scan:04d}-{branch}.npz',A=A[branch],coords=coords,times_mjd=obs['times_mjd'],mask=mask,**st)
        table.append({'scan':scan,'role':m['role'],'branch':branch,'score':float(st['z'][0]),'centered_line_amplitude':float(st['mean'][0]-st['center']),'control_MAD':float(st['scale']),'retained_integrations':int(mask.sum()),'removed_integrations':int((~mask).sum()),'controls_at_least_target':int((st['z'][1:]>=st['z'][0]).sum()),'n_controls':100})
        for t in range(len(a)):profiles.append({'scan':scan,'role':m['role'],'branch':branch,'integration':t,'mjd':obs['times_mjd'][t],'C03_amplitude':float(A[branch][0,t]),'control_center':float(np.median(A[branch][1:,t])),'control_MAD':float(c.mad(A[branch][1:,t])),'mean_shared_proxy':float(gm[t]),'retained':bool(mask[t])})
        amp,(jj,h,q,bg)=profile_with_template(row_scaled if branch=='row_scalar' else a,obs,float(coords[0]),branch,gb)
        errors=[]
        for t in [0,len(a)//2,len(a)-1]:
            source=row_scaled if branch=='row_scalar' else a
            value=math.fsum(float(h[t,k])*(float(source[t,int(j)])/float(bg[t])-1) for k,j in enumerate(jj))/math.fsum(float(v)*float(v) for v in h[t]);errors.append(abs(value-float(amp[t])))
        assert max(errors)<1e-10
        checks.append({'branch':branch,'scalar_raw_bin_max_error':max(errors),'template_mass_error':float(np.max(abs(h.sum(axis=1)-1)))})
    csvout(R/'results'/f'scores-{scan:04d}.csv',table);csvout(R/'results'/f'row-profiles-{scan:04d}.csv',profiles)
    # Actual-power injections at frozen coordinates. Noise/whole-scan reference weights are frozen.
    trials=[]
    for offset in [0,-45000,-35000,-25000,-15000,-5000,5000,15000,25000,35000,45000]:
        place=float(c.P['rest_hz']+offset)
        for branch in BRANCHES:
            st,mask=fits[branch];source=row_scaled if branch=='row_scalar' else a
            before,(jj,h,q,bg)=profile_with_template(source,obs,place,branch,gb)
            for level in [.03,.1,.3]:
                injected=np.asarray(source[:,jj],float)+level*bg[:,None]*h
                residual=injected/bg[:,None]-1;after=(residual*h).sum(axis=1)/(h*h).sum(axis=1)
                err=float(np.max(abs((after-before)-level)));assert err<1e-10
                val=float(np.sum(after[mask]*st['weights']*st['q'])/np.sum(st['weights']*st['q']**2))
                score=(val-st['center'])/st['scale']
                trials.append({'scan':scan,'role':m['role'],'branch':branch,'offset_hz':offset,'injection':'steady','level':level,'score':score,'passes_2p5':bool(score>=2.5),'recovered_increment_max_error':err,'target_retained_fraction':1.0,'scope':'prescribed coordinate, frozen control weights; conditional mean-power template, no global completeness'})
    # A one-integration line at the most depressed interval explicitly tests mask-induced signal loss.
    bad=int(np.argmin(gm));level=.3
    for branch in BRANCHES:
        st,mask=fits[branch];source=row_scaled if branch=='row_scalar' else a
        before,(jj,h,q,bg)=profile_with_template(source,obs,float(coords[0]),branch,gb)
        delta=np.zeros_like(before);delta[bad]=level
        injected=np.asarray(source[:,jj],float)+delta[:,None]*bg[:,None]*h
        residual=injected/bg[:,None]-1;after=(residual*h).sum(axis=1)/(h*h).sum(axis=1)
        inc=float(np.sum((after-before)[mask]*st['weights']*st['q'])/np.sum(st['weights']*st['q']**2))
        tscore=float((np.sum(after[mask]*st['weights']*st['q'])/np.sum(st['weights']*st['q']**2)-st['center'])/st['scale'])
        trials.append({'scan':scan,'role':m['role'],'branch':branch,'offset_hz':0,'injection':'one_integration_at_deepest_proxy','level':level,'score':tscore,'passes_2p5':bool(tscore>=2.5),'recovered_increment_max_error':float(np.max(abs((after-before)-delta))),'target_retained_fraction':float(mask[bad]),'scope':f'transient in integration{bad}; fitted whole-scan increment={inc:.12g}; mask can discard real emission'})
    csvout(R/'results'/f'injections-{scan:04d}.csv',trials)
    rec={'scan':scan,'role':m['role'],'prior_profile_max_error':prior_error,'row_scalar_profile_max_error':scalar_error,'checks':checks,'rows':table,'injection_trials':len(trials),'worst_shared_proxy_integration':bad,'removed_integrations':np.flatnonzero(~keep).tolist()}
    save(dest,rec);print('AUDITED',scan,table,flush=True)
def finish():
    rows=[];trials=[];records=[]
    for scan in range(13,19):
        r=json.loads((R/'results'/f'audit-{scan:04d}.json').read_text());records.append(r);rows.extend(r['rows'])
        with (R/'results'/f'injections-{scan:04d}.csv').open() as f:trials.extend(list(csv.DictReader(f)))
    csvout(R/'results/all-branch-scores.csv',rows);csvout(R/'results/all-injection-trials.csv',trials)
    gates={b:all((r['score']>=2.5 if r['role']=='ON' else r['score']<2) for r in rows if r['branch']==b) for b in BRANCHES}
    maxdiff=max(abs(r['score']-next(x['score'] for x in rows if x['scan']==r['scan'] and x['branch']=='original16')) for r in rows if r['branch']=='row_scalar')
    save(R/'results/summary.json',{'status':'complete','scans':records,'scores':rows,'joint_diagnostic_gates':gates,'row_scalar_score_max_change':maxdiff,'injection_trials':len(trials),'scope':'Same previously examined observations; shared proxy is not calibrated gain; weighted mean-power template cannot correct voltage phase/leakage.'})
    print('AUDIT COMPLETE',gates,flush=True)
if __name__=='__main__':
    for scan in range(13,19):run_scan(scan)
    finish()

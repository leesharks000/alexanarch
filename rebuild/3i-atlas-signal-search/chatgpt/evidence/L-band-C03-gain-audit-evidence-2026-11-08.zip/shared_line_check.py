import json,csv
import numpy as np
import audit as a
R=a.R
def run():
    rows=[]
    for scan in range(13,19):
        z=np.load(R/'data'/f'input-{scan:04d}.npz');m=json.loads((R/'metadata'/f'input-{scan:04d}.json').read_text());obs=m['observation'];power=z['power'];gb=z['gain_blocks17'];gm=z['gain_mean']
        _,(j0,h0,_,_)=a.profile_with_template(power,obs,a.c.P['rest_hz'],'original16',gb)
        for branch in a.BRANCHES:
            source=np.asarray(power,float)/np.asarray(gm,float)[:,None] if branch=='row_scalar' else power
            before,(jj,h,q,bg)=a.profile_with_template(source,obs,a.c.P['rest_hz'],branch,gb)
            projected=np.zeros_like(h)
            for k,j in enumerate(jj):
                if j0[0]<=j<=j0[-1]:projected[:,k]=h0[:,int(j-j0[0])]
            p=np.load(R/'results'/f'profiles-{scan:04d}-{branch}.npz');mask=p['mask'];w=p['weights'];qw=p['q']
            for level in [.03,.1,.3]:
                injected=np.asarray(source[:,jj],float)+level*bg[:,None]*projected
                after=((injected/bg[:,None]-1)*h).sum(axis=1)/(h*h).sum(axis=1)
                gain=(after-before)/level
                # Independent analytic overlap predicts the effect of fitting a changed template.
                analytic=(projected*h).sum(axis=1)/(h*h).sum(axis=1);err=float(np.max(abs(gain-analytic)));assert err<1e-10
                increment=float(np.sum((after-before)[mask]*w*qw)/np.sum(w*qw**2))
                rows.append({'scan':scan,'branch':branch,'injected_original16_amplitude':level,'minimum_row_response_ratio':float(gain.min()),'maximum_row_response_ratio':float(gain.max()),'fitted_whole_scan_increment':increment,'analytic_overlap_max_error':err,'scope':'same original16 injected mean-power signal fitted by each branch; excludes a universal coherent-voltage claim'})
    a.csvout(R/'results/shared-original-line-recovery.csv',rows)
    a.save(R/'results/shared-original-line-recovery.json',{'trials':len(rows),'minimum_response_ratio':min(r['minimum_row_response_ratio'] for r in rows),'maximum_response_ratio':max(r['maximum_row_response_ratio'] for r in rows),'rows':rows})
    print('SHARED ORIGINAL-LINE CHECK',len(rows),flush=True)
if __name__=='__main__':run()

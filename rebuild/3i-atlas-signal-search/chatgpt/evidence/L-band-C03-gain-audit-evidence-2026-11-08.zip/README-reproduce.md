# Reproduce the L-band gain audit

The evidence archive supplies exact native fine-resolution C03/control cutouts, derived high-time shared-power curves, the per-scan17-block summaries/masks, inherited model/ephemeris inputs and prior strict profile outputs. Completed analysis does not require network access or the full earlier archives. Dependencies are numpy, scipy and matplotlib; current versions are in inputs/software-versions.json.

From the extracted project directory run:

1. `python audit.py --force`
2. `python shared_line_check.py`
3. `python validate.py`
4. `python report.py`

The first step recomputes rather than reuses completed scan results. Run each as a separate process. The original strict implementation is retained as common.py. Background windows remain anchored to the original16-position path in all branches, isolating the exposure-template change from any background-index rounding.

To reconstruct the high-time proxy independently, restore the12original archives listed in inputs/source-fine-ledger.json and inputs/high-native-identities.json under inputs/native-archives/, remove the corresponding prepared data/metadata pair, and run prepare_inputs.py. It verifies original full-power hashes and recomputes the cutout and proxy. The source fine arrays were previously recovered from public GBT rawspec.0000 HDF5 powers; they are not voltages. High-time originals came from rawspec.0001. Their original source URLs and hashes are recorded per scan.

The full shared-power proxy is provided as a derived input for standalone reconstruction. It is not a new measurement of calibrated antenna gain. All native originals remain preserved under their existing identities. Quality-mask results are secondary and must be accompanied by the demonstrated loss of an injected transient in a masked integration. The prior tolerance-dependent C03 discovery screen, later strict physical-template score and this robustness audit are separate analyses.

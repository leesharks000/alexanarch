# L-band C03 shared-power/gain audit — fixed plan

8 November 2026. User requests the public-data follow-up after S-band testing and the discovery of a published statement that the GBT raw voltages were being transferred. This bounded analysis is the previously proposed original L-band gain audit; no external contact is made.

## Inputs and scope

Restore the six saved original fine-resolution power arrays (scans0013–0018, blc23 coarse channel7, 2.793967724Hz by6.084537003s) and the six saved high-time arrays (channels48–71,349.525333microseconds). Verify source archive/native hashes against existing ledgers. No new observing epoch. C03 and the shared OFF14 excursion were previously selected/inspected. This is an exploratory robustness/causal-mechanism audit, not an independent detection or a retrospective preregistration.

Keep the prior strict C03 coordinate1665633776.6172388Hz, Gaussian sigma1.6763806343Hz, the100existing spectral controls (+/-1..50kHz),50Hz local-background exclusion, ten128-channel background blocks per side, and inverse-control-variance temporal weighting. Reproduce all101prior strict per-scan amplitudes/scores before interpretation. Extract only the frequency tile required for these coordinates/backgrounds; original full arrays remain preserved at their original identities.

## Shared-power proxy and alignment

For each high-time RF channel, divide its native powers by its scan median. At each time, take the median over the15neighboring reference channels48–55 and65–71, excluding the nine target/boundary channels56–64. This is an empirical shared-system-power proxy g(t), not a measured astronomical gain or proof of instrumental origin. It may contain sky/interference and receiver variations.

Use actual headers to verify common start time. Expected ratio is17408high-time samples per fine integration, comprising17groups of1024samples. Preserve and report the high-time tail not represented by the49complete fine integrations. The grouping is supported by product cadence; no coherent-voltage correction can be reconstructed from powers alone.

## Fixed branches

1. ORIGINAL16: reproduce prior16-subtime Gaussian mean-power template, controls, amplitudes and score.
2. ROW-SCALAR: divide each original spectral row by its mean shared-power proxy, then re-run the same local normalization/template. A frequency-independent multiplicative factor should cancel algebraically because both row powers and their local background scale together. Verify that cancellation on actual arrays; do not interpret numerical roundoff as a physical effect.
3. UNIFORM17: use17uniform exposure positions, one at each coarse FFT group's midpoint. This controls the numerical quadrature change from16 to17positions.
4. POWER-WEIGHTED17: use the same17positions weighted by the measured mean g in their1024sample blocks, normalized to unit weight per fine integration. This tests an explicitly approximate gain-weighted mean-power exposure model. It does not model voltage phase, coherent FFT-window leakage or establish actual signal coupling to the proxy.
5. QUALITY-MASK16 (secondary): retain original16 template but omit whole fine integrations containing any overlapping complete0.1-second shared-proxy bin outside[0.8,1.2] of the scan reference. Fixed thresholds depend only on independent reference-channel powers. Refit temporal weights/averages using retained rows. Keep the original and weighted all-row branches primary; record removed exposure. This branch can discard a real transient and is not automatically a better detector.

For every branch preserve target/100control row profiles, scalar means, scores, weights, whole-cadence screen and ON/OFF contrasts. The inherited ON>=2.5/OFF<2 gate is diagnostic, not a Gaussian/global significance rule. No frequency or width tuning after results.

## Injected-line preservation and checks

At C03 and ten fixed neighboring offsets +/-5,15,25,35,45kHz, inject Gaussian mean-power lines at dimensionless integrated fractional amplitudes0.03,0.1,0.3 into actual raw power arrays. Steady injections use the corresponding exposure template; recovery is measured with frozen background comparison weights and the full local normalization. Verify analytic row-scaling cancellation and actual amplitude increments. Also inject a one-integration line in each scan's most depressed shared-power interval to expose any loss due to QUALITY-MASK16. Report model-dependent recovery; do not claim a universal weak-source safeguard or a new EIRP calibration.

Independently reconstruct selected raw-bin sums, template mass, and all whole-scan scores using Python median/fsum. Validate alignment and compare reconstructed ORIGINAL16 arrays/scores with the saved prior outputs. Plot the shared proxy with fine-bin boundaries/quality flags and C03 row profiles. Save checkpoints after input preparation, first scan, and completed run. Preserve all original input identities and full-array hashes, the smaller exact cutouts, the derived17-block proxy and the full scoring/recovery code.

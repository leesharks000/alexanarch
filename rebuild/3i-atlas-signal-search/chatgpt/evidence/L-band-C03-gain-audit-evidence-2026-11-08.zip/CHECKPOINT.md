# L-band shared-power/gain audit — complete

Input cutouts prepared: [13, 14, 15, 16, 17, 18]. Numerical audits complete: [13, 14, 15, 16, 17, 18]. All preceding astronomy projects retain their original conclusions and identities.

This archive contains the exact native fine cutouts plus the derived full high-time shared-power proxy and 17-block summaries. All completed scientific analysis can run offline from these files. The original six full fine arrays and six high-time arrays remain at their original Library identities in inputs/source-fine-ledger.json and inputs/high-native-identities.json; metadata/input-*.json records source hashes. These original full arrays are only needed to reconstruct the proxy/cutout preparation independently. They are not included in this smaller archive.

Run audit.py --force, shared_line_check.py, validate.py and report.py using versions in inputs/software-versions.json. prepare_inputs.py skips completed input pairs; recovering a missing pair requires the original archives listed above. Do not infer an older background process is still alive. Retain all five branches; row division is algebraically invariant, and masking may discard real transient emission. The power-weighted17 branch is an approximate intensity exposure test, not a voltage/phase correction.

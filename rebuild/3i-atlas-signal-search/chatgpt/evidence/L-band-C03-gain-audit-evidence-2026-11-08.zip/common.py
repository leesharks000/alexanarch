"""Fixed physical mean-power templates and explicit calibration assumptions."""
from pathlib import Path
import json,hashlib,csv,datetime
import numpy as np
from scipy.special import erf
R=Path(__file__).resolve().parent;C=299792.458
P=json.loads((R/'inputs/plan.json').read_text())
def save(path,obj):
 path=Path(path);temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(obj,indent=2,allow_nan=False));temp.replace(path)
def csvout(path,rows):
 if not rows:return
 path=Path(path);temp=path.with_suffix('.tmp')
 with temp.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 temp.replace(path)
def guard():
 proof=json.loads((R/'inputs/frozen-plan-proof.json').read_text())
 for path,digest in proof['sha256'].items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==digest
 assert all(x['status']=='succeeded' for x in proof['receipt']['results'])
def mad(x,axis=None):
 mid=np.median(x,axis=axis,keepdims=True);return 1.4826*np.median(abs(x-mid),axis=axis)
def ephemeris(site):
 result=json.loads((R/f'inputs/{site.lower()}-horizons-response.json').read_text())['result'];rows=[]
 for line in result.split('$$SOE')[1].split('$$EOE')[0].strip().splitlines():
  numbers=[]
  for v in line.split(','):
   try:numbers.append(float(v.strip()))
   except ValueError:pass
  jd=next(v for v in numbers if 2400000<v<2600000);rows.append([jd-2400000.5,numbers[-2],numbers[-1]])
 return np.asarray(rows)
def ep(obs,times):
 e=ephemeris(obs['telescope']);assert np.min(times)>=e[0,0] and np.max(times)<=e[-1,0]
 return np.interp(times,e[:,0],e[:,1]),np.interp(times,e[:,0],e[:,2])
def raw(obs):return np.load(R/obs['path'],mmap_mode='r')
def template(obs,place,receiver=False):
 tt=np.asarray(obs['times_mjd']);dt=obs['dt_s'];sub=tt[:,None]+((np.arange(P['exposure_subtimes'])+.5)/P['exposure_subtimes']-.5)*dt/86400
 dist,vel=ep(obs,sub.ravel());ratio=(1-vel/C).reshape(sub.shape)
 if receiver:ratio=np.ones_like(ratio)
 fq=place*ratio;sig=P['sigma_rest_hz']*ratio;df=obs['df_hz'];fo=obs['f0_hz'];q=(fq-fo)/df
 lo=int(np.floor(q.min()-P['template_support_sigma']*np.max(sig)/abs(df)-2));hi=int(np.ceil(q.max()+P['template_support_sigma']*np.max(sig)/abs(df)+2))+1
 assert 0<=lo<hi<=obs['shape'][1],(obs['id'],place,lo,hi)
 jj=np.arange(lo,hi);centers=fo+jj*df
 u=(centers[None,:,None]+abs(df)/2-fq[:,None,:])/(np.sqrt(2)*sig[:,None,:]);v=(centers[None,:,None]-abs(df)/2-fq[:,None,:])/(np.sqrt(2)*sig[:,None,:])
 h=np.mean(.5*(erf(u)-erf(v)),axis=2);mass=h.sum(axis=1);assert np.max(abs(mass-1))<1e-9
 return jj,h,q.mean(axis=1)
def baseline(array,q,df):
 gap=int(np.ceil(P['background_exclusion_hz']/abs(df)))+1;bs=P['background_block_channels'];nb=P['background_blocks_per_side'];centers=np.floor(q).astype(int)
 rel=np.r_[np.arange(-gap-nb*bs,-gap),np.arange(gap+1,gap+1+nb*bs)]
 ii=centers[:,None]+rel;assert ii.min()>=0 and ii.max()<array.shape[1]
 values=np.asarray(array[np.arange(len(q))[:,None],ii],float).reshape(len(q),2*nb,bs)
 blockmeans=values.mean(axis=2);base=np.median(blockmeans,axis=1);assert np.isfinite(base).all() and (base>0).all()
 return base,blockmeans

def profile(array,obs,place,receiver=False):
 jj,h,q=template(obs,place,receiver);base,blocks=baseline(array,q,obs['df_hz']);r=np.asarray(array[:,jj],float)/base[:,None]-1
 amp=(r*h).sum(axis=1)/(h*h).sum(axis=1)
 return amp,dict(jj=jj,h=h,q=q,baseline=base,blockmeans=blocks)
def scalar_profile(array,obs,place,receiver=False):
 # Independently sum original bins, rather than using vector dot products.
 jj,h,q=template(obs,place,receiver);base,_=baseline(array,q,obs['df_hz']);out=[]
 for t in range(len(array)):
  numerator=sum(float(h[t,k])*(float(array[t,int(j)])/float(base[t])-1) for k,j in enumerate(jj));denominator=sum(float(v)*float(v) for v in h[t]);out.append(numerator/denominator)
 return np.asarray(out)
def w_scan(A,obs):
 # A has target then 100 coordinate-only spectral controls.
 sigma=mad(A[1:],axis=0);assert (sigma>0).all();w=1/sigma**2
 dist,_=ep(obs,np.asarray(obs['times_mjd']));dm=float(np.median(dist));q=(dm/dist)**2
 denom=float(np.sum(w*q*q));averages=(A@(w*q))/denom;center=float(np.median(averages[1:]));scale=float(mad(averages[1:]));assert scale>0
 return dict(weights=w,row_sigma=sigma,q=q,mean=averages,center=center,scale=scale,z=(averages-center)/scale,distance_au=dm)
def power_factor(obs,sefd,distance_au):
 # Multiply fractional line amplitude by this to get equivalent isotropic W.
 return 4*np.pi*(distance_au*P['AU_m'])**2*abs(obs['df_hz'])*1e-26*sefd

def utc(mjd):return (datetime.datetime(1858,11,17,tzinfo=datetime.timezone.utc)+datetime.timedelta(days=float(mjd))).isoformat()

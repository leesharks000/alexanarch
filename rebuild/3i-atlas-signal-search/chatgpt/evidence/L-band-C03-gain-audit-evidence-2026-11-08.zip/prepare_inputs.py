from pathlib import Path
import zipfile,json,hashlib,shutil,sys
import numpy as np
R=Path(__file__).resolve().parent
for n in ['data','metadata','results','inputs/canonical']:(R/n).mkdir(parents=True,exist_ok=True)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(8<<20),b''):h.update(b)
    return h.hexdigest()
def save(p,x):
    q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(x,indent=2));q.replace(p)
def run():
    prior=R/'inputs/physical';ledger=json.loads((R/'inputs/source-fine-ledger.json').read_text());observations=json.loads((R/'inputs/source-observations.json').read_text())
    for n in ['plan.json','gbt-horizons-response.json','original13.json']:
        if (prior/'inputs'/n).exists():shutil.copyfile(prior/'inputs'/n,R/'inputs'/n)
        else:assert (R/'inputs'/n).exists()
    # Preserve the actual inherited scoring implementation as an input and use the same functions.
    if (prior/'common.py').exists():shutil.copyfile(prior/'common.py',R/'common.py')
    else:assert (R/'common.py').exists()
    allmeta=[]
    for entry in ledger:
        scan=entry['scan'];dest=R/'data'/f'input-{scan:04d}.npz';meta=R/'metadata'/f'input-{scan:04d}.json'
        if dest.exists() and meta.exists():allmeta.append(json.loads(meta.read_text()));print('PREPARED ALREADY',scan,flush=True);continue
        archive=R/'inputs/native-archives'/entry['file'];assert sha(archive)==entry['sha256']
        temp=R/'inputs/canonical'/f'full-fine-{scan:04d}.npy'
        with zipfile.ZipFile(archive) as z:
            with z.open('power.npy') as source,temp.open('wb') as out:shutil.copyfileobj(source,out)
        assert sha(temp)==entry['npy_sha256'];fine=np.load(temp,mmap_mode='r')
        old=next(x for x in observations if x['id']==f'GBT-{scan:04d}')
        f0=old['f0_hz'];df=old['df_hz'];lo=int(np.floor((1665710000.-f0)/df));hi=int(np.ceil((1665580000.-f0)/df))+1
        cut=np.asarray(fine[:,lo:hi]).copy();obs={**old,'f0_hz':f0+lo*df,'shape':list(cut.shape),'path':f'data/input-{scan:04d}.npz','tile_full_start_channel':lo,'tile_full_stop_channel':hi}
        higharchive=R/'inputs/native-archives'/f'GBT-high-time-native-{scan:04d}.zip'
        with zipfile.ZipFile(higharchive) as z:
            raw=z.read(f'data/scan-{scan:04d}.npy');hm=json.loads(z.read(f'metadata/scan-{scan:04d}.json'))
        assert hashlib.sha256(raw).hexdigest()==hm['power_sha256']
        import io
        high=np.load(io.BytesIO(raw));assert np.isfinite(high).all() and (high>0).all()
        hd=hm['attrs'];dt=float(hd['tsamp']);start=float(hd['tstart']);fine_start=old['times_mjd'][0]-old['dt_s']/2/86400
        assert abs(start-fine_start)<1e-10
        n=int(round(old['dt_s']/dt));assert n==17408 and abs(n*dt-old['dt_s'])<1e-10
        assert n%17==0
        ref=np.r_[0:8,17:24];medians=np.median(high[:,ref],axis=0);g=np.median(high[:,ref]/medians,axis=1)
        used=len(fine)*n;gb=g[:used].reshape(len(fine),17,1024).mean(axis=2);gm=gb.mean(axis=1)
        width=round(.1/dt);n100=len(g)//width;g100=g[:n100*width].reshape(n100,width).mean(axis=1)
        flags=np.flatnonzero((g100<.8)|(g100>1.2));keep=np.ones(len(fine),bool);flagrecords=[]
        for k in flags:
            first=int(k*width//n);last=int(((k+1)*width-1)//n)
            for j in range(first,min(last+1,len(fine))):keep[j]=False
            flagrecords.append({'proxy_bin':int(k),'start_s':k*width*dt,'end_s':(k+1)*width*dt,'shared_ratio':float(g100[k]),'first_fine_row':first,'last_fine_row':last})
        assert keep.sum()>=10
        q=dest.with_suffix('.partial.npz');np.savez_compressed(q,power=cut,gain_proxy=g,gain_blocks17=gb,gain_mean=gm,gain_100ms=g100,gain_100ms_width_samples=width,keep=keep,times_mjd=old['times_mjd']);q.replace(dest)
        rec={'scan':scan,'role':entry['role'],'observation':obs,'native_cutout_sha256':sha(dest),'original_fine_archive':entry,'original_high_archive_file':higharchive.name,'original_high_archive_sha256':sha(higharchive),'original_high_power_sha256':hm['power_sha256'],'original_high_source_url':hm['url'],'high_attrs':hd,'high_sample_count':len(high),'high_samples_used':used,'high_tail_samples_not_in_fine_product':len(high)-used,'high_to_fine_ratio':n,'block_count':17,'samples_per_block':1024,'proxy_reference_channels':list(range(48,56))+list(range(65,72)),'quality_flag_records':flagrecords,'removed_fine_rows':np.flatnonzero(~keep).tolist(),'mean_proxy_min':float(gm.min()),'mean_proxy_max':float(gm.max()),'minimum_100ms_proxy':float(g100.min())}
        save(meta,rec);allmeta.append(rec);print('PREPARED',scan,'rows removed',rec['removed_fine_rows'],'mean proxy min',rec['mean_proxy_min'],flush=True)
    save(R/'inputs/input-ledger.json',allmeta)
if __name__=='__main__':run()

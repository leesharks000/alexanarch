from pathlib import Path
import json,hashlib,zipfile,sys
R=Path(__file__).resolve().parent
def pack(final=False):
    prepared=sorted(int(x.stem[-4:]) for x in (R/'metadata').glob('input-*.json'))
    analyzed=sorted(int(x.stem[-4:]) for x in (R/'results').glob('audit-*.json'))
    state={'status':'complete' if final else 'completed numerical batch; report may be pending','prepared':prepared,'analyzed':analyzed,'summary_exists':(R/'results/summary.json').exists(),'validation_exists':(R/'results/validation.json').exists()}
    (R/'results/checkpoint-state.json').write_text(json.dumps(state,indent=2))
    text='# L-band shared-power/gain audit — '+state['status']+'\n\n'
    text+='Input cutouts prepared: '+str(prepared)+'. Numerical audits complete: '+str(analyzed)+'. All preceding astronomy projects retain their original conclusions and identities.\n\n'
    text+='This archive contains the exact native fine cutouts plus the derived full high-time shared-power proxy and 17-block summaries. All completed scientific analysis can run offline from these files. The original six full fine arrays and six high-time arrays remain at their original Library identities in inputs/source-fine-ledger.json and inputs/high-native-identities.json; metadata/input-*.json records source hashes. These original full arrays are only needed to reconstruct the proxy/cutout preparation independently. They are not included in this smaller archive.\n\n'
    text+='Run audit.py --force, shared_line_check.py, validate.py and report.py using versions in inputs/software-versions.json. prepare_inputs.py skips completed input pairs; recovering a missing pair requires the original archives listed above. Do not infer an older background process is still alive. Retain all five branches; row division is algebraically invariant, and masking may discard real transient emission. The power-weighted17 branch is an approximate intensity exposure test, not a voltage/phase correction.\n'
    (R/'CHECKPOINT.md').write_text(text)
    data={}
    for f in R.rglob('*'):
        if not f.is_file():continue
        rel=f.relative_to(R)
        if any(s in rel.parts for s in ['native-archives','canonical','physical','high-time','helpers','continuity','__pycache__']):continue
        if f.suffix=='.zip' or '.partial.' in f.name or f.name=='SHA256SUMS.json':continue
        data[str(rel)]=f.read_bytes()
    sums={n:hashlib.sha256(b).hexdigest() for n,b in data.items()};ss=json.dumps(sums,indent=2).encode();(R/'SHA256SUMS.json').write_bytes(ss)
    with zipfile.ZipFile(R/'L-band-C03-gain-audit-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        for n,b in data.items():z.writestr(n,b)
        z.writestr('SHA256SUMS.json',ss)
    print(json.dumps(state));print('archive bytes',(R/'L-band-C03-gain-audit-evidence.zip').stat().st_size)
if __name__=='__main__':pack('final' in sys.argv)

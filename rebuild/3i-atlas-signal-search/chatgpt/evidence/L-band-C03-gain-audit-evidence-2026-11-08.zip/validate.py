import json,hashlib,math,csv
from statistics import median
import numpy as np
import audit as a
R=a.R
def run():
    checks=[];hashes=[]
    for scan in range(13,19):
        m=json.loads((R/'metadata'/f'input-{scan:04d}.json').read_text());z=np.load(R/'data'/f'input-{scan:04d}.npz')
        digest=hashlib.sha256((R/'data'/f'input-{scan:04d}.npz').read_bytes()).hexdigest();assert digest==m['native_cutout_sha256'];hashes.append({'scan':scan,'sha256':digest})
        assert m['high_to_fine_ratio']==17408 and m['samples_per_block']==1024 and m['block_count']==17
        reconstructed=z['gain_proxy'][:49*17408].reshape(49,17,1024).mean(axis=2)
        assert np.array_equal(reconstructed,z['gain_blocks17'])
        for branch in a.BRANCHES:
            p=np.load(R/'results'/f'profiles-{scan:04d}-{branch}.npz');mask=p['mask'];A=p['A'][:,mask];q=p['q'];weights=[]
            for t in range(A.shape[1]):
                vals=list(map(float,A[1:,t]));mid=median(vals);sigma=1.4826*median([abs(x-mid) for x in vals]);weights.append(1/sigma**2)
            denom=math.fsum(w*float(qq)**2 for w,qq in zip(weights,q));means=[math.fsum(float(v)*w*float(qq) for v,w,qq in zip(row,weights,q))/denom for row in A]
            mid=median(means[1:]);scale=1.4826*median([abs(v-mid) for v in means[1:]]);score=(means[0]-mid)/scale;err=abs(score-float(p['z'][0]));assert err<1e-9
            checks.append({'scan':scan,'branch':branch,'independent_score':score,'stored_score':float(p['z'][0]),'error':err})
    with (R/'results/all-injection-trials.csv').open() as f:trials=list(csv.DictReader(f))
    assert len(trials)==1020
    # A quality mask must acknowledge loss of a transient located in a removed integration.
    lost=[r for r in trials if r['scan']=='14' and r['branch']=='quality_mask16' and r['injection']=='one_integration_at_deepest_proxy']
    assert len(lost)==1 and float(lost[0]['target_retained_fraction'])==0
    shared=json.loads((R/'results/shared-original-line-recovery.json').read_text());assert shared['trials']==90
    result={'passed':True,'input_cutout_hashes':hashes,'alignment_checks':6,'independent_score_checks':checks,'maximum_score_error':max(x['error'] for x in checks),'self_matched_mean_power_injections':len(trials),'shared_original_signal_injections':shared['trials'],'maximum_injection_increment_error':max(float(r['recovered_increment_max_error']) for r in trials),'quality_mask_loses_flagged_transient':True}
    a.save(R/'results/validation.json',result);print('VALIDATED',len(checks),'scores;1110 injection trials',flush=True)
if __name__=='__main__':run()

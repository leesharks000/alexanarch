"""Resolve metadata only for the first known ATA discovery observation."""
import json,urllib.request,urllib.parse,hashlib
from pathlib import Path
from html.parser import HTMLParser
import h5py
from remote_h5 import RemoteRange,clean
ROOT=Path(__file__).resolve().parent
class Links(HTMLParser):
 def __init__(self):super().__init__();self.links=[]
 def handle_starttag(self,tag,attrs):
  if tag=='a':
   h=dict(attrs).get('href','')
   if h and h!='../' and not h.startswith('?'):self.links.append(h)
def links(url):
 with urllib.request.urlopen(url,timeout=30) as f:raw=f.read(200000)
 p=Links();p.feed(raw.decode());return [urllib.parse.urljoin(url,h) for h in p.links]
def run():
 inv=json.loads((ROOT/'inputs/prior-inventory.json').read_text());session=next(s for s in inv['sessions'] if '2025-07-03' in s['url']);scan=session['links'][0]
 folders=[u for u in links(scan) if '/LoD.' in u]
 assert folders
 folders=sorted(folders,key=lambda u:int(u.rstrip('/').split('C')[-1]))
 result={'scope':'metadata only; no data or mask dataset slice','scan':scan,'all_LoD_folders':folders,'files':[]}
 # Highest named subband, plus the previously used middle subband.
 selected=[folders[-1],next(u for u in folders if '/LoD.C0928/' in u)]
 for folder in selected:
  urls=sorted(u for u in links(folder) if u.endswith('.fbh5'));assert len(urls)==2
  for beam,url in enumerate(urls):
   dest=ROOT/f'inputs/metadata-{folder.rstrip("/").split("/")[-1]}-beam{beam}.json'
   if dest.exists():r=json.loads(dest.read_text());result['files'].append(r);continue
   rr=RemoteRange(url,budget=1<<20)
   with h5py.File(rr,'r') as f:
    data=f['data'];attrs={k:clean(v) for k,v in data.attrs.items()};shape=list(data.shape)
    r={'url':url,'folder':folder,'beam':beam,'attrs':attrs,'shape':shape,'chunks':list(data.chunks),'dtype':str(data.dtype),'filters':data._filters,
       'mask_shape':list(f['mask'].shape),'mask_chunks':list(f['mask'].chunks),'mask_filters':f['mask']._filters,
       'first_center_MHz':attrs['fch1'],'last_center_MHz':attrs['fch1']+(shape[-1]-1)*attrs['foff'],'ranges':rr.manifest()}
   dest.write_text(json.dumps(r,indent=2));result['files'].append(r)
   directory=ROOT/'metadata-heads'/hashlib.sha256(url.encode()).hexdigest();directory.mkdir(parents=True,exist_ok=True)
   for block,raw in rr.cache.items():(directory/f'{block:09}.bin').write_bytes(raw)
   print('METADATA',r['folder'].rstrip('/').split('/')[-1],beam,r['first_center_MHz'],r['last_center_MHz'],flush=True)
 (ROOT/'inputs/source-metadata.json').write_text(json.dumps(result,indent=2))
if __name__=='__main__':run()

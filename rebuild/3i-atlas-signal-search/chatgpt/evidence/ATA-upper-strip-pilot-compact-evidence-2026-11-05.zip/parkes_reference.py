"""Reference-only SIGPROC quality slices. Preserves negative foff."""
import json,struct,hashlib,urllib.request,concurrent.futures,zipfile
from pathlib import Path
import numpy as np
from acquire_pilot import guard,save,sha,R,get_range
STRING={'source_name','rawdatafile'}
INT={'telescope_id','machine_id','data_type','barycentric','pulsarcentric','nbits','nsamples','nchans','nifs','nbeams','ibeam','signed'}
DOUBLE={'az_start','za_start','src_raj','src_dej','tstart','tsamp','fch1','foff','refdm','period'}
def header(b):
 at=0
 def string():
  nonlocal at
  n=struct.unpack_from('<i',b,at)[0];at+=4;assert 0<n<10000;s=b[at:at+n].decode();at+=n;return s
 assert string()=='HEADER_START';a={}
 while True:
  k=string()
  if k=='HEADER_END':return a,at
  if k in STRING:a[k]=string()
  elif k in INT:a[k]=struct.unpack_from('<i',b,at)[0];at+=4
  elif k in DOUBLE:a[k]=struct.unpack_from('<d',b,at)[0];at+=8
  else:raise ValueError(('unknown SIGPROC key',k,at))
def run():
 p=guard();url=p['parkes_reference_url'];assert '_R_' in url and '_S_' not in url
 directory=R/'parkes-ranges';directory.mkdir(exist_ok=True)
 hp=directory/'header.bin';mp=directory/'header.json'
 if not mp.exists():
  with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':'bytes=0-4095'}),timeout=45) as f:
   assert f.status==206;b=f.read(4097);total=int(f.headers['Content-Range'].split('/')[-1]);assert len(b)==4096
  a,nhead=header(b);hp.write_bytes(b[:nhead]);save(mp,dict(url=url,attrs=a,header_bytes=nhead,source_bytes=total,header_sha256=sha(b[:nhead])))
 m=json.loads(mp.read_text());a=m['attrs'];assert a['nbits']==32 and a['nifs']==1 and a['foff']<0
 n=(m['source_bytes']-m['header_bytes'])//(a['nchans']*4);assert n==20 and (m['source_bytes']-m['header_bytes'])%(a['nchans']*4)==0
 for reg in p['regions']:
  if reg['name']=='centre':continue
  dest=R/f"native/parkes-reference-{reg['name']}.npz"
  if dest.exists():assert zipfile.ZipFile(dest).testzip() is None;continue
  # Physical lower/upper bounds become reversed channel coordinates.
  q=[(v/1e6-a['fch1'])/a['foff'] for v in [reg['lo'],reg['hi']]];lo=int(np.floor(min(q)));hi=int(np.ceil(max(q)))+1
  assert 0<=lo<hi<=a['nchans'];entries=[dict(t=t,offset=m['header_bytes']+(t*a['nchans']+lo)*4,size=(hi-lo)*4) for t in range(n)]
  def get(e):
   cp=directory/f"{e['offset']}-{e['size']}.bin";sp=cp.with_suffix('.sha256')
   if cp.exists() and sp.exists():b=cp.read_bytes();assert sha(b)==sp.read_text()
   else:
    b=get_range(url,e['offset'],e['offset']+e['size']-1,m['source_bytes']);tmp=cp.with_suffix('.tmp');tmp.write_bytes(b);tmp.replace(cp);sp.write_text(sha(b))
   assert len(b)==e['size'];e['sha256']=sha(b);return np.frombuffer(b,dtype='<f4')
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:raw=np.stack(list(pool.map(get,entries)))
  assert np.isfinite(raw).all();meta=dict(**m,shape=list(raw.shape),start_channel=lo,stop_channel=hi,entries=entries,region=reg,power_sha256=sha(raw.tobytes()),scope='reference only; no comet ephemeris or source powers')
  tmp=dest.with_suffix('.tmp')
  with tmp.open('wb') as fp:np.savez_compressed(fp,power=raw,metadata=json.dumps(meta))
  assert zipfile.ZipFile(tmp).testzip() is None;tmp.replace(dest);save(dest.with_suffix('.json'),dict(file=dest.name,sha256=sha(dest.read_bytes()),bytes=dest.stat().st_size,metadata=meta))
  print('PARKES REFERENCE SAVED',reg['name'],raw.shape,flush=True)
if __name__=='__main__':run()

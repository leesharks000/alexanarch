"""Read HDF5 v1 rank-3 chunk B-trees; exact keys, validated against HDF5 API."""
import struct,bisect

def root(b,itemsize):
 at=0;found=[]
 while True:
  at=b.find(b'TREE\x01\x01',at)
  if at<0:break
  n=struct.unpack_from('<H',b,at+6)[0]
  if 1<=n<=64 and at+24+48*n+40<=len(b):
   keys=[struct.unpack_from('<II4Q',b,at+24+48*i) for i in range(n+1)]
   if keys[-1][-1]==itemsize and keys[0][0]>262144*itemsize and keys[0][0]<262144*itemsize+1024:
    found.append((at,keys,[struct.unpack_from('<Q',b,at+24+48*i+40)[0] for i in range(n)]))
  at+=1
 assert len(found)==1,(itemsize,len(found))
 return found[0]

def entries(rr,coordinates,key,dtype):
 itemsize=4 if dtype=='float32' else 1
 off,rows,pointers=root(rr.cache[0],itemsize);keys=[tuple(x[2:]) for x in rows];assert keys==sorted(keys)
 chosen={}
 for coord in coordinates:
  i=bisect.bisect_right(keys,tuple(coord))-1;assert 0<=i<len(pointers);chosen.setdefault(pointers[i],[]).append(tuple(coord))
 out=[]
 for pointer,coords in sorted(chosen.items()):
  rr.seek(pointer);head=rr.read(24);assert head[:6]==b'TREE\x01\x00';n=struct.unpack_from('<H',head,6)[0];assert 1<=n<=64
  rr.seek(pointer+24);b=rr.read(48*n+40);leaf={}
  for i in range(n):
   vals=struct.unpack_from('<II4Q',b,48*i);offset=struct.unpack_from('<Q',b,48*i+40)[0];leaf[tuple(vals[2:])]=(vals[0],vals[1],offset)
  for coord in coords:
   size,filter_mask,offset=leaf[coord];assert 0<offset<offset+size<=rr.size
   t,feed,c,last=coord;assert feed==last==0
   out.append(dict(key=key,t=t,start=c,byte_offset=offset,size=size,filter_mask=filter_mask,dtype=dtype))
 return out

"""Sequential stages with durable saves and version-guarded resume updates."""
from pathlib import Path
import json,subprocess,sys
from acquire_pilot import R,save

def cp_version():
 receipts=[(p.stat().st_mtime,p) for p in (R/'results').glob('save-*.json') if p.stat().st_size]
 for _,p in sorted(receipts,reverse=True):
  try:s=json.loads(p.read_text())
  except ValueError:continue
  for x in reversed(s.get('results',[])):
   if x.get('library_file_id')=='libfile_349f1c1635808191b815fee10ce169d7' and x.get('status')=='succeeded':return x['current_version_number']
 raise RuntimeError('no confirmed CP version')

def persist(stage):
 dest=R/f'results/save-stage-{stage}.json'
 if dest.exists():
  rec=json.loads(dest.read_text());assert all(x['status']=='succeeded' for x in rec['results']);return rec
 subprocess.run([sys.executable,'save_stage.py',stage],cwd=R,check=True)
 archive=R/f'ATA-upper-pilot-{stage}-evidence.zip'
 uploads=[dict(local_path=str(archive),purpose='create_library_file',library_artifact_type='other'),dict(local_path=str(R/'3I-ATLAS-RESUME.md'),purpose='replace_library_file',library_file_id='libfile_349f1c1635808191b815fee10ce169d7',expected_current_version=cp_version(),version_reason=f'ATA upper-strip pilot {stage} acquisition checkpoint')]
 with dest.open('w') as out:
  result=subprocess.run([sys.executable,'helpers/library_upload.py'],input=json.dumps(dict(uploads=uploads)),text=True,cwd=R,stdout=out)
 assert result.returncode==0,('save not confirmed; inspect before retry',stage)
 receipt=json.loads(dest.read_text());assert all(x['status']=='succeeded' for x in receipt['results'])
 print('DURABLY SAVED',stage,[(x['library_file_id'],x.get('current_version_number')) for x in receipt['results']],flush=True)
 return receipt
if __name__=='__main__':
 for stage in sys.argv[1:]:
  if stage=='parkes':subprocess.run([sys.executable,'-u','parkes_reference.py'],cwd=R,check=True)
  elif stage!='save-C1504-0':
   sub,b=stage.split('-');subprocess.run([sys.executable,'-u','acquire_pilot.py',sub,b],cwd=R,check=True)
  persist(stage.removeprefix('save-'))

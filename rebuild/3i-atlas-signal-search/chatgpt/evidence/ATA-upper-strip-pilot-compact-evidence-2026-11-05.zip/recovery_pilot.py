"""Fixed injection recovery; known coordinates only, no candidate generation."""
from pathlib import Path
import json,hashlib,importlib.metadata,sys
import numpy as np
from scipy.special import erf
import core as s
from acquire_pilot import guard,save,sha,R
FRAME=dict(name='true',kind='true',delta=0.)
def inject(raw,m,place,amp,L):
 a=m['beams'][0]['attrs'];df=a['foff']*1e6;lo=m['beams'][0]['start_channel'];out=raw.copy();sig=.6;noise=[];den=1-s.rv([s.reference()])[0]/s.C
 for t in range(len(raw)):
  subt=a['tstart']+(t+(np.arange(16)+.5)/16)*a['tsamp']/86400
  u=(place*(1-s.rv(subt)/s.C)/den-a['fch1']*1e6)/df-lo
  window=np.arange(max(0,int(u.mean()-5000/abs(df))),min(raw.shape[1],int(u.mean()+5000/abs(df))))
  vv=raw[t,window[abs(window-u.mean())*abs(df)>50]];med=np.median(vv);mad=float(1.4826*np.median(abs(vv-med)));noise.append(mad)
  if t>=L:continue
  jj=np.arange(int(np.floor(u.min()-7)),int(np.ceil(u.max()+7))+1)
  shape=np.mean(sig*np.sqrt(np.pi/2)*(erf((jj[:,None]+.5-u[None,:])/(np.sqrt(2)*sig))-erf((jj[:,None]-.5-u[None,:])/(np.sqrt(2)*sig))),axis=1)
  out[t,jj]=(raw[t,jj].astype(float)+amp*mad*shape).astype(np.float32)
 return out,noise

def scores(prefix,m,grid,L):
 q,step,width,tt,rate=s.geometry(m,FRAME,grid)
 assert min(q)-width//2>=0 and max(q+step*(len(grid)-1))+width//2+2<prefix.shape[1]-1
 power=s.sampled(prefix[:L],q[:L],step[:L],width,len(grid)).sum(axis=0)
 z,cal=s.standard(power);return z,cal,dict(width=width,q=q,step=step,rate=rate)

def direct(raw,m,grid,L,k,cal,g):
 """Independent direct native-bin sum; recomputes row normalization from raw."""
 n,nc=raw.shape;block=np.median(raw.reshape(n,nc//1024,1024),axis=2);value=0.;width=g['width'];h=width//2
 for t in range(L):
  base=np.interp(np.arange(nc),np.arange(nc//1024)*1024+511.5,block[t]).astype(np.float32)
  x=raw[t]/base-1;mid=np.median(x);scale=1.4826*np.median(abs(x-mid));v=(x-mid)/scale
  q=g['q'][t]+g['step'][t]*k;j=int(np.floor(q));w=q-j
  value+=(1-w)*np.asarray(v[j-h:j+h+1],float).sum()+w*np.asarray(v[j+1-h:j+h+2],float).sum()
 return (value-cal['center'])/cal['scale']

def checks():
 maxerr=0.
 for center in [0.,.25,.5,.75]:
  for j in [-2,-1,0,1]:
   x=np.linspace(j-.5,j+.5,20001);num=np.trapezoid(np.exp(-.5*((x-center)/.6)**2),x)
   exact=.6*np.sqrt(np.pi/2)*(erf((j+.5-center)/(np.sqrt(2)*.6))-erf((j-.5-center)/(np.sqrt(2)*.6)))
   maxerr=max(maxerr,abs(num-exact))
 assert maxerr<1e-8
 rng=np.random.default_rng(1115);x=rng.normal(size=(7,4096));p=np.column_stack((np.zeros(7),np.cumsum(x,axis=1)));pr=np.column_stack((np.zeros(7),np.cumsum(x[:,::-1],axis=1)))
 q=1700-.42*np.arange(7);step=np.full(7,1.25);v=s.sampled(p,q,step,7,31);vr=s.sampled(pr,4095-q,-step,7,31)
 error=float(np.max(abs(v-vr)));assert error<1e-10
 return dict(gaussian_quadrature_max_error=maxerr,ascending_descending_axis_max_error=error,versions={k:importlib.metadata.version(k) for k in ['numpy','scipy','numba','h5py','hdf5plugin','matplotlib']})

def quality(raw,meta,region):
 a=meta['attrs'];df=a['foff']*1e6;f=a['fch1']*1e6+meta['start_channel']*df
 ii=np.arange(raw.shape[1]);sel=(f+ii*df>=region['lo'])&(f+ii*df<region['hi']);x=raw[:,sel]
 rowmed=np.median(x,axis=1);mad=1.4826*np.median(abs(x-rowmed[:,None]),axis=1)
 return dict(n_integrations=len(x),channels_per_integration=x.shape[1],axis_step_hz=df,first_selected_center_hz=float((f+ii*df)[sel][0]),last_selected_center_hz=float((f+ii*df)[sel][-1]),finite_fraction=float(np.isfinite(x).mean()),positive_fraction=float((x>0).mean()),row_median=rowmed.astype(float).tolist(),row_raw_mad=mad.astype(float).tolist(),median_row_power=float(np.median(rowmed)),median_row_mad=float(np.median(mad)),relative_row_mad_to_power=float(np.median(mad/rowmed)),fraction_gt_row_median_plus_8mad=float((x>rowmed[:,None]+8*mad[:,None]).mean()),median_row_quantiles=np.median(np.quantile(x,[.01,.1,.5,.9,.99],axis=1),axis=1).tolist(),scope='relative raw-power diagnostics; not flux/SEFD or absolute sensitivity')

def run(names):
 p=guard();initial=checks();save(R/'results/software-checks.json',initial)
 for ri,reg in enumerate(p['regions']):
  if names and reg['name'] not in names:continue
  zz=[np.load(R/f"native/ata-{reg['name']}-beam{b}.npz") for b in [0,1]];m=dict(beams=[json.loads(str(z['metadata'])) for z in zz]);raw=[z['power'] for z in zz];mask=[z['mask'] for z in zz]
  for b in [0,1]:
   assert sha(raw[b].tobytes())==m['beams'][b]['power_sha256'];assert sha(mask[b].tobytes())==m['beams'][b]['mask_sha256'];assert not np.any(mask[b]);assert np.isfinite(raw[b]).all()
   for k in ['tstart','tsamp','fch1','foff','nchans']:assert m['beams'][b]['attrs'][k]==m['beams'][0]['attrs'][k]
  a=m['beams'][0]['attrs'];df=a['foff']*1e6;ref=a['tstart']+.5*a['tsamp']/86400;s.reference=lambda:ref
  grid=np.arange(reg['lo'],reg['hi'],p['grid_hz']);q,step,width,tt,rate=s.geometry(m,FRAME,grid)
  guess=reg['lo']+.375e6;place=a['fch1']*1e6+(np.round((guess-a['fch1']*1e6)/df)+p['phase_native_bins'][ri])*df
  zero,_=inject(raw[0],m,place,0,19);assert np.array_equal(zero,raw[0]);del zero
  diagnostic=dict(region=reg,place_hz=float(place),zero_amplitude_bitwise_equal=True,drift_hz_s=rate.tolist(),width_native_bins=width,beams=[quality(raw[b],m['beams'][b],reg) for b in [0,1]],source_urls=[b['url'] for b in m['beams']],scope='pilot; no candidate selection')
  save(R/f"results/quality-{reg['name']}.json",diagnostic)
  base,basecal=s.normalize(raw[1],mask[1]);baseline={L:scores(base,m,grid,L)[:2] for L in p['durations']};del base
  for amp in p['injection_amplitudes_raw_MAD']:
   for L in p['durations']:
    dest=R/f"results/recovery-{reg['name']}-a{amp}-L{L}.json"
    if dest.exists():continue
    mod,noise=inject(raw[0],m,place,amp,L);delta=mod.astype(float)-raw[0].astype(float);prefix,rowcal=s.normalize(mod,mask[0]);z0,cal0,g=scores(prefix,m,grid,L);del prefix
    near=np.flatnonzero(abs(grid-place)<=df);assert len(near)>0;cases=[]
    for occupancy in p['occupancies']:
     if occupancy=='target_only':z1,cal1=baseline[L];other=raw[1]
     else:
      other=(raw[1].astype(float)+delta).astype(np.float32);pref,unused=s.normalize(other,mask[1]);z1,cal1,unused=scores(pref,m,grid,L);del pref
     J=z0-np.maximum(z1,0);eligible=near[(z0[near]>=p['gate']['on'])&(J[near]>=p['gate']['j'])];select=eligible if len(eligible) else near;k=int(select[np.argmax(J[select])])
     direct0=direct(mod,m,grid,L,k,cal0,g);direct1=direct(other,m,grid,L,k,cal1,g);err=max(abs(direct0-z0[k]),abs(direct1-z1[k]));assert err<1e-5,err
     rec=dict(region=reg['name'],placement_hz=float(place),amplitude_raw_row_MAD=amp,L=L,start=0,occupancy=occupancy,screen=bool(len(eligible)),eligible_cells=len(eligible),frequency_hz=float(grid[k]),z_target=float(z0[k]),z_reference=float(z1[k]),J=float(J[k]),direct_score_max_error=float(err),calibration=[cal0,cal1],raw_row_MAD=noise)
     cases.append(rec);print('RECOVERY',reg['name'],amp,L,occupancy,rec['screen'],round(rec['z_target'],3),round(rec['J'],3),flush=True)
    save(dest,cases)
  print('REGION COMPLETE',reg['name'],flush=True)
 rows=[x for path in sorted((R/'results').glob('recovery-*-a*-L*.json')) for x in json.loads(path.read_text())]
 strong=[x for x in rows if x['amplitude_raw_row_MAD']==16 and x['L'] in [4,19] and x['occupancy']=='target_only']
 save(R/'results/recovery-summary.json',dict(n=len(rows),complete=len(rows)==96,strong_required_cases=len(strong),strong_required_all_pass=len(strong)==8 and all(x['screen'] for x in strong),cases=rows))
if __name__=='__main__':run(sys.argv[1:])

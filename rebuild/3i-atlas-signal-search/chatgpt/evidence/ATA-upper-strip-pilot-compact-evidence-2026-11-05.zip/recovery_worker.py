"""Run fixed recoveries as soon as each paired acquisition is complete."""
from pathlib import Path
import subprocess,sys,time
R=Path(__file__).resolve().parent
for names in [['low','middle','edge'],['centre']]:
 while not all((R/f'native/ata-{name}-beam{b}.npz').exists() for name in names for b in [0,1]):time.sleep(5)
 subprocess.run([sys.executable,'-u','recovery_pilot.py',*names],cwd=R,check=True)

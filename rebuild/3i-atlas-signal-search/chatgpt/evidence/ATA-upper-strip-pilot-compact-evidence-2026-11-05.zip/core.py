"""Detector arithmetic. Use search.py to configure a tile; no standalone search."""
from pathlib import Path
import json,sys,time,tempfile
import numpy as np
from numba import njit
from scipy.ndimage import maximum_filter1d
R=Path(__file__).resolve().parent;C=299792.458
hp=json.loads((R/'inputs/horizons-response.json').read_text())['result'].split('$$SOE')[1].split('$$EOE')[0]
EP=np.array([[float(c[0])-2400000.5,float(c[-1])] for c in [[v.strip() for v in l.split(',') if v.strip()] for l in hp.strip().splitlines()]])
def rv(t):
 t=np.asarray(t);assert t.min()>=EP[0,0] and t.max()<=EP[-1,0];return np.interp(t,EP[:,0],EP[:,1])
def save(name,obj):
 p=R/'results'/name
 with tempfile.NamedTemporaryFile('w',dir=p.parent,prefix=p.name+'.',suffix='.tmp',delete=False) as f:f.write(json.dumps(obj,indent=2,allow_nan=False));tmp=Path(f.name)
 tmp.replace(p)
def load(index):
 raise RuntimeError('Configure a current tile through search.configure first')
def reference():
 raise RuntimeError('Configure the global reference through search.configure first')
def frames():
 return [dict(name='true',kind='true',delta=0.),dict(name='flipped',kind='flipped',delta=0.),dict(name='receiver',kind='receiver',delta=0.)]+[dict(name=f'wrong-{i:02}',kind='true',delta=float(v)) for i,v in enumerate(np.r_[-np.linspace(.03,1,20),np.linspace(.03,1,20)])]
def normalize(raw,mask):
 n,nc=raw.shape;assert nc%1024==0;assert not np.any(mask),'Nonzero masks: stop for explicit masked-path handling before any scoring'
 block=np.median(raw.reshape(n,nc//1024,1024),axis=2);out=np.empty((n,nc+1));out[:,0]=0;cal=[]
 for t in range(n):
  base=np.interp(np.arange(nc),np.arange(nc//1024)*1024+511.5,block[t]).astype(np.float32)
  x=raw[t]/base-1;mid=np.median(x);scale=1.4826*np.median(abs(x-mid));assert scale>0
  out[t,1:]=np.cumsum(np.asarray((x-mid)/scale,float));cal.append(dict(center=float(mid),scale=float(scale)))
 return out,cal
def geometry(m,frame,grid):
 a=m['beams'][0]['attrs'];df=a['foff']*1e6;tt=a['tstart']+(np.arange(m['beams'][0]['shape'][0])+.5)*a['tsamp']/86400;tref=reference();den=1-rv(np.array([tref]))[0]/C
 ratio=(1-rv(tt)/C)/den
 deriv=-((rv(tt+a['tsamp']/2/86400)-rv(tt-a['tsamp']/2/86400))/(a['tsamp']))/C/den
 if frame['kind']=='flipped':ratio=2-ratio;deriv=-deriv
 if frame['kind']=='receiver':ratio=np.ones_like(ratio);deriv=np.zeros_like(ratio)
 rate=np.mean(grid)*deriv+frame['delta'];width=int(3+np.ceil(np.max(abs(rate))*a['tsamp']/df));width+=1-width%2
 q0=(grid[0]*ratio+frame['delta']*((tt-tref)*86400)-a['fch1']*1e6)/df-m['beams'][0]['start_channel'];step=(grid[1]-grid[0])*ratio/df
 return q0,step,width,tt,rate
@njit(cache=True)
def sampled(prefix,q0,step,width,nfreq):
 n=len(q0);out=np.empty((n,nfreq));h=width//2
 for t in range(n):
  for k in range(nfreq):
   q=q0[t]+step[t]*k;j=int(np.floor(q));w=q-j
   out[t,k]=(1-w)*(prefix[t,j+h+1]-prefix[t,j-h])+w*(prefix[t,j+h+2]-prefix[t,j+1-h])
 return out
def standard(x):
 center=float(np.median(x));scale=float(1.4826*np.median(abs(x-center)));assert scale>0;return (x-center)/scale,dict(center=center,scale=scale)
def gridfull(m):
 raise RuntimeError('Configure the current tile grid through search.configure first')
def evaluate(index,frame,grid,prefixes,m,keep_map=False,durations=None):
 q0,step,width,tt,rate=geometry(m,frame,grid);n=len(tt)
 nc=prefixes[0].shape[1]-1
 assert np.min(q0)-width//2>=0 and np.max(q0+step*(len(grid)-1))+width//2+2<nc
 paths=[sampled(p,q0,step,width,len(grid)) for p in prefixes]
 cum=[np.vstack((np.zeros(len(grid)),np.cumsum(p,axis=0))) for p in paths];del paths
 best=dict(J=-1e100);swap=dict(J=-1e100);cals=[];pool=[];by_duration={};gate_counts=[];gate_indices=[];gate_lengths=[];gate_starts=[]
 maxj=np.full(len(grid),-np.inf,np.float32);argL=np.zeros(len(grid),np.uint8);argS=np.zeros(len(grid),np.uint8)
 for L in (durations or [1,4,8,19]):
  if L>n:continue
  for start in range(n-L+1):
   zz=[];cc=[]
   for cb in cum:
    z,ca=standard(cb[start+L]-cb[start]);zz.append(z);cc.append(ca)
   z0,z1=zz;J=z0-np.maximum(z1,0);js=z1-np.maximum(z0,0);j=int(np.argmax(J));ks=int(np.argmax(js))
   def record(k,score,on,off):return dict(pair=index,frame=frame['name'],frequency_hz=float(grid[k]),frequency_index=int(k),L=int(L),start=int(start),J=float(score[k]),z_target=float(on[k]),z_reference=float(off[k]),width=width)
   if J[j]>best['J']:best=record(j,J,z0,z1)
   if js[ks]>swap['J']:swap=record(ks,js,z1,z0)
   if L not in by_duration or J[j]>by_duration[L]['J']:by_duration[L]=record(j,J,z0,z1)
   cals.append(dict(L=L,start=start,beams=cc))
   eligible=(z0>=6)&(J>=3);passed=np.flatnonzero(eligible)
   gate_counts.append(dict(L=L,start=start,n=int(len(passed)),max_target=float(np.max(z0)),best_eligible=record(int(passed[np.argmax(J[passed])]),J,z0,z1) if len(passed) else None))
   if keep_map:
    changed=J>maxj;maxj[changed]=J[changed];argL[changed]=L;argS[changed]=start
    # Keep every screened local peak, plus enough highest peaks for5clusters.
    local=J==maximum_filter1d(J,11,mode='nearest');eligible=(z0>=6)&(J>=3)
    ii=np.flatnonzero(eligible|(local&(J>=J[j]-2)))
    pool.extend(record(k,J,z0,z1) for k in ii)
    gate_indices.append(passed.astype(np.uint32));gate_lengths.append(np.full(len(passed),L,np.uint8));gate_starts.append(np.full(len(passed),start,np.uint8))
 print('SCORED',index,frame['name'],'width',width,'best',best['J'],flush=True)
 result=dict(pair=index,frame=frame,grid_start_hz=float(grid[0]),grid_stop_hz=float(grid[-1]),grid_n=len(grid),width=width,drift_hz_s=rate.tolist(),best=best,by_duration=by_duration,swapped_best=swap,calibrations=cals,gate_counts=gate_counts,gate_passing_cells=sum(x['n'] for x in gate_counts))
 if keep_map:
  np.savez_compressed(R/f'results/surface-{index}-{frame["name"]}.npz',frequency=grid,maxJ=maxj,length=argL,start=argS)
  result['peaks']=pool
  np.savez_compressed(R/f'results/gates-{index}-{frame["name"]}.npz',frequency_index=np.concatenate(gate_indices),length=np.concatenate(gate_lengths),start=np.concatenate(gate_starts))
 return result
def discovery(index):
 z,m=load(index);prefix=[];rowcal=[]
 for b in [0,1]:p,ca=normalize(z[f'power{b}'],z[f'mask{b}']);prefix.append(p);rowcal.append(ca)
 save(f'rowcal-{index}.json',rowcal);grid=gridfull(m)
 for frame in frames():
  out=R/f'results/discovery-{index}-{frame["name"]}.json'
  if out.exists():continue
  rec=evaluate(index,frame,grid,prefix,m,frame['name'] in ['true','flipped','receiver'])
  rec['provenance']={'context':search_context,'source_beams':[{'url':b['url'],'power_sha256':b['power_sha256'],'mask_sha256':b['mask_sha256'],'attrs':b['attrs'],'start_channel':b['start_channel'],'stop_channel':b['stop_channel']} for b in m['beams']]}
  save(out.name,rec)
if __name__=='__main__':
 raise SystemExit('Use search.py INDEX [TILE ...]; this arithmetic module cannot freeze nominees')

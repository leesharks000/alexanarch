"""Snapshot one completed acquisition stage and advance the common resume."""
from pathlib import Path
import json,sys,zipfile,hashlib
from acquire_pilot import R,save,sha
stage=sys.argv[1];p=json.loads((R/'inputs/pilot-plan.json').read_text())
if stage=='parkes':
 native=sorted((R/'native').glob('parkes-reference-*'));cache=[R/'parkes-ranges'];meta=[]
else:
 sub,b=stage.split('-');regions=[x['name'] for x in p['regions'] if x['subband']==sub];native=[R/f'native/ata-{x}-beam{b}{ext}' for x in regions for ext in ['.npz','.json']];sources=[x for x in p['ata_files'] if sub in x['folder'] and x['beam']==int(b)];assert len(sources)==1
 key=sha(sources[0]['url'].encode());cache=[R/'range-cache'/key,R/'chunk-cache'/key];meta=[]
assert all(x.exists() for x in native)
paths=native+[q for d in cache for q in d.rglob('*') if q.is_file()]+list(R.glob('*.py'))+[R/'ATA-upper-strip-pilot-plan.md']+[q for d in [R/'inputs',R/'results'] for q in d.glob('*') if q.is_file() and not q.name.startswith('save-')]
paths=sorted(set(x for x in paths if x.suffix not in ['.tmp','.sparse']));archive=R/f'ATA-upper-pilot-{stage}-evidence.zip';manifest=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
 for f in paths:
  rel=f.relative_to(R);assert not any(x.startswith('.') for x in rel.parts);assert f.suffix not in ['.sparse','.tmp'];b=f.read_bytes();z.writestr(str(rel),b);manifest.append(dict(path=str(rel),size=len(b),sha256=sha(b)))
 z.writestr('stage-manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
rec=dict(stage=stage,archive=str(archive),size=archive.stat().st_size,sha256=sha(archive.read_bytes()));save(R/f'results/stage-{stage}.json',rec)
cp=R/'3I-ATLAS-RESUME.md';current=cp.read_text();note=f'''# CURRENT — upper-strip pilot checkpoint: {stage}

2026-11-05. Stage {stage} native acquisition is complete, source hashes and CRC verified; checkpoint save in progress. Evidence archive: {archive.name}; SHA256 {rec['sha256']}. Project ata-edge-pilot-20261105. Plan MD libfile_88885d3743a48191b550e792081fda88 and plan JSON libfile_45d87815054c8191939155eca4d00a48 are saved. Read per-stage save receipts to distinguish confirmed saves. Remaining stages and recoveries are pending unless a later entry says complete. Parkes SOURCE powers remain uninspected. Preserve the unknown status of the other survey and prior exposure. Resume acquisition using acquire_pilot.py (SHA-checked caches), then recovery_pilot.py; do not restart full-band acquisition or decode Parkes source powers.

''';cp.write_text(note+current)
print(json.dumps(rec))

from pathlib import Path
import hashlib,json
import chunk_index
R=Path(__file__).resolve().parent
m=json.loads((R/'inputs/layout-C1504-0.json').read_text());d=R/'range-cache'/hashlib.sha256(m['url'].encode()).hexdigest()
class Offline:
 def __init__(self):self.cache={int(p.stem):p.read_bytes() for p in d.glob('*.bin')};self.size=m['metadata']['remote_bytes'];self.pos=0
 def seek(self,p):self.pos=p
 def read(self,n):
  result=b''
  while n:
   idx=self.pos//65536;at=self.pos%65536;nn=min(n,65536-at);result+=self.cache[idx][at:at+nn];self.pos+=nn;n-=nn
  return result
rr=Offline();coords=sorted(set((x['t'],0,x['start'],0) for x in m['entries']));out=[]
for key,dtype in [('data','float32'),('mask','uint8')]:out+=chunk_index.entries(rr,coords,key,dtype)
original=sorted(m['entries'],key=lambda x:(x['key'],x['t'],x['start']));result=sorted(out,key=lambda x:(x['key'],x['t'],x['start']));assert result==original
proof=dict(n=len(result),all_fields_equal=True,reference='ordinary HDF5 get_chunk_info_by_coord layout C1504 beam0',fields=list(result[0]),code_sha256=hashlib.sha256((R/'chunk_index.py').read_bytes()).hexdigest())
(R/'results/manual-index-parity.json').write_text(json.dumps(proof,indent=2));print('INDEX EXACT',len(result))

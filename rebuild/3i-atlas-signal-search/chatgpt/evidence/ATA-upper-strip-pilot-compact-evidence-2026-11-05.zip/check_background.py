"""Zero-injection known-location checks and descriptive beam relationship."""
import json,time
import numpy as np
from acquire_pilot import R,guard,save
from recovery_pilot import scores
import core as s
p=guard();background=[];relations=[]
for ri,r in enumerate(p['regions']):
 while not all((R/f"native/ata-{r['name']}-beam{b}.npz").exists() for b in [0,1]):time.sleep(5)
 z=[np.load(R/f"native/ata-{r['name']}-beam{b}.npz") for b in [0,1]];raw=[v['power'] for v in z];m=dict(beams=[json.loads(str(v['metadata'])) for v in z]);a=m['beams'][0]['attrs'];df=a['foff']*1e6;ref=a['tstart']+.5*a['tsamp']/86400;s.reference=lambda:ref
 grid=np.arange(r['lo'],r['hi'],p['grid_hz']);place=a['fch1']*1e6+(np.round((r['lo']+.375e6-a['fch1']*1e6)/df)+p['phase_native_bins'][ri])*df;ii=np.flatnonzero(abs(grid-place)<=df)
 pref=[s.normalize(raw[b],z[b]['mask'])[0] for b in [0,1]]
 for L in p['durations']:
  zz=[scores(v,m,grid,L)[0] for v in pref];J=zz[0]-np.maximum(zz[1],0);eligible=ii[(zz[0][ii]>=6)&(J[ii]>=3)];select=eligible if len(eligible) else ii;k=int(select[np.argmax(J[select])]);background.append(dict(region=r['name'],L=L,placement_hz=float(place),frequency_hz=float(grid[k]),z_target=float(zz[0][k]),z_reference=float(zz[1][k]),J=float(J[k]),screen=bool(len(eligible))))
 del pref
 x=[v[:,::101].astype(float) for v in raw];correlations=[];trimmed=[]
 for t in range(len(x[0])):
  vv=[]
  for xx in x:
   v=xx[t];mid=np.median(v);mad=1.4826*np.median(abs(v-mid));vv.append((v-mid)/mad)
  correlations.append(float(np.corrcoef(vv[0],vv[1])[0,1]));keep=(abs(vv[0])<3)&(abs(vv[1])<3);trimmed.append(float(np.corrcoef(vv[0][keep],vv[1][keep])[0,1]))
 relations.append(dict(region=r['name'],power_hash_equal=m['beams'][0]['power_sha256']==m['beams'][1]['power_sha256'],stride=101,sample_bitwise_equal_fraction=float((x[0]==x[1]).mean()),per_row_raw_correlations=correlations,per_row_central_3MAD_correlations=trimmed,scope='descriptive background dependence; not a beam-response or sky-source leakage calibration'))
 save(R/'results/background-known-location.json',dict(complete=len(background)==12,cases=background));save(R/'results/beam-relationship.json',relations)
 print('BACKGROUND',r['name'],[x['screen'] for x in background if x['region']==r['name']],float(np.median(trimmed)),flush=True)

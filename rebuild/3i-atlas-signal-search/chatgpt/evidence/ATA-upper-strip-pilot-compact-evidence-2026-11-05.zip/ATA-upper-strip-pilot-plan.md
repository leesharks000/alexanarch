# ATA upper-strip feasibility pilot — fixed plan v1

Fixed before new target-power decoding. This is a sensitivity and data-quality pilot, not a technosignature search or a blind confirmation. Prior exposure beyond the recovered records and the other survey's completion status are unknown.

## Data

One ATA July 3 observation, the first scan in the recovered inventory, all 19 integrations and both simultaneous beams. Metadata establishes the highest recorded channel-cell edge at **3687.750000 MHz**, not 3688 MHz. Four fixed 1 MHz regions (Hz):

- low: 3648010000.000000–3649010000.000000; LoD.C1504.
- middle: 3667500000.000000–3668500000.000000; LoD.C1504.
- edge: 3686740000.000000–3687740000.000000; LoD.C1504.
- centre: 3351500000.000000–3352500000.000000; LoD.C0928.

Complete native storage chunks covering each region plus 1 kHz guards will be retained, including masks and original byte hashes. No more than two public HTTP requests in flight and 1.6 GB total transfer budget for this pilot. Atomic local checkpoints after each range/beam. Save each completed beam extract durably before moving beyond acquisition.

Parkes July 31 blc27's first **reference** R observation only, same three upper regions, all 20 integrations. Descending signed frequency axis must be preserved and tested. No Parkes source-observation powers may be inspected. Parkes reference quality alone cannot establish comet-observation sensitivity; no comet-frame analysis of Parkes will use ATA's ephemeris.

## Recovery and checks

ATA: corrected comet-frame detector; fixed 2 Hz grid; 1024-native-channel median baseline interpolation; per-row robust MAD normalization; matched odd-width boxcars allowing exposure drift smearing. Every evaluated known-location cell is checked against ON >= 6 and J = ON - max(reference,0) >= 3 before selecting the best eligible cell. Start is fixed at integration zero; no search over starts. Full-tile robust score calibration is recomputed after injection.

At each region's lower edge + 0.375 MHz (with native-bin phase 0, .25, .5, .75 by region), add Gaussian tones of sigma .6 native bins integrated over channel cells and 16 exposure sub-times, following the saved ATA observer radial-velocity track. Amplitudes 2, 4, 8, 16 times local raw-row MAD; durations 1, 4, 19 integrations. Test target-only and shared occupancy (the identical absolute raw increment in both beams): **96 cases**. Known location +/- one native bin only; no new candidate lists or false-alarm probabilities. Shared equal-raw signals need not yield equal normalized scores; report all passes without tuning.

Require zero-amplitude bitwise identity, independent Gaussian bin-integral checks, native-source HDF5 parity in every acquired beam/region, and direct native-bin versus prefix arithmetic checks for recovery scores. Test positive and negative frequency axes synthetically. Nonzero masks stop scoring pending explicit masked-path handling.

The strong target-only amplitudes (16 MAD) at durations 4 and 19 must recover in every ATA region for the current detector to be considered usable there. Misses trigger diagnosis, not an automatic signal claim or a tuned rescue. Short/weak misses and shared passes are recorded. No universal completeness limit will be inferred from these few injections.

## Outputs and decision

Report per-region power, relative noise and flag diagnostics, recovery outcomes, checks, exact software/data provenance, and limitations. Relative raw power or injected-tone recovery is not an absolute flux-density/SEFD calibration. Examine interference descriptively; do not nominate astronomical candidates in this pilot.

This pilot does not release the remaining ATA scans, freeze a full-strip discovery plan, or authorize decoding Parkes source powers. If quality/recovery is adequate, the next stage fixes discovery/reserve scans, controls, thresholds, candidate caps and multiplicity accounting, saves that plan, then searches ATA; only frozen ATA candidates proceed to Parkes.

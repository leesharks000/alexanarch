"""Plan-gated, resumable public source-chunk acquisition; no signal search."""
from pathlib import Path
import json,hashlib,zlib,os,urllib.request,concurrent.futures,threading,zipfile
import numpy as np,h5py
from remote_h5 import clean
from persistent_range import PersistentRange
R=Path(__file__).resolve().parent
LOCK=threading.Lock()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,o):
 p=Path(p);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(o,indent=2));tmp.replace(p)
def guard():
 receipt_path=R/'results/save-plan.json'
 if not receipt_path.exists():receipt_path=R/'inputs/confirmed-plan-receipt.json'
 receipt=json.loads(receipt_path.read_text());results=receipt['results']
 for name in ['ATA-upper-strip-pilot-plan.md','pilot-plan.json']:
  assert any(x.get('status')=='succeeded' and Path(x['local_path']).name==name for x in results),('plan not saved',name)
 proof=json.loads((R/'inputs/pilot-plan-proof.json').read_text())
 for rel,digest in proof.items():assert sha((R/rel).read_bytes())==digest
 return json.loads((R/'inputs/pilot-plan.json').read_text())
def get_range(url,start,stop,expected_total):
 req=urllib.request.Request(url,headers={'Range':f'bytes={start}-{stop}'})
 with urllib.request.urlopen(req,timeout=60) as response:
  cr=response.headers.get('Content-Range');assert response.status==206 and cr==f'bytes {start}-{stop}/{expected_total}',cr
  body=response.read(stop-start+2)
 assert len(body)==stop-start+1
 return body
def acquire(source):
 plan=guard();url=source['url'];beam=source['beam'];sub=source['folder'].rstrip('/').split('.')[-1];regions=[x for x in plan['regions'] if x['subband']==sub]
 outputs=[R/f"native/ata-{x['name']}-beam{beam}.npz" for x in regions]
 if all(p.exists() for p in outputs):
  for p in outputs:assert zipfile.ZipFile(p).testzip() is None
  print('RESTORED',sub,beam,flush=True);return
 a0=source['attrs'];cc0=source['chunks'][-1];df0=a0['foff']*1e6;first0=a0['fch1']*1e6
 coords=[]
 for r in regions:
  left=int(np.floor((r['lo']-plan['guard_hz']-first0)/df0/cc0))*cc0;right=(int(np.floor((r['hi']+plan['guard_hz']-first0)/df0/cc0))+1)*cc0
  coords.extend((t,0,c,0) for t in range(source['shape'][0]) for c in range(left,right,cc0))
 rr=PersistentRange(url,budget=64<<20,coordinates=coords)
 with h5py.File(rr,'r') as f:
  a={k:clean(v) for k,v in f['data'].attrs.items()};assert a==source['attrs'];n=f['data'].shape[0];cc=f['data'].chunks[-1];df=a['foff']*1e6;first=a['fch1']*1e6
  spans=[]
  for region in regions:
   lo=int(np.floor((region['lo']-plan['guard_hz']-first)/df/cc))*cc;hi=(int(np.floor((region['hi']+plan['guard_hz']-first)/df/cc))+1)*cc
   assert 0<=lo<hi<=a['nchans'];spans.append((region,lo,hi))
  chunks=sorted(set(c for _,lo,hi in spans for c in range(lo,hi,cc)));entries=[]
  dtypes={}
  for key in ['data','mask']:
   d=f[key];assert d.chunks==(1,1,cc) and d._filters=={'gzip':0};dtypes[key]=str(d.dtype)
 # Avoid the API's whole-index enumeration. This exact v1 index reader was
 # compared field-by-field against all 342 ordinary HDF5 entries for beam0.
 import chunk_index
 parity=json.loads((R/'results/manual-index-parity.json').read_text());assert parity['all_fields_equal'] and parity['n']==342 and parity['code_sha256']==sha((R/'chunk_index.py').read_bytes());assert cc==262144 and dtypes=={'data':'float32','mask':'uint8'}
 coordinates=[(t,0,c,0) for t in range(n) for c in chunks]
 for key in ['data','mask']:entries.extend(chunk_index.entries(rr,coordinates,key,dtypes[key]))
 save(R/f'inputs/layout-{sub}-{beam}.json',dict(url=url,attrs=a,spans=[dict(region=r,start=lo,stop=hi) for r,lo,hi in spans],entries=entries,metadata=rr.manifest()))
 directory=R/'chunk-cache'/sha(url.encode());directory.mkdir(parents=True,exist_ok=True)
 def cache(e):return directory/f"{e['byte_offset']}-{e['size']}.chunk"
 def cached(e):
  p=cache(e);h=p.with_suffix('.sha256')
  if not p.exists() or not h.exists():return False
  assert p.stat().st_size==e['size'] and sha(p.read_bytes())==h.read_text().strip();return True
 groups=[]
 for e in sorted((e for e in entries if not cached(e)),key=lambda e:e['byte_offset']):
  if not groups or e['byte_offset']+e['size']-groups[-1][0]['byte_offset']>24*1024**2 or e['byte_offset']-(groups[-1][-1]['byte_offset']+groups[-1][-1]['size'])>2*1024**2:groups.append([])
  groups[-1].append(e)
 records_path=R/f'results/ranges-{sub}-{beam}.json';records=json.loads(records_path.read_text()) if records_path.exists() else []
 def get(group):
  off=group[0]['byte_offset'];end=group[-1]['byte_offset']+group[-1]['size']-1
  # Hard conservative ceiling on all completed payload transfers plus this batch.
  with LOCK:
   done=sum(x['size'] for p in (R/'results').glob('ranges-*.json') for x in json.loads(p.read_text()))
   assert done+2*(end-off+1)+4*(64<<20)<plan['byte_budget']
  body=get_range(url,off,end,rr.size)
  for e in entries:
   i=e['byte_offset']-off;j=i+e['size']
   if 0<=i<j<=len(body):
    p=cache(e);b=body[i:j]
    if cached(e):assert p.read_bytes()==b
    else:
     tmp=p.with_name(p.name+'.tmp');tmp.write_bytes(b);tmp.replace(p);p.with_suffix('.sha256').write_text(sha(b))
  rec=dict(url=url,offset=off,size=len(body),sha256=sha(body))
  with LOCK:records.append(rec);save(records_path,records)
  print('RANGE',sub,beam,len(records),len(groups),len(body),flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(get,groups))
 assert all(cached(e) for e in entries)
 sparse=R/f'native/source-{sub}-{beam}.sparse'
 with sparse.open('wb') as fp:
  fp.truncate(rr.size)
  for idx,b in rr.cache.items():fp.seek(idx*rr.block);fp.write(b)
  for e in entries:fp.seek(e['byte_offset']);fp.write(cache(e).read_bytes())
 for (region,lo,hi),dest in zip(spans,outputs):
  power=np.empty((n,hi-lo),np.float32);mask=np.empty((n,hi-lo),np.uint8)
  subset=[e for e in entries if lo<=e['start']<hi]
  for e in subset:
   b=cache(e).read_bytes();e['sha256']=sha(b);payload=zlib.decompress(b) if e['filter_mask']==0 else b;ar=np.frombuffer(payload,dtype=np.dtype(e['dtype']));assert len(ar)==cc
   target=power if e['key']=='data' else mask;j=e['start']-lo;target[e['t'],j:j+cc]=ar
  checks=[]
  with h5py.File(sparse,'r') as f:
   for t,j in [(0,lo+31),(n-1,hi-65)]:
    for key,target in [('data',power),('mask',mask)]:
     assert np.array_equal(f[key][t,0,j:j+16],target[t,j-lo:j-lo+16]);checks.append(dict(t=t,channel=j,key=key,n=16,bitwise_equal=True))
  bm=dict(url=url,attrs=a,shape=list(power.shape),start_channel=lo,stop_channel=hi,chunk_channels=cc,entries=subset,power_sha256=sha(power.tobytes()),mask_sha256=sha(mask.tobytes()),nonzero_masks=int(np.count_nonzero(mask)),region=region,checks=checks)
  tmp=dest.with_name(dest.name+'.tmp')
  with tmp.open('wb') as fp:np.savez_compressed(fp,power=power,mask=mask,metadata=json.dumps(bm))
  assert zipfile.ZipFile(tmp).testzip() is None;tmp.replace(dest)
  save(dest.with_suffix('.json'),dict(file=dest.name,bytes=dest.stat().st_size,sha256=sha(dest.read_bytes()),metadata=bm))
  print('SAVED',dest.name,dest.stat().st_size,'masks',bm['nonzero_masks'],flush=True)
 sparse.unlink()
if __name__=='__main__':
 import sys
 p=guard()
 for s in p['ata_files']:
  if len(sys.argv)==1 or (s['beam']==int(sys.argv[2]) and sys.argv[1] in s['folder']):acquire(s)

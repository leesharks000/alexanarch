"""Bounded, cached HTTP Range reader for inspecting public HDF5 data."""
import io, json, urllib.request, time, hashlib, struct, concurrent.futures
from pathlib import Path
import h5py
import hdf5plugin  # registers bitshuffle/LZ4 HDF5 filters

class RemoteRange(io.RawIOBase):
    def __init__(self,url,block=65536,budget=64*1024*1024):
        self.url=url;self.pos=0;self.block=block;self.cache={};self.requests=[];self.budget=budget;self.transferred=0
        req=urllib.request.Request(url,headers={'Range':'bytes=0-65535'})
        with urllib.request.urlopen(req,timeout=30) as r:
            if r.status!=206:raise RuntimeError('Server does not support bounded Range access')
            self.size=int(r.headers['Content-Range'].rsplit('/',1)[-1]);b=r.read(65536)
            self.headers=dict(r.headers)
        self.cache[0]=b;self.transferred=len(b);self.requests.append({'start':0,'end':len(b)-1,'sha256':hashlib.sha256(b).hexdigest()})
    def readable(self):return True
    def seekable(self):return True
    def tell(self):return self.pos
    def seek(self,offset,whence=0):
        self.pos=offset if whence==0 else self.pos+offset if whence==1 else self.size+offset
        return self.pos
    def read(self,n=-1):
        if n<0:n=self.size-self.pos
        n=min(n,self.size-self.pos)
        if n<=0:return b''
        if n>24*1024*1024:raise RuntimeError(f'Read too large: {n}')
        end=self.pos+n;result=[]
        while self.pos<end:
            idx=self.pos//self.block;start=idx*self.block
            if idx not in self.cache:
                stop=min(start+self.block,self.size)-1
                if self.transferred+(stop-start+1)>self.budget:raise RuntimeError('Range transfer budget exceeded')
                print(f'Range {start}-{stop}',flush=True)
                req=urllib.request.Request(self.url,headers={'Range':f'bytes={start}-{stop}'})
                with urllib.request.urlopen(req,timeout=30) as r:
                    if r.status!=206:raise RuntimeError('Range ignored')
                    if not r.headers.get('Content-Range','').startswith(f'bytes {start}-'):
                        raise RuntimeError('Incorrect Content-Range: '+str(r.headers.get('Content-Range')))
                    b=r.read(stop-start+1)
                    if len(b)!=stop-start+1:raise RuntimeError('Short range read')
                self.cache[idx]=b;self.transferred+=len(b)
                self.requests.append({'start':start,'end':stop,'sha256':hashlib.sha256(b).hexdigest()})
            chunk=self.cache[idx];offset=self.pos-start;take=min(end-self.pos,len(chunk)-offset)
            result.append(chunk[offset:offset+take]);self.pos+=take
        return b''.join(result)
    def readinto(self,b):
        data=self.read(len(b));b[:len(data)]=data;return len(data)
    def manifest(self):return {'url':self.url,'remote_bytes':self.size,'downloaded_bytes':self.transferred,'headers':self.headers,'ranges':self.requests}
    def prefetch_v1_chunk_index(self,root_offset=8192,rank=3):
        """Prefetch children of the verified level-one B-tree in this archive.

        This is a metadata optimization only. HDF5 still resolves every chunk.
        For v1 raw-data B-trees the key is size/filter plus rank+1 offsets.
        """
        b=self.cache[0];key_size=8+8*(rank+1);stride=key_size+8
        if b[root_offset:root_offset+6]!=b'TREE\x01\x01':
            raise RuntimeError('Unexpected raw chunk index layout')
        count=struct.unpack_from('<H',b,root_offset+6)[0]
        pointers=[struct.unpack_from('<Q',b,root_offset+24+key_size+i*stride)[0] for i in range(count)]
        indexes=sorted(set(p//self.block for p in pointers)-set(self.cache))
        def fetch(idx):
            start=idx*self.block;stop=min(start+self.block,self.size)-1
            with urllib.request.urlopen(urllib.request.Request(self.url,headers={'Range':f'bytes={start}-{stop}'}),timeout=30) as r:
                if r.status!=206 or not r.headers.get('Content-Range','').startswith(f'bytes {start}-'):
                    raise RuntimeError('Incorrect prefetched Range')
                data=r.read(stop-start+1)
            if len(data)!=stop-start+1:raise RuntimeError('Short prefetched Range')
            return idx,data
        print('Prefetching',len(indexes),'metadata blocks',flush=True)
        if self.transferred+len(indexes)*self.block>self.budget:raise RuntimeError('Metadata exceeds budget')
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            for idx,data in pool.map(fetch,indexes):
                self.cache[idx]=data;self.transferred+=len(data)
                self.requests.append({'start':idx*self.block,'end':idx*self.block+len(data)-1,'sha256':hashlib.sha256(data).hexdigest()})

def clean(v):
    if isinstance(v,bytes):return v.decode(errors='replace')
    if hasattr(v,'tolist'):return v.tolist()
    return v

if __name__=='__main__':
    import signal, faulthandler
    faulthandler.dump_traceback_later(25,repeat=True)
    signal.alarm(90)
    out=Path(__file__).resolve().parent
    probe=json.loads((out/'range_probe.json').read_text())
    print('Opening range reader',flush=True)
    rr=RemoteRange(probe['url'])
    print('Opening HDF5',flush=True)
    with h5py.File(rr,'r') as f:
        d={'attrs':{k:clean(v) for k,v in f.attrs.items()},'datasets':{}}
        def visitor(k,x):
            print('Dataset metadata: '+k,flush=True)
            if isinstance(x,h5py.Dataset):d['datasets'][k]={'shape':x.shape,'dtype':str(x.dtype),'chunks':x.chunks,
                       'filters':x._filters,'attrs':{k:clean(v) for k,v in x.attrs.items()}}
        for key in f.keys():visitor(key,f[key])
        print(json.dumps(d,indent=2,default=str),flush=True)
    d['range_manifest']=rr.manifest()
    (out/'hdf5_metadata.json').write_text(json.dumps(d,indent=2,default=str))

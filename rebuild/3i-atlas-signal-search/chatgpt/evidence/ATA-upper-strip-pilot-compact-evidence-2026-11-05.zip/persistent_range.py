"""Hash-checked public Range cache. Prefetch verified HDF5 B-tree children."""
import io,json,hashlib,urllib.request,concurrent.futures,threading
from pathlib import Path
class PersistentRange(io.RawIOBase):
 def __init__(self,url,block=65536,budget=64<<20,coordinates=None):
  self.coordinates=coordinates
  self.url=url;self.pos=0;self.block=block;self.budget=budget;self.transferred=0;self.cache={};self.requests=[];self.headers={};self.lock=threading.Lock();self.seen=set()
  self.directory=Path(__file__).resolve().parent/'range-cache'/hashlib.sha256(url.encode()).hexdigest();self.directory.mkdir(parents=True,exist_ok=True)
  meta=self.directory/'source.json'
  if meta.exists():
   m=json.loads(meta.read_text());assert m['url']==url;self.size=m['size'];self.headers=m['headers']
  else:
   with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':'bytes=0-65535'}),timeout=40) as f:
    assert f.status==206;self.size=int(f.headers['Content-Range'].split('/')[-1]);self.headers=dict(f.headers);b=f.read()
   assert len(b)==min(self.size,block);self._install(0,b);meta.write_text(json.dumps(dict(url=url,size=self.size,headers=self.headers),indent=2))
  self._fetch(0);self._prefetch_roots(self.cache[0],0)
 def _install(self,idx,b):
  p=self.directory/f'{idx:09}.bin';tmp=p.with_suffix('.tmp');tmp.write_bytes(b);tmp.replace(p);p.with_suffix('.sha256').write_text(hashlib.sha256(b).hexdigest())
 def _fetch(self,idx):
  if idx in self.cache:return
  p=self.directory/f'{idx:09}.bin';start=idx*self.block;stop=min(self.size,start+self.block)-1
  if p.exists() and p.with_suffix('.sha256').exists():
   b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==p.with_suffix('.sha256').read_text() and len(b)==stop-start+1
  else:
   with urllib.request.urlopen(urllib.request.Request(self.url,headers={'Range':f'bytes={start}-{stop}'}),timeout=40) as f:
    assert f.status==206 and f.headers['Content-Range'].startswith(f'bytes {start}-');b=f.read(stop-start+2)
   assert len(b)==stop-start+1;self._install(idx,b)
  with self.lock:
   self.cache[idx]=b;self.transferred+=len(b);assert self.transferred<=self.budget
   self.requests.append(dict(start=start,end=stop,sha256=hashlib.sha256(b).hexdigest()))
 def _prefetch_roots(self,b,start):
  import struct
  at=0;todo=[]
  while True:
   at=b.find(b'TREE\x01\x01',at)
   if at<0:break
   root=start+at;at+=1
   if root in self.seen:continue
   count=struct.unpack_from('<H',b,at+5)[0]
   # rank3 chunk-index key40bytes, pointer8bytes; verified old decoder layout.
   if not 1<=count<=64 or at-1+24+48*count+40>len(b):continue
   pointers=[struct.unpack_from('<Q',b,at-1+24+40+48*i)[0] for i in range(count)]
   if not all(0<p<self.size for p in pointers):continue
   self.seen.add(root)
   if self.coordinates is not None:
    keys=[struct.unpack_from('<4Q',b,at-1+24+8+48*i) for i in range(count+1)]
    assert keys==sorted(keys),('unsorted chunk root',root)
    import bisect
    chosen=sorted({bisect.bisect_right(keys,tuple(coord))-1 for coord in self.coordinates})
    assert all(0<=i<count for i in chosen),('coordinate outside index',chosen)
    pointers=[pointers[i] for i in chosen]
   todo.extend(p//self.block for p in pointers)
  todo=sorted(set(todo)-set(self.cache))
  if todo:
   print('Checkpointed prefetch',len(todo),'metadata blocks',flush=True)
   with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(self._fetch,todo))
 def prefetch_v1_chunk_index(self,*args,**kwargs):return
 def readable(self):return True
 def seekable(self):return True
 def tell(self):return self.pos
 def seek(self,offset,whence=0):
  self.pos=offset if whence==0 else self.pos+offset if whence==1 else self.size+offset;return self.pos
 def read(self,n=-1):
  if n<0:n=self.size-self.pos
  n=min(n,self.size-self.pos)
  if n<=0:return b''
  assert n<=24<<20;end=self.pos+n;parts=[]
  while self.pos<end:
   idx=self.pos//self.block;self._fetch(idx);b=self.cache[idx];self._prefetch_roots(b,idx*self.block);off=self.pos%self.block;take=min(end-self.pos,len(b)-off);parts.append(b[off:off+take]);self.pos+=take
  return b''.join(parts)
 def readinto(self,b):v=self.read(len(b));b[:len(v)]=v;return len(v)
 def manifest(self):return dict(url=self.url,remote_bytes=self.size,downloaded_bytes=self.transferred,headers=self.headers,ranges=self.requests)

"""Make the completed-pilot report from saved results; no data search."""
from pathlib import Path
import json,zipfile,hashlib,datetime
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from recovery_pilot import quality
from acquire_pilot import R,save,sha

def run():
 full_quality=json.loads((R/'results/full-extract-quality.json').read_text());assert len(full_quality)==8 and all(x['nonfinite']==x['nonpositive']==x['nonzero_masks']==0 for x in full_quality)
 p=json.loads((R/'inputs/pilot-plan.json').read_text());s=json.loads((R/'results/recovery-summary.json').read_text());assert s['complete'] and s['n']==96
 diagnostics=[json.loads((R/f"results/quality-{r['name']}.json").read_text()) for r in p['regions']]
 pq=[]
 for r in p['regions'][:3]:
  z=np.load(R/f"native/parkes-reference-{r['name']}.npz");m=json.loads(str(z['metadata']));assert '_R_' in m['url'] and m['attrs']['foff']<0
  pq.append(dict(region=r['name'],diagnostic=quality(z['power'],m,r),source=m['url'],power_sha256=m['power_sha256']))
 save(R/'results/parkes-reference-quality.json',pq)
 background=json.loads((R/'results/background-known-location.json').read_text());assert background['complete'];relations=json.loads((R/'results/beam-relationship.json').read_text())
 checks=json.loads((R/'results/software-checks.json').read_text());cases=s['cases'];parity=[];native=[]
 for reg in p['regions']:
  for b in [0,1]:
   path=R/f"native/ata-{reg['name']}-beam{b}.npz";info=json.loads(path.with_suffix('.json').read_text());parity.extend(info['metadata']['checks']);native.append(info)
 assert len(parity)==32 and all(x['bitwise_equal'] for x in parity)
 maxerr=max(x['direct_score_max_error'] for x in cases)
 outcomes=[]
 for reg in p['regions']:
  target=[x for x in cases if x['region']==reg['name'] and x['occupancy']=='target_only'];shared=[x for x in cases if x['region']==reg['name'] and x['occupancy']=='shared_equal_raw']
  outcomes.append(dict(region=reg['name'],target_pass=sum(x['screen'] for x in target),shared_pass=sum(x['screen'] for x in shared),target_n=len(target),shared_n=len(shared),strong_required_pass=sum(x['screen'] for x in target if x['amplitude_raw_row_MAD']==16 and x['L'] in [4,19])))
 receipts=[]
 for f in sorted((R/'results').glob('save-stage-*.json')):
  rr=json.loads(f.read_text());assert all(x['status']=='succeeded' for x in rr['results'])
  receipts.extend({k:x[k] for k in ['file_name','library_file_id','current_version_number','status'] if k in x} for x in rr['results'] if x['file_name'].endswith('.zip'))
 transfer=sum(x['size'] for f in (R/'results').glob('ranges-*.json') for x in json.loads(f.read_text()))
 refbytes=sum(x['size'] for f in (R/'native').glob('parkes-reference-*.json') for x in json.loads(f.read_text())['metadata']['entries'])
 metadata_bytes=sum(f.stat().st_size for f in (R/'range-cache').glob('*/*.bin'));preview_bytes=sum(f.stat().st_size for f in (R/'metadata-heads').glob('*/*.bin'))+4096
 assert transfer+refbytes+metadata_bytes+preview_bytes<p['byte_budget']
 pack=dict(full_extract_quality=full_quality,metadata_cache_bytes=metadata_bytes,preview_header_transfer_bytes=preview_bytes,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope=p['scope'],complete=True,zero_injection_known_location=background,beam_relationship=relations,strong_required_all_pass=s['strong_required_all_pass'],outcomes=outcomes,direct_score_max_error=maxerr,source_HDF_parity_checks=len(parity),software_checks=checks,quality=diagnostics,parkes_reference_quality=pq,ata_completed_payload_range_bytes=transfer,parkes_reference_payload_range_bytes=refbytes,native_archives=native,stage_evidence=receipts,limitations=['One ATA observation only; no survey null or astrophysical candidate result.','Prior exposure outside recovered records and other survey completion remain unknown.','Injected amplitudes are in measured raw-row MAD units; no absolute sky sensitivity, SEFD, or flux calibration.','Parkes reference quality alone is not source-observation sensitivity; no Parkes comet powers inspected.','Strong synthetic recovery qualifies the defined detector, not all possible transmitter behaviors.'])
 save(R/'results/pilot-summary.json',pack)
 fig,axs=plt.subplots(1,2,figsize=(11,4.4),layout='constrained');labels=[r['name'] for r in p['regions']];xx=np.arange(4)
 for b,color in [(0,'#1967ad'),(1,'#d66b24')]:
  values=np.array([d['beams'][b]['median_row_power'] for d in diagnostics]);centre=values[-1]
  axs[0].plot(xx+(-.04 if b==0 else .04),values/centre,'o',label=f'ATA beam {b}',color=color)
 axs[0].set(xticks=xx,xticklabels=labels,ylabel='Median raw power / centre-tile power',title='Relative raw power — not flux sensitivity');axs[0].grid(alpha=.2);axs[0].legend()
 success=np.array([[sum(x['screen'] for x in cases if x['region']==r['name'] and x['occupancy']=='target_only' and x['amplitude_raw_row_MAD']==amp) for amp in p['injection_amplitudes_raw_MAD']] for r in p['regions']]);im=axs[1].imshow(success,vmin=0,vmax=3,cmap='Blues',aspect='auto')
 axs[1].set(xticks=range(4),xticklabels=p['injection_amplitudes_raw_MAD'],yticks=range(4),yticklabels=labels,xlabel='Injected amplitude (raw-row MAD)',title='Target-only recovery (durations 1, 4, 19)')
 for i in range(4):
  for j in range(4):axs[1].text(j,i,f'{success[i,j]}/3',ha='center',va='center',color='white' if success[i,j]>=2 else 'black')
 fig.savefig(R/'ATA-upper-strip-pilot.png',dpi=170);plt.close(fig)
 text='# ATA upper-strip feasibility pilot\n\n'
 text+=f"Completed {pack['created_utc']}. **{'The fixed strong-tone recovery requirement passed in all four ATA regions.' if s['strong_required_all_pass'] else 'The fixed strong-tone requirement did not pass everywhere; diagnose before full-strip use.'}** This was a software/data-quality pilot, not a new astronomical signal search.\n\n"
 text+='The data header fixes ATA’s actual upper channel-cell edge at **3687.750000 MHz**. The originally proposed 3687.750–3688 MHz portion is absent from this tuning. The separate Parkes header audit shows that the recorded ATA strip also lies within Parkes blc27 coverage; it is not an otherwise unobserved frequency gap. Parkes’s July 31 reference observation was used only for quality checks here.\n\n'
 text+='| ATA sample (MHz) | Target-only recoveries | Shared-equal-raw passes | Required strong recoveries |\n|---|---:|---:|---:|\n'
 for r,o in zip(p['regions'],outcomes):text+=f"| {r['name']}: {r['lo']/1e6:.6f}–{r['hi']/1e6:.6f} | {o['target_pass']}/12 | {o['shared_pass']}/12 | {o['strong_required_pass']}/2 |\n"
 text+='\nThe 96 fixed cases comprise four regions, amplitudes 2/4/8/16 measured local raw-row MAD, durations 1/4/19 integrations, and target-only versus the same absolute raw increment before float32 rounding in both simultaneous beams. The known location was fixed before power decoding; only its ±1-native-bin neighbourhood was eligible. Start was fixed at zero. These are sparse feasibility benchmarks, not estimated detection probabilities. ON and J are robust standardized detector scores, not calibrated Gaussian significance. Shared equal-raw increments can produce unequal standardized beam scores; any shared passes are documented rather than tuned away.\n\n'
 text+='| Sample | Beam 0 median raw power | Beam 1 median raw power | Beam 0 fractional raw MAD | Beam 1 fractional raw MAD |\n|---|---:|---:|---:|---:|\n'
 for d in diagnostics:
  a,b=d['beams'];text+=f"| {d['region']['name']} | {a['median_row_power']:.6g} | {b['median_row_power']:.6g} | {a['relative_row_mad_to_power']:.5f} | {b['relative_row_mad_to_power']:.5f} |\n"
 text+='\nAll ATA native powers are finite and positive; all acquired masks are zero. Raw power levels across tunings depend on receiver gain and band response as well as sky/system power. Similar fractional noise and passing raw-power injections do not establish equal astronomical sensitivity, especially near a passband edge. No flux-calibrated threshold can be stated from this pilot.\n\n'
 text+=f"The zero-injection background passed the same known-location screen in **{sum(x['screen'] for x in background['cases'])}/12** fixed region/duration checks. A background pass would make recovery at that coordinate ambiguous. The two beam arrays have different power hashes; their sampled backgrounds are correlated (median within-row, central-three-MAD correlations: "+', '.join(f"{x['region']} {np.median(x['per_row_central_3MAD_correlations']):.3f}" for x in relations)+"). These are not independent noise streams. No measured celestial beam-leakage calibration was obtained: a real sky tone entering the reference beam could be penalized by J. The synthetic target-only recovery result is conditional on the injected occupancy.\n\n"
 text+='The centre comparison is not a clean, featureless band. Fractions above each raw row’s median + 8 MAD are:\n\n| Region | Beam 0 | Beam 1 |\n|---|---:|---:|\n'
 for d in diagnostics:text+=f"| {d['region']['name']} | {100*d['beams'][0]['fraction_gt_row_median_plus_8mad']:.6f}% | {100*d['beams'][1]['fraction_gt_row_median_plus_8mad']:.6f}% |\n"
 text+='\nThe strongest raw outliers are in the comparison extract; their origin was not established here. The fixed injection recovery and robust baseline checks passed despite these features. No such feature was nominated as an astronomical candidate.\n\n'
 text+='Parkes reference checks:\n\n| Region | Integrations | Frequency step (Hz) | Finite / positive fraction | Fractional raw MAD |\n|---|---:|---:|---:|---:|\n'
 for item in pq:
  d=item['diagnostic'];text+=f"| {item['region']} | {d['n_integrations']} | {d['axis_step_hz']:.6f} | {d['finite_fraction']:.6f} / {d['positive_fraction']:.6f} | {d['relative_row_mad_to_power']:.5f} |\n"
 text+='\nParkes’s negative frequency increment was retained. Its reference slices are not a test of comet emission, and ATA ephemerides were not applied to Parkes. Parkes source powers remain uninspected.\n\n'
 text+=f"Validation: **{len(parity)}** independent native-source HDF5 comparisons were bitwise equal, spanning data and masks in every ATA region and beam. All four zero-amplitude injections were bitwise unchanged. Gaussian bin-integral quadrature maximum error: **{checks['gaussian_quadrature_max_error']:.3g}**. Ascending/descending-axis numerical agreement: **{checks['ascending_descending_axis_max_error']:.3g}**. Independent direct-native-bin versus prefix score maximum error across all recovery cases: **{maxerr:.3g}**. Every archive was CRC-checked; source ranges, chunks and arrays carry SHA-256 records.\n\n"
 text+=f"Completed ATA payload-range transfers: {transfer/1e6:.3f} MB; Parkes reference payload ranges: {refbytes/1e6:.3f} MB, plus {metadata_bytes/1e6:.3f} MB of unique source metadata blocks and {preview_bytes/1e6:.3f} MB of preview headers. Coalesced ATA ranges include gap bytes that were not decoded as target powers. The 1.6 GB ceiling and two-request cap were respected. No full 40 MHz acquisition was started.\n\n"
 text+='What remains: document or model celestial leakage into the reference beam before using it as a hard veto (or retain a separately controlled shared-beam branch); identify any prior exposure and actual status of the separate survey; freeze the ATA discovery/reserve split, controls, multiplicity accounting, sensitivity/quality exclusions and candidate limits before additional source powers; run that defined search; freeze ATA nominees before checking Parkes comet observations with its own observer geometry. A later-epoch Parkes non-recurrence would constrain persistent signals, not automatically exclude a July 3 transient.\n\n'
 text+='Saved evidence (each includes source chunks/ranges, native extracts, relevant code and checks):\n\n'
 for rec in receipts:text+=f"- [{rec['file_name']}](https://chatgpt.com/library?file_id={rec['library_file_id']}&account_id=personal)\n"
 text+='\nThe final compact evidence packet contains all code, metadata, fixed plan, per-case results and summary needed alongside those native evidence parts. Prior 3332–3339 MHz and older branches remain separate; this pilot does not revise their outcomes.\n'
 (R/'ATA-upper-strip-pilot-report.md').write_text(text)
 print('REPORT READY',outcomes,flush=True)
if __name__=='__main__':run()

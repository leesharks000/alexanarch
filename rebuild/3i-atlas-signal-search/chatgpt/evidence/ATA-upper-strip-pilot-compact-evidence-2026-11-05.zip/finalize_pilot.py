"""Prepare compact reproducibility packet and final version-guarded resume."""
from pathlib import Path
import json,sys,zipfile,hashlib
from acquire_pilot import R,save,sha
from stage_worker import cp_version
if sys.argv[1]=='pack':
 assert json.loads((R/'results/recovery-summary.json').read_text())['complete']
 receipts=[]
 for f in sorted((R/'results').glob('save-stage-*.json')):
  x=json.loads(f.read_text());assert all(r['status']=='succeeded' for r in x['results']);receipts.extend({k:r[k] for k in ['file_name','library_file_id','current_version_number','status'] if k in r} for r in x['results'])
 assert sum(x['file_name'].endswith('.zip') for x in receipts)==5
 save(R/'results/evidence-index.json',dict(native_evidence=receipts,notes='Native raw/derived arrays and source chunks in separate per-stage files. All statistical results and code in this packet. Parkes reference only; source powers uninspected.'))
 paths=list(R.glob('*.py'))+list(R.glob('ATA-upper-strip-*.md'))+[R/'ATA-upper-strip-pilot.png',R/'README-reproduce.md']+[f for d in [R/'inputs',R/'results'] for f in d.rglob('*') if f.is_file() and f.suffix not in ['.tmp','.zip'] and not f.name.startswith('save-') and f.name not in ['compact-evidence-hash.json','resume-upload-input.json'] and not f.name.endswith('.log')]
 paths+=list((R/'metadata-heads').rglob('*.bin'))
 zpath=R/'ATA-upper-strip-pilot-compact-evidence.zip';manifest=[]
 with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for f in sorted(set(paths)):
   rel=f.relative_to(R);assert not any(x.startswith('.') for x in rel.parts);b=f.read_bytes();z.writestr(str(rel),b);manifest.append(dict(path=str(rel),size=len(b),sha256=sha(b)))
  z.writestr('compact-manifest.json',json.dumps(manifest,indent=2))
 with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
 save(R/'results/compact-evidence-hash.json',dict(file=zpath.name,bytes=zpath.stat().st_size,sha256=sha(zpath.read_bytes())))
 print('COMPACT READY',zpath.stat().st_size,flush=True)
elif sys.argv[1]=='resume':
 results=json.loads((R/'results/save-final-artifacts.json').read_text())['results'];assert all(x['status']=='succeeded' for x in results)
 s=json.loads((R/'results/pilot-summary.json').read_text());outcomes=s['outcomes'];lines=[]
 for rec in results:lines.append(f"- {rec['file_name']}: {rec['library_file_id']}")
 note=f'''# CURRENT — upper-strip feasibility pilot COMPLETE

2026-11-05. No full-strip search or Parkes source-data follow-up was run. Actual ATA upper channel-cell edge is 3687.750000 MHz. One ATA July 3 observation, four fixed 1 MHz regions, all 19 integrations and both beams, plus the first Parkes July 31 reference observation in the three upper regions. Strong-tone requirement all pass: {s['strong_required_all_pass']}. 96 raw-power recovery cases; 32 source-HDF5 parity comparisons; direct-score maximum error {s['direct_score_max_error']:.9g}. Region outcomes: {json.dumps(outcomes)}.

Saved final files:
'''+ '\n'.join(lines)+'\n\nNative evidence parts:\n'+'\n'.join(f"- {x['file_name']}: {x['library_file_id']}" for x in s['stage_evidence'])+'''

Resume from the final report and compact evidence together with native parts as needed. Do not call this a new signal detection or a survey null. Strong injected-tone recovery is in measured raw-row MAD units, not flux-calibrated astronomical sensitivity. Parkes source powers remain uninspected. Other survey completion and any prior exposure outside recovered records remain unknown. Next: document/model celestial reference-beam leakage or retain a separately controlled shared-beam branch, reconcile exposure/survey status, freeze full-strip discovery/reserve, controls, thresholds, quality exclusions, multiplicity and candidate cap, then ATA search; frozen ATA candidates only proceed to Parkes with its own observer ephemeris. The claimed absence of other public coverage is disproved by the saved Parkes header audit. Keep earlier CH/Wow/C03 branches and limitations separate.

'''
 cp=R/'3I-ATLAS-RESUME.md';cp.write_text(note+cp.read_text());version=cp_version()
 upload=dict(uploads=[dict(local_path=str(cp),purpose='replace_library_file',library_file_id='libfile_349f1c1635808191b815fee10ce169d7',expected_current_version=version,version_reason='Completed upper-strip feasibility pilot; saved final report, recoveries and all native evidence')])
 (R/'results/resume-upload-input.json').write_text(json.dumps(upload))
 print('RESUME READY',version,flush=True)

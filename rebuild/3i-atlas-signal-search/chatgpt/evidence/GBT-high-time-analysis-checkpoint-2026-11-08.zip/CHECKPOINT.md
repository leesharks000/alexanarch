# Green Bank high-time follow-up — complete

Native scans complete: [13, 14, 15, 16, 17, 18]. Timing scans complete: [13, 14, 15, 16, 17, 18]. See results/checkpoint-state.json for native ZIP IDs and confirmed save receipts.

The initial request concerns the public .0001 high-time total-power products, NOT voltages or resolved individual-candidate modulation. Selection was fixed in PLAN.md, with metadata-only target-boundary and numerical-screen clarifications recorded there.

Restore only the data/ and metadata/ members from each completed native ZIP, then unpack the compact evidence last. Copies of PLAN.md and acquire.py inside native ZIPs are historical acquisition snapshots; the compact evidence owns the final analysis code and corrected plans. Install versions in results/software-versions.json (numpy, scipy, h5py, hdf5plugin, requests, matplotlib). If missing native scans, resume acquire.py with their scan numbers, respecting server rate limits. The compressed cache is optional and not included. Do not infer a prior process remains alive.

Then run analyze.py for all six scans. It recomputes if its dense scratch Fourier cache is missing. Run analyze.py finish, recovery.py, validate.py. Event NPZs, dense Fourier arrays and optional compressed-source caches are reproducible from saved native powers and are omitted from this compact checkpoint; they are not distinct observations. Per-file source metadata, ranges/hashes and direct HDF5 parity checks are included. No entire .h5 node file was downloaded.

import json,csv
import numpy as np
from scipy import signal
from analyze import ROOT,OUT,DT,normalize,robust,binned,csvsave,jsonsave

def run():
    tests=[];contexts=[]
    for scan in range(13,19):
        a=np.load(ROOT/'data'/f'scan-{scan:04d}.npy');raw,diff,common,_=normalize(a)
        with (OUT/f'bursts-{scan:04d}.csv').open() as f:rows=list(csv.DictReader(f))
        with (OUT/f'periodicity-peaks-{scan:04d}.csv').open() as f:periods=list(csv.DictReader(f))
        for mode,x in [('raw',raw),('differential',diff)]:
            for group in ['target','control']:
                w=max([r for r in rows if r['mode']==mode and r['group']==group],key=lambda r:float(r['max_positive_z']))
                c=int(w['channel'])-48;factor=int(w['factor']);offset=int(w['offset'])
                y=binned(x[:,c,None],factor,offset)[:,0];m,s=robust(y);z=(y-m)/s;i=int(np.argmax(z))
                reconstructed=float(z[i]);err=abs(reconstructed-float(w['max_positive_z']));assert err<1e-3,(scan,mode,group,err,reconstructed,w['max_positive_z'])
                # Independent scalar mean of the original fractional-power samples at the winning bin.
                start=offset+i*factor;scalar=float(np.sum(x[start:start+factor,c],dtype=np.float64)/factor)
                mean_error=abs(scalar-float(y[i]));assert mean_error<1e-6
                lo=i;hi=i+1
                if z[i]>=5:
                    while lo>0 and z[lo-1]>=5:lo-=1
                    while hi<len(z) and z[hi]>=5:hi+=1
                    duration=(hi-lo)*factor*DT
                else:duration=0.
                contexts.append({'scan':scan,'role':'ON' if scan%2 else 'OFF','mode':mode,'group':group,'channel':c+48,'peak_z':reconstructed,'bin_seconds':factor*DT,'peak_mid_seconds':(start+.5*factor)*DT,'contiguous_positive_5sigma_duration_seconds':duration,'peak_fractional_mean':scalar,'neighbor_median_fractional_mean_at_same_bin':float(np.mean(common[start:start+factor]))})
                tests.append({'scan':scan,'type':'scalar bin mean and robust-z reconstruction','mode':mode,'group':group,'mean_error':mean_error,'z_error':err})
            w=max([r for r in periods if r['mode']==mode],key=lambda r:float(r['local_power_ratio']))
            c=int(w['channel'])-48;k=int(w['fourier_bin']);n=len(x)
            xd=signal.detrend(x[:,c].astype(np.float64),type='linear')
            direct=np.dot(xd,np.exp(-2j*np.pi*k*np.arange(n)/n))
            fft=np.fft.rfft(xd)[k]
            rel=float(abs(direct-fft)/max(abs(fft),1e-30));assert rel<1e-7
            # Recompute local spectral normalization for the published selected peak.
            f,p=signal.periodogram(x[:,c],fs=1/DT,detrend='linear',scaling='density')
            near=np.r_[p[k-50:k-2],p[k+3:k+51]];score=float(p[k]/np.partition(near,len(near)//2)[len(near)//2])
            score_error=abs(score-float(w['local_power_ratio']));assert score_error<2e-5*max(1,abs(float(w['local_power_ratio']))),(scan,mode,score,w['local_power_ratio'],score_error)
            tests.append({'scan':scan,'type':'direct complex DFT and local periodogram ratio','mode':mode,'channel':c+48,'fourier_bin':k,'DFT_relative_error':rel,'ratio_error':score_error})
        print('VALIDATED SCAN',scan,flush=True)
    csvsave(OUT/'strongest-event-contexts.csv',contexts)
    jsonsave(OUT/'validation.json',{'passed':True,'checks':tests,'n_checks':len(tests),'scope':'30 direct source-HDF5 scalar parity checks are separately in the six native manifests; these checks reconstruct derived statistics independently.'})
    print('VALIDATED',len(tests),'checks',flush=True)

if __name__=='__main__':run()

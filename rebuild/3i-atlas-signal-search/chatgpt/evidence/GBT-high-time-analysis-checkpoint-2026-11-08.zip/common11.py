import time,json
import numpy as np
from scipy import signal
from analyze import ROOT,OUT,DT,TARGET,CONTROL,normalize,csvsave,jsonsave

def measure(x,scan,name,part,start_sample):
    f,p=signal.periodogram(x,fs=1/DT,detrend='linear',scaling='density')
    ii=np.flatnonzero((f>=11.095)&(f<=11.125));ratios=[]
    for k in ii:
        neighbors=np.r_[p[k-50:k-2],p[k+3:k+51]];ratios.append(float(p[k]/np.partition(neighbors,len(neighbors)//2)[len(neighbors)//2]))
    k=int(ii[np.argmax(ratios)]);fr=float(f[k]);t=(np.arange(len(x))+.5)*DT
    design=np.column_stack([np.ones(len(t)),(t-t.mean())/np.ptp(t),np.sin(2*np.pi*fr*t),np.cos(2*np.pi*fr*t)])
    fit=np.linalg.lstsq(design,x,rcond=None)[0]
    return {'scan':scan,'role':'ON' if scan%2 else 'OFF','series':name,'part':part,'start_sample':start_sample,'n_samples':len(x),'peak_frequency_hz':fr,'local_power_ratio':max(ratios),'fractional_sinusoidal_amplitude':float(np.hypot(fit[2],fit[3])),'phase_radians_at_part_start':float(np.arctan2(fit[3],fit[2]))}

def run():
    rows=[]
    for scan in range(13,19):
        while not (ROOT/'metadata'/f'scan-{scan:04d}.json').exists():time.sleep(2)
        a=np.load(ROOT/'data'/f'scan-{scan:04d}.npy');raw=a/np.median(a,axis=0)-1
        for name,indices in [('all24',np.arange(24)),('target9',TARGET),('neighbor15',CONTROL)]:
            x=np.median(raw[:,indices],axis=1)
            for part,lo,hi in [('whole',0,len(x)),('first_half',0,len(x)//2),('second_half',len(x)//2,len(x))]:rows.append(measure(x[lo:hi],scan,name,part,lo))
        csvsave(OUT/'adaptive-11hz-common-mode.csv',rows)
        print('COMMON11',scan,[r for r in rows if r['scan']==scan and r['part']=='whole'],flush=True)
    jsonsave(OUT/'adaptive-11hz-summary.json',{'status':'complete','plan':'ADAPTIVE-11HZ-PLAN.md','rows':len(rows),'frequency_window_hz':[11.095,11.125],'scope':'Adaptive broadband check selected using ON13/ON15 and OFF14; later common-mode results not inspected at freezing; same observing epoch.'})

if __name__=='__main__':run()

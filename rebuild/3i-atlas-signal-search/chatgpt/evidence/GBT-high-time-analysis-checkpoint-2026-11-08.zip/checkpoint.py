import json,zipfile,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def pack(final=False):
    native=[]
    for p in sorted((ROOT/'results').glob('native-save-*.json')):
        r=json.loads(p.read_text());native.append({'scan':int(p.stem[-4:]),**r})
    complete=[int(p.stem[-4:]) for p in (ROOT/'metadata').glob('scan-*.json')]
    analyzed=[int(p.stem[-4:]) for p in (ROOT/'results').glob('analysis-*.json')]
    state={'native_scans_complete':sorted(complete),'timing_scans_complete':sorted(analyzed),'native_parts':native,'all_statistics_complete':(ROOT/'results/summary.json').exists(),'recoveries_complete':(ROOT/'results/recovery-summary.json').exists(),'validation_complete':(ROOT/'results/validation.json').exists(),'status':'complete' if final else 'partial; consult individual completion fields'}
    (ROOT/'results/checkpoint-state.json').write_text(json.dumps(state,indent=2))
    text='# Green Bank high-time follow-up — '+state['status']+'\n\n'
    text+='Native scans complete: '+str(sorted(complete))+'. Timing scans complete: '+str(sorted(analyzed))+'. See results/checkpoint-state.json for native ZIP IDs and confirmed save receipts.\n\n'
    text+='The initial request concerns the public .0001 high-time total-power products, NOT voltages or resolved individual-candidate modulation. Selection was fixed in PLAN.md, with metadata-only target-boundary and numerical-screen clarifications recorded there.\n\n'
    text+='Restore only the data/ and metadata/ members from each completed native ZIP, then unpack the compact evidence last. Copies of PLAN.md and acquire.py inside native ZIPs are historical acquisition snapshots; the compact evidence owns the final analysis code and corrected plans. Install versions in results/software-versions.json (numpy, scipy, h5py, hdf5plugin, requests, matplotlib). If missing native scans, resume acquire.py with their scan numbers, respecting server rate limits. The compressed cache is optional and not included. Do not infer a prior process remains alive.\n\n'
    text+='Then run analyze.py for all six scans. It recomputes if its dense scratch Fourier cache is missing. Run analyze.py finish, recovery.py, validate.py. Event NPZs, dense Fourier arrays and optional compressed-source caches are reproducible from saved native powers and are omitted from this compact checkpoint; they are not distinct observations. Per-file source metadata, ranges/hashes and direct HDF5 parity checks are included. No entire .h5 node file was downloaded.\n'
    (ROOT/'CHECKPOINT.md').write_text(text)
    paths=[]
    for f in ROOT.rglob('*'):
        if not f.is_file():continue
        rel=f.relative_to(ROOT)
        if any(x in rel.parts for x in ['cache','data','helpers','prior','__pycache__']):continue
        if f.name.startswith('event-') or f.name=='SHA256SUMS.json':continue
        if f.suffix in ['.py','.json','.md','.log','.csv','.npz','.png'] or f.name=='C03-equal-strength-envelope-evidence.zip':paths.append(f)
    contents={str(f.relative_to(ROOT)):f.read_bytes() for f in paths}
    sums={n:hashlib.sha256(b).hexdigest() for n,b in contents.items()}
    (ROOT/'SHA256SUMS.json').write_text(json.dumps(sums,indent=2))
    with zipfile.ZipFile(ROOT/'GBT-high-time-analysis-checkpoint.zip','w',zipfile.ZIP_DEFLATED,compresslevel=4) as z:
        for n,b in contents.items():z.writestr(n,b)
        z.write(ROOT/'SHA256SUMS.json','SHA256SUMS.json')
    print(json.dumps(state,indent=2));print('ARCHIVE_BYTES',(ROOT/'GBT-high-time-analysis-checkpoint.zip').stat().st_size)

if __name__=='__main__':
    import sys
    pack('final' in sys.argv)

import os, io, json, time, hashlib, struct, threading, concurrent.futures, bisect
from pathlib import Path
import numpy as np
import requests, h5py, hdf5plugin

ROOT=Path(__file__).resolve().parent
for n in ['data','cache','metadata','results']:(ROOT/n).mkdir(exist_ok=True)
BASE='https://bldata.berkeley.edu/ATLAS/GB_ATLAS/'
SCANS=[('17226',13,False),('17543',14,True),('17861',15,False),('18179',16,True),('18497',17,False),('18814',18,True)]
TLS=threading.local()
RATE_LOCK=threading.Lock()
NEXT_REQUEST=0.0
def throttle():
    global NEXT_REQUEST
    with RATE_LOCK:
        when=max(time.monotonic(),NEXT_REQUEST);NEXT_REQUEST=when+.055
    while time.monotonic()<when:time.sleep(min(1,when-time.monotonic()))
def session():
    if not hasattr(TLS,'s'):
        TLS.s=requests.Session()
        TLS.s.mount('https://',requests.adapters.HTTPAdapter(pool_connections=8,pool_maxsize=8))
    return TLS.s
def sha(b):return hashlib.sha256(b).hexdigest()
def clean(v):
    if isinstance(v,bytes):return v.decode(errors='replace')
    if isinstance(v,np.ndarray):return [clean(x) for x in v.tolist()]
    if isinstance(v,np.generic):return clean(v.item())
    return v
def atomicjson(p,x):
    q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(x,indent=2));q.replace(p)
class Remote(io.RawIOBase):
    def __init__(self,url,scan):
        self.url=url;self.scan=scan;self.pos=0;self.block=65536;self.cache={};self.ledger=[];self.headers={};self.bytes=0;self.nodes={};self.node_starts=[]
        self.disk=ROOT/'cache'/f'{scan:04d}';self.disk.mkdir(exist_ok=True)
        with session().get(url,headers={'Range':'bytes=0-65535'},timeout=(10,30),stream=True) as r:
            r.raise_for_status();assert r.status_code==206
            self.size=int(r.headers['Content-Range'].rsplit('/',1)[1]);b=r.raw.read(65536)
            self.etag=r.headers.get('ETag');self.headers=dict(r.headers)
        assert len(b)==65536 and b[:8]==b'\x89HDF\r\n\x1a\n'
        self.cache[0]=b;self.bytes+=len(b)
        self.ledger.append({'start':0,'size':len(b),'sha256':sha(b),'purpose':'metadata'})
    def fetch(self,start,end,purpose='metadata'):
        key=self.disk/f'{start}-{end}.bin'
        if key.exists():
            b=key.read_bytes();assert len(b)==end-start+1
            return b,{'start':start,'size':len(b),'sha256':sha(b),'purpose':purpose,'cached':True}
        for attempt in range(8):
            try:
                hdr={'Range':f'bytes={start}-{end}'}
                if self.etag:hdr['If-Match']=self.etag
                throttle()
                with session().get(self.url,headers=hdr,timeout=(10,30),stream=True) as r:
                    if r.status_code==429:
                        delay=float(r.headers.get('Retry-After',15));print('RATE LIMIT',self.scan,'delay',delay,flush=True)
                        with RATE_LOCK:
                            globals()['NEXT_REQUEST']=max(globals()['NEXT_REQUEST'],time.monotonic()+delay)
                    r.raise_for_status()
                    assert r.status_code==206 and r.headers.get('Content-Range','').startswith(f'bytes {start}-{end}/')
                    b=r.raw.read(end-start+1);assert len(b)==end-start+1
                tmp=key.with_suffix('.tmp');tmp.write_bytes(b);tmp.replace(key)
                return b,{'start':start,'size':len(b),'sha256':sha(b),'purpose':purpose,'cached':False}
            except Exception:
                if attempt==7:raise
                time.sleep(.25*(attempt+1))
    def readable(self):return True
    def seekable(self):return True
    def tell(self):return self.pos
    def seek(self,n,w=0):self.pos=n if w==0 else self.pos+n if w==1 else self.size+n;return self.pos
    def readinto(self,b):
        x=self.read(len(b));b[:len(x)]=x;return len(x)
    def read(self,n=-1):
        if n<0:n=self.size-self.pos
        n=min(n,self.size-self.pos)
        if n>8*1024*1024:raise RuntimeError('Unbounded read refused')
        out=[]
        while n>0:
            j=bisect.bisect_right(self.node_starts,self.pos)-1
            if j>=0:
                a=self.node_starts[j];v=self.nodes[a];off=self.pos-a
                if off<len(v):
                    b=v[off:off+n];out.append(b);n-=len(b);self.pos+=len(b);continue
            idx=self.pos//self.block;off=self.pos%self.block
            if idx not in self.cache:
                if len(self.cache)*self.block>16*1024*1024:raise RuntimeError('metadata budget')
                a=idx*self.block;z=min(a+self.block,self.size)-1
                b,rec=self.fetch(a,z);self.cache[idx]=b;self.ledger.append(rec);self.bytes+=len(b)
            b=self.cache[idx][off:off+n]
            if not b:break
            out.append(b);n-=len(b);self.pos+=len(b)
        return b''.join(out)
    def prefetch_tree(self,offset=3152):
        def children(node):
            assert node[:5]==b'TREE\x01'
            level=node[5];n=struct.unpack_from('<H',node,6)[0]
            assert n<=64
            return level,[struct.unpack_from('<Q',node,64+48*i)[0] for i in range(n)] if level else []
        self.seek(offset);node=self.read(3136)
        level,pending=children(node)
        print('TREE',self.scan,'level',level,'children',len(pending),flush=True)
        while pending:
            next_nodes=[]
            def get(a):return a,self.fetch(a,a+3135)
            with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
                for a,(b,rec) in pool.map(get,sorted(set(pending))):
                    self.nodes[a]=b;self.ledger.append(rec);self.bytes+=0 if rec['cached'] else len(b)
                    lev,ptr=children(b);next_nodes.extend(ptr)
            self.node_starts=sorted(self.nodes)
            print('METADATA',self.scan,'nodes',len(self.nodes),flush=True)
            pending=next_nodes

def acquire(scanrow):
    stamp,scan,off=scanrow
    out=ROOT/'data'/f'scan-{scan:04d}.npy';meta=ROOT/'metadata'/f'scan-{scan:04d}.json'
    if out.exists() and meta.exists():print('COMPLETE ALREADY',scan,flush=True);return
    name=f'blc23_guppi_61027_{stamp}_DIAG_3I_ATLAS'+('_OFF' if off else '')+f'_{scan:04d}.rawspec.0001.h5'
    r=Remote(BASE+name,scan)
    with h5py.File(r,'r') as f:
        d=f['data'];attrs={k:clean(v) for k,v in d.attrs.items()}
        assert d.chunks==(1024,1,8) and d.shape[1:]==(1,512)
        assert abs(attrs['foff']+.3662109375)<1e-12 and abs(attrs['tsamp']-.000349525333333333)<1e-15
        info={'url':r.url,'scan':scan,'role':'OFF' if off else 'ON','shape':d.shape,'chunks':d.chunks,'dtype':str(d.dtype),'attrs':attrs,'file_size':r.size,'etag':r.etag,'channel_indices':list(range(48,72)),'target_indices':list(range(56,65)),'control_indices':list(range(48,56))+list(range(65,72)),'filters':d._filters}
        atomicjson(ROOT/'metadata'/f'header-{scan:04d}.json',info)
        r.prefetch_tree()
        records=[]
        for t in range(0,d.shape[0],1024):
            chunks=[]
            for c in [48,56,64]:
                q=d.id.get_chunk_info_by_coord((t,0,c));assert q.byte_offset is not None
                chunks.append({'t':t,'c':c,'offset':q.byte_offset,'size':q.size,'mask':q.filter_mask})
            records.append(chunks)
        atomicjson(ROOT/'metadata'/f'chunk-index-{scan:04d}.json',records)
        # Consecutive frequency chunks are merged only when physically contiguous.
        jobs=[]
        for group in records:
            merged=[]
            for q in sorted(group,key=lambda q:q['offset']):
                if merged and q['offset']==merged[-1][-1]['offset']+merged[-1][-1]['size']:merged[-1].append(q)
                else:merged.append([q])
            jobs.extend(merged)
        print('ACQUIRE',scan,'n_jobs',len(jobs),'compressed_bytes',sum(q['size'] for g in records for q in g),flush=True)
        part=out.with_suffix('.partial.npy')
        arr=np.lib.format.open_memmap(part,mode='w+',dtype=np.float32,shape=(d.shape[0],24))
        # A tiny in-memory HDF5 dataset delegates bitshuffle/LZ4 to the registered original filter.
        with h5py.File(f'chunk-{scan}.h5','w',driver='core',backing_store=False) as temp:
            dec=temp.create_dataset('x',shape=(1024,1,8),chunks=(1024,1,8),dtype='float32',**hdf5plugin.Bitshuffle(nelems=0,lz4=True))
            def get(group):
                a=group[0]['offset'];end=group[-1]['offset']+group[-1]['size']-1
                return group,r.fetch(a,end,'compressed data')
            with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
                for done,(group,(blob,rec)) in enumerate(pool.map(get,jobs),1):
                    r.ledger.append(rec);r.bytes+=0 if rec['cached'] else len(blob)
                    for q in group:
                        begin=q['offset']-group[0]['offset'];raw=blob[begin:begin+q['size']]
                        dec.id.write_direct_chunk((0,0,0),raw,filter_mask=q['mask'])
                        values=dec[:,0,:]
                        n=min(1024,d.shape[0]-q['t']);arr[q['t']:q['t']+n,q['c']-48:q['c']-40]=values[:n]
                    if done%100==0:
                        arr.flush();print('PROGRESS',scan,done,'/',len(jobs),flush=True)
                        atomicjson(ROOT/'results'/f'progress-{scan:04d}.json',{'completed_jobs':done,'total_jobs':len(jobs),'new_bytes_including_metadata':r.bytes,'status':'partial'})
        arr.flush()
        checks=[]
        for t,c in [(0,48),(0,56),(0,64),(d.shape[0]//2,60),(d.shape[0]-1,71)]:
            source=float(d[t,0,c]);copy=float(arr[t,c-48]);assert source==copy
            checks.append({'t':t,'channel':c,'source':source,'copy':copy})
        del arr
        part.replace(out)
        info.update({'power_sha256':sha(out.read_bytes()),'byte_ranges':r.ledger,'new_bytes_including_metadata':r.bytes,'direct_hdf5_parity_checks':checks,'completed_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
        atomicjson(meta,info)
        print('SAVED',scan,out.stat().st_size,'bytes',flush=True)

if __name__=='__main__':
    import sys
    which=set(map(int,sys.argv[1:]))
    for row in SCANS:
        if not which or row[1] in which:acquire(row)

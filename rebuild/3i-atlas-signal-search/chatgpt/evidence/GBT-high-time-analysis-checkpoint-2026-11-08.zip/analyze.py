import json,csv,hashlib,time,itertools
from pathlib import Path
import numpy as np
from scipy import signal,ndimage
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
TARGET=np.arange(8,17);CONTROL=np.r_[0:8,17:24]
DT=.000349525333333333
FACTORS=sorted(set([1,4,16,64,256,1024,4096,round(1/DT),round(10/DT)]))
def jsonsave(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False))
def csvsave(p,rows):
    if not rows:return
    with p.open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def robust(x,axis=0):
    m=np.median(x,axis=axis);s=1.482602218505602*np.median(np.abs(x-m),axis=axis)
    return m,np.maximum(s,1e-12)
def normalize(a):
    med=np.median(a,axis=0)
    if not np.all(np.isfinite(a)) or np.any(med<=0):raise RuntimeError('Nonfinite or invalid median needs explicit quality amendment')
    raw=a/med-1
    common=np.median(raw[:,CONTROL],axis=1)
    diff=raw-common[:,None]
    for c in CONTROL:
        others=CONTROL[CONTROL!=c]
        diff[:,c]=raw[:,c]-np.median(raw[:,others],axis=1)
    return raw,diff,common,med
def binned(x,factor,offset=0):
    n=(len(x)-offset)//factor
    return x[offset:offset+n*factor].reshape(n,factor,-1).mean(axis=1)
def burstrows(x,scan,mode):
    rows=[]
    for factor in FACTORS:
        for offset in sorted(set([0,factor//2])):
            y=binned(x,factor,offset);m,s=robust(y);z=(y-m)/s
            for c in range(24):
                ip=int(np.argmax(z[:,c]));ia=int(np.argmax(np.abs(z[:,c])))
                rows.append({'scan':scan,'role':'ON' if scan%2 else 'OFF','mode':mode,'channel':c+48,'group':'target' if c in TARGET else 'control','factor':factor,'offset':offset,'bin_seconds':factor*DT,'n_bins':len(y),'median':float(m[c]),'robust_sigma':float(s[c]),'max_positive_z':float(z[ip,c]),'max_absolute_z':float(abs(z[ia,c])),'peak_time_seconds':(offset+(ip+.5)*factor)*DT,'peak_fractional':float(y[ip,c]),'positive_5sigma_bins':int((z[:,c]>=5).sum()),'negative_5sigma_bins':int((z[:,c]<=-5).sum()),'other_channels_5sigma_at_positive_peak':int((z[ip]>=5).sum()-int(z[ip,c]>=5))})
    return rows
def spectrum(x):
    # Periodogram with fixed linear detrend; native cadence and actual scan duration.
    f,p=signal.periodogram(x,fs=1/DT,detrend='linear',scaling='density',axis=0)
    # 101-bin window, exclude central five bins. Median is an empirical local reference.
    footprint=np.ones(101,dtype=bool);footprint[48:53]=False
    scores=np.empty(p.shape,dtype=np.float32)
    for c in range(x.shape[1]):
        local=ndimage.median_filter(p[:,c,None],footprint=footprint[:,None],mode='reflect')[:,0]
        scores[:,c]=p[:,c]/np.maximum(local,1e-30)
    return f,scores
def peaks(f,scores,scan,mode):
    lo,hi=np.searchsorted(f,[.1,1000]);records=[]
    for c in range(24):
        inds,_=signal.find_peaks(scores[lo:hi,c],distance=5)
        inds+=lo
        for rank,i in enumerate(inds[np.argsort(scores[inds,c])[-5:][::-1]],1):
            records.append({'scan':scan,'role':'ON' if scan%2 else 'OFF','mode':mode,'channel':c+48,'group':'target' if c in TARGET else 'control','rank':rank,'fourier_bin':int(i),'frequency_hz':float(f[i]),'local_power_ratio':float(scores[i,c])})
    return records
def analyze_scan(scan):
    dest=OUT/f'analysis-{scan:04d}.json'
    if dest.exists() and (ROOT/'cache'/f'scores-{scan:04d}.npz').exists():print('ANALYZED ALREADY',scan,flush=True);return
    a=np.load(ROOT/'data'/f'scan-{scan:04d}.npy')
    meta=json.loads((ROOT/'metadata'/f'scan-{scan:04d}.json').read_text())
    assert hashlib.sha256((ROOT/'data'/f'scan-{scan:04d}.npy').read_bytes()).hexdigest()==meta['power_sha256']
    raw,diff,common,med=normalize(a)
    quality=[]
    for c in range(24):
        m,s=robust(raw[:,c]);quality.append({'channel':c+48,'median_power':float(med[c]),'zero_samples':int((a[:,c]==0).sum()),'negative_samples':int((a[:,c]<0).sum()),'fractional_robust_sigma':float(s),'minimum':float(a[:,c].min()),'maximum':float(a[:,c].max()),'lag1_correlation':float(np.corrcoef(raw[:-1,c],raw[1:,c])[0,1]),'common_mode_correlation':float(np.corrcoef(raw[:,c],common)[0,1])})
    allburst=[];allpeak=[];welch=[]
    dense=ROOT/'cache'/f'scores-{scan:04d}.npz'
    powers=[]
    for mode,x in [('raw',raw),('differential',diff)]:
        print('BURSTS',scan,mode,flush=True);allburst.extend(burstrows(x,scan,mode))
        print('FOURIER',scan,mode,flush=True);f,s=spectrum(x);allpeak.extend(peaks(f,s,scan,mode));powers.append(s)
        wf,wp=signal.welch(x,fs=1/DT,nperseg=65536,noverlap=32768,detrend='linear',axis=0)
        welch.append(wp.astype(np.float32))
    np.savez(dense,f=f.astype(np.float32),raw=powers[0],differential=powers[1])
    np.savez_compressed(OUT/f'welch-{scan:04d}.npz',frequency=wf,raw=welch[0],differential=welch[1])
    envelope=binned(raw,round(.1/DT));envdiff=binned(diff,round(.1/DT))
    np.savez_compressed(OUT/f'envelope-{scan:04d}.npz',raw=envelope,differential=envdiff,dt=round(.1/DT)*DT)
    csvsave(OUT/f'bursts-{scan:04d}.csv',allburst);csvsave(OUT/f'periodicity-peaks-{scan:04d}.csv',allpeak)
    # Save native-scale extrema with neighboring samples, not only smoothed plots.
    events=[]
    for mode,x in [('raw',raw),('differential',diff)]:
        for c in TARGET:
            m,s=robust(x[:,c]);i=int(np.argmax(x[:,c]));a0=max(0,i-4096);a1=min(len(x),i+4097)
            events.append({'mode':mode,'channel':int(c+48),'sample':i,'time_s':i*DT,'z':float((x[i,c]-m)/s),'start':a0,'stop':a1})
            np.savez_compressed(OUT/f'event-{scan:04d}-{mode}-{c+48}.npz',start=a0,raw=raw[a0:a1],differential=diff[a0:a1])
    jsonsave(dest,{'scan':scan,'role':meta['role'],'n_samples':len(a),'duration_s':len(a)*DT,'start_mjd':meta['attrs']['tstart'],'quality':quality,'common_robust_sigma':float(robust(common)[1]),'burst_rows':len(allburst),'periodic_peak_rows':len(allpeak),'events':events})
    print('ANALYSIS SAVED',scan,flush=True)

def finish():
    scans=list(range(13,19));rows=[];ps=[];summaries=[]
    for scan in scans:
        summaries.append(json.loads((OUT/f'analysis-{scan:04d}.json').read_text()))
        with (OUT/f'bursts-{scan:04d}.csv').open() as f:rows.extend(list(csv.DictReader(f)))
        with (OUT/f'periodicity-peaks-{scan:04d}.csv').open() as f:ps.extend(list(csv.DictReader(f)))
    csvsave(OUT/'all-burst-tests.csv',rows);csvsave(OUT/'all-periodicity-peaks.csv',ps)
    # Frequency rules selected from top-five target peaks only; all scans/channels rescored at each fixed frequency.
    freq_rules={}
    for r in ps:
        if r['role']=='ON' and r['group']=='target':
            # Consolidate identical/nearby FFT lines only after retaining all original rows.
            key=(r['mode'],round(float(r['frequency_hz']),2))
            freq_rules.setdefault(key,float(r['frequency_hz']))
    scores={};freq_axes={}
    for scan in scans:
        z=np.load(ROOT/'cache'/f'scores-{scan:04d}.npz');freq_axes[scan]=z['f'];scores[scan]={m:z[m] for m in ['raw','differential']}
    comparisons=[]
    for (mode,key),fr in sorted(freq_rules.items()):
        target=[];control=[]
        for scan in scans:
            f=freq_axes[scan];i=int(np.argmin(abs(f-fr)));inds=np.arange(max(1,i-1),min(len(f),i+2))
            v=scores[scan][mode][inds].max(axis=0)
            target.append(float(v[TARGET].max()));control.append(float(v[CONTROL].max()))
        on=[target[i] for i in [0,2,4]];off=[target[i] for i in [1,3,5]]
        lead=sum(v>=10 for v in on)>=2 and max(off)<5 and max(control)<5
        comparisons.append({'mode':mode,'frequency_hz':fr,'ON13_target_max':target[0],'OFF14_target_max':target[1],'ON15_target_max':target[2],'OFF16_target_max':target[3],'ON17_target_max':target[4],'OFF18_target_max':target[5],'neighbor_control_max':max(control),'screen_pass':lead})
    csvsave(OUT/'periodicity-crosschecks.csv',comparisons)
    # Within-pair ON/OFF randomization applies to broad variability, not individual pointwise bins.
    metrics=[]
    for mode in ['raw','differential']:
        for factor in FACTORS:
            vals=[]
            for scan in scans:
                subset=[r for r in rows if int(r['scan'])==scan and r['mode']==mode and int(r['factor'])==factor and r['group']=='target']
                vals.append(max(float(r['max_positive_z']) for r in subset))
            differences=np.array(vals)[[0,2,4]]-np.array(vals)[[1,3,5]]
            stat=float(differences.mean());null=[float(np.mean(differences*np.array(s))) for s in itertools.product([-1,1],repeat=3)]
            metrics.append({'mode':mode,'factor':factor,'seconds':factor*DT,'ON_minus_OFF_mean_max_z':stat,'pair_swap_tail':sum(v>=stat-1e-10 for v in null)/8,'scan_maxima':vals})
    jsonsave(OUT/'paired-comparisons.json',metrics)
    # Compact descriptive maxima and the channel carrying each.
    maxima=[]
    for scan in scans:
        for mode in ['raw','differential']:
            for group in ['target','control']:
                rr=[r for r in rows if int(r['scan'])==scan and r['mode']==mode and r['group']==group]
                winner=max(rr,key=lambda r:float(r['max_positive_z']))
                maxima.append(winner)
    csvsave(OUT/'maximum-burst-by-scan.csv',maxima)
    jsonsave(OUT/'summary.json',{'scans':summaries,'target_channels':list(range(56,65)),'control_channels':list(range(48,56))+list(range(65,72)),'burst_tests':len(rows),'periodic_peaks':len(ps),'frequency_crosschecks':len(comparisons),'periodic_screen_passes':[r for r in comparisons if r['screen_pass']],'paired_comparisons':metrics,'numerical_screen':'At least two ONs >=10 local power ratio; every OFF target <5 and every neighboring-control maximum <5, within +/-1 FFT bin. Screening heuristic; trials not a detection p value.'})
    # Figures preserve scan separations and show target/control behavior together.
    fig,axes=plt.subplots(6,2,figsize=(13,14),sharex='col')
    for row,scan in enumerate(scans):
        z=np.load(OUT/f'envelope-{scan:04d}.npz');t=(np.arange(len(z['raw']))+.5)*z['dt']
        for col,mode in enumerate(['raw','differential']):
            ax=axes[row,col];x=z[mode]
            for c in TARGET:ax.plot(t,x[:,c],lw=.6,alpha=.65)
            ax.plot(t,np.median(x[:,CONTROL],axis=1),color='black',lw=.7,label='neighbor median')
            ax.set_ylabel(f'{scan} '+('ON' if scan%2 else 'OFF')+'\nfractional power');ax.grid(alpha=.2)
            if row==0:ax.set_title(mode+'; 0.100 s bins')
    axes[-1,0].set_xlabel('Seconds within each scan');axes[-1,1].set_xlabel('Seconds within each scan');fig.tight_layout();fig.savefig(OUT/'time-envelopes.png',dpi=150);plt.close(fig)
    fig,axes=plt.subplots(3,2,figsize=(13,10),sharex=True)
    for ax,scan in zip(axes.flat,scans):
        z=np.load(OUT/f'welch-{scan:04d}.npz');f=z['frequency'];p=z['raw'];mask=(f>=.1)&(f<=1000)
        ax.loglog(f[mask],np.median(p[:,TARGET],axis=1)[mask],label='target median');ax.loglog(f[mask],np.median(p[:,CONTROL],axis=1)[mask],label='neighbor median',alpha=.8)
        ax.set_title(f'Scan {scan} '+('ON' if scan%2 else 'OFF'));ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.supxlabel('Temporal frequency (Hz)');fig.supylabel('Fractional-power density / Hz');fig.tight_layout();fig.savefig(OUT/'temporal-spectra.png',dpi=150);plt.close(fig)
    print('FINISHED',len(comparisons),'period rules;',sum(r['screen_pass'] for r in comparisons),'pass',flush=True)

if __name__=='__main__':
    import sys
    if sys.argv[1:] and sys.argv[1]=='finish':finish()
    else:
        for scan in map(int,sys.argv[1:] or range(13,19)):analyze_scan(scan)

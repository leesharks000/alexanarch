import json,csv
from pathlib import Path
import numpy as np
from scipy import signal
from analyze import ROOT,OUT,DT,normalize,robust,binned,csvsave,jsonsave

def run(periods_only=False):
    a=np.load(ROOT/'data/scan-0013.npy');raw,diff,_,_=normalize(a)
    if periods_only:
        with (OUT/'burst-injection-trials.csv').open() as f:rows=list(csv.DictReader(f))
    else:
        rng=np.random.default_rng(20261108);rows=[]
        for c in [16,7]: # absolute high-time channel 64 and neighboring control 55
            for mode,matrix in [('raw',raw),('differential',diff)]:
                x=matrix[:,c].copy()
                for width in [1,16,256,4096]:
                    positions=rng.integers(10*4096,len(x)-10*4096,size=8)
                    for amp in [.001,.003,.01,.03,.1,.3,1.0]:
                        for trial,center in enumerate(positions):
                            y=x.copy();sigma=width/2.354820045
                            lo=max(0,int(center-5*sigma)-2);hi=min(len(y),int(center+5*sigma)+3)
                            y[lo:hi]+=amp*np.exp(-.5*((np.arange(lo,hi)-center)/sigma)**2)
                            best=-1e30;basebest=-1e30
                            for offset in sorted(set([0,width//2])):
                                by=binned(y[:,None],width,offset)[:,0];base=binned(x[:,None],width,offset)[:,0]
                                m,s=robust(by);bm,bs=robust(base)
                                k=int((center-offset)//width);inds=np.arange(max(0,k-2),min(len(by),k+3))
                                best=max(best,float(((by[inds]-m)/s).max()));basebest=max(basebest,float(((base[inds]-bm)/bs).max()))
                            rows.append({'channel':c+48,'mode':mode,'FWHM_samples':width,'FWHM_seconds':width*DT,'peak_fractional_amplitude':amp,'trial':trial,'center_sample':int(center),'injected_peak_z':best,'background_peak_z':basebest,'recovered_6sigma':best>=6})
                    print('BURST RECOVERY',c+48,mode,width,flush=True)
        csvsave(OUT/'burst-injection-trials.csv',rows)
        summary=[]
        keys=sorted(set((r['channel'],r['mode'],r['FWHM_samples'],r['peak_fractional_amplitude']) for r in rows))
        for c,m,w,amp in keys:
            rs=[r for r in rows if (r['channel'],r['mode'],r['FWHM_samples'],r['peak_fractional_amplitude'])==(c,m,w,amp)]
            summary.append({'channel':c,'mode':m,'width_samples':w,'width_seconds':w*DT,'amplitude':amp,'recovered':sum(r['recovered_6sigma'] for r in rs),'n':len(rs),'background_6sigma':sum(r['background_peak_z']>=6 for r in rs)})
        csvsave(OUT/'burst-injection-summary.csv',summary)
    periods=[];t=(np.arange(len(raw))+.5)*DT
    for c in [16,7]:
        for mode,matrix in [('raw',raw),('differential',diff)]:
            x=matrix[:,c]
            for fr in [1,10,100]:
                for amp in [.00003,.0001,.0003,.001,.003,.01]:
                    for phase in [0,np.pi/2,np.pi,3*np.pi/2]:
                        y=x+amp*np.sin(2*np.pi*fr*t+phase)
                        f,p=signal.periodogram(y,fs=1/DT,detrend='linear',scaling='density')
                        i=int(np.argmin(abs(f-fr)));scores=[]
                        for k in [i-1,i,i+1]:
                            neighbors=np.r_[p[k-50:k-2],p[k+3:k+51]]
                            scores.append(float(p[k]/np.partition(neighbors,len(neighbors)//2)[len(neighbors)//2]))
                        score=max(scores)
                        periods.append({'channel':c+48,'mode':mode,'frequency_hz':fr,'fractional_amplitude':amp,'phase':float(phase),'local_power_ratio':score,'prescribed_frequency_screen_recovered':score>=10})
                print('PERIOD RECOVERY',c+48,mode,fr,flush=True)
    csvsave(OUT/'period-injection-trials.csv',periods)
    ps=[]
    for c,m,fr,amp in sorted(set((r['channel'],r['mode'],r['frequency_hz'],r['fractional_amplitude']) for r in periods)):
        rs=[r for r in periods if (r['channel'],r['mode'],r['frequency_hz'],r['fractional_amplitude'])==(c,m,fr,amp)]
        ps.append({'channel':c,'mode':m,'frequency_hz':fr,'amplitude':amp,'recovered':sum(r['prescribed_frequency_screen_recovered'] for r in rs),'n':len(rs)})
    csvsave(OUT/'period-injection-summary.csv',ps)
    # Explicit bandwidth dilution scale, not a claim of narrowband sensitivity.
    W=.02636159403603917;D=1.798*149597870700;flux=W/(4*np.pi*D**2)/1e-26
    jsonsave(OUT/'recovery-summary.json',{'burst_trials':len(rows),'period_trials':len(periods),'seed':20261108,'burst_definition':'Gaussian positive added fractional power, fixed baseline, FWHM as recorded; same robust bin detector, >=6 pointwise z; prescribed injection location, not blind-search completeness','period_definition':'Full-scan sinusoid, same Fourier/local-median statistic, >=10 at prescribed frequency +/- one bin; not blind-search completeness or ON/OFF joint recovery','one_high_time_channel_hz':366210.9375,'dilution_2p7939677_Hz_to_broad_bin':366210.9375/2.7939677238464355,'conditional_C03_integrated_flux_JyHz':flux,'conditional_C03_fraction_of_12p5Jy_system_in_one_broad_bin':flux/(12.5*366210.9375),'warning':'Transmitter strength/calibration from prior conditional C03 fit; unknown frequency response, pointing and modulation. Total-power bin cannot isolate C03.'})
    print('RECOVERY COMPLETE',len(rows),len(periods),flush=True)

if __name__=='__main__':
    import sys
    run('periods-only' in sys.argv)

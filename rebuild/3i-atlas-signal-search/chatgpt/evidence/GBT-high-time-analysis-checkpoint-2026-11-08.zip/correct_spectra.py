import json,hashlib,time
import numpy as np
from scipy import ndimage
from analyze import ROOT,OUT,normalize,spectrum,peaks,csvsave,finish,jsonsave
from validate import run as validate
from report import run as report

foot=np.ones(101,dtype=bool);foot[48:53]=False
ar=np.arange(201.)
one=float(ndimage.median_filter(ar,footprint=foot)[100])
two=float(ndimage.median_filter(ar[:,None],footprint=foot[:,None])[100,0])
truth=float(np.partition(ar[50:151][foot],48)[48])
assert two==truth==103
jsonsave(OUT/'sparse-footprint-regression.json',{'installed_1d_sparse_filter_result':one,'explicit_2d_result':two,'direct_order_statistic':truth,'correction':'Use explicit 2D (frequency by singleton) footprint. Installed 1D fast path did not respect intended sparse window. Primary Fourier ratios/peaks/crosschecks rerun; native arrays and burst results unchanged. Common-mode/injection/scalar-validation methods use direct order statistics.'})
for scan in range(13,19):
    a=np.load(ROOT/'data'/f'scan-{scan:04d}.npy');raw,diff,_,_=normalize(a)
    records=[];ss=[]
    for mode,x in [('raw',raw),('differential',diff)]:
        print('CORRECT SPECTRUM',scan,mode,flush=True)
        f,s=spectrum(x);records.extend(peaks(f,s,scan,mode));ss.append(s)
    np.savez(ROOT/'cache'/f'scores-{scan:04d}.npz',f=f.astype(np.float32),raw=ss[0],differential=ss[1])
    csvsave(OUT/f'periodicity-peaks-{scan:04d}.csv',records)
    print('CORRECTED',scan,flush=True)
finish()
print('Run validate.py and report.py in fresh processes to bound peak memory.',flush=True)

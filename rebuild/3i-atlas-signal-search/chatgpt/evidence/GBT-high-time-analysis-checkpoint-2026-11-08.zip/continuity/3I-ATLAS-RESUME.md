# CURRENT — C03 CSV reconstruction supplement COMPLETE; original results unchanged

2026-11-05. Following Claude's independent audit, a standalone CSV now reconstructs all 24 observation/track products (996 rows), including all 18 published GBT scan-table rows. Maximum score error 8.881784197e-16; maximum power error 1.332267630e-15 W. Common GBT fit reconstructs exactly at 0.02636159403603917 W. Supplement ZIP also exposes all 2400 whole-scan spectral-control amplitudes. Original report, CSVs and evidence ZIP are unchanged; original evidence SHA256 verified as 4547e6ca946f35627881eb81c0b589a15c7c2e555d145caf8d7faa0afca1221e.

Difference of estimators: temporal rows subtract each row's control median; the whole-scan fit weights raw rows and then subtracts the median of whole-scan control amplitudes. The original row CSV alone omitted the terms for that second calculation. This was an export-completeness gap, not a numerical contradiction. The new CSV supplies weights, distance factors, centres, scales and physical conversion factors. No new astronomical observation, emitter test or source classification.

Saved supplement:
- C03-scan-fit-reconstruction.csv: libfile_67962aa23da081918eea97c9855744f2
- C03-scan-fit-reconstruction-notes.md: libfile_2d2319cd1bf08191befc7aa0a32225d1
- C03-scan-fit-reconstruction-supplement.zip: libfile_e7c85c491be48191a82166928d1f9da2

Scope corrections: the new ATA 10 W benchmark gives 100/100 target-only and 87/100 joint recoveries, not survey-wide completeness. No resolved exceptional temporal variation was found under the tested ~30/61/122 s windows; this is not proof of no burst. Strict GBT ON scores are 2.667, 2.398, 1.849. Distances vary per integration about 1.797980763–1.798004367 AU, with 1.798 a rounded description.

Claude separately reported a satellite run 3/7 channels complete, four pending. This session did not inspect that run or verify its completion. Preserve full false-frame distributions and untrimmed/trimmed branches. Strongest-row trimming needs injection recovery for burst/sparse signals, not only clutter suppression. Completed partial channels and current run state should be durably saved now, independently of the eventual final bundle. These are requirements for follow-up, not new results.

Previous C03 and pending upper-strip/Wow/Parkes records remain unchanged below.

# CURRENT — C03 equal-transmitter-strength and time-profile experiment COMPLETE

2026-11-05. Bounded experiment completed; no measurement or simulation job remains pending. New cross-telescope physical mean-power benchmark (not the old detector) uses six already-examined GBT scans and three already-examined ATA pairs. All nine original archives verified; 24 C03 observation/track profile products directly checked. 7,200 fixed power-grid trials; 36 float32/local-baseline checks pass, max score error 4.73029836e-06. Nominal descriptive C03 Gaussian power fit 0.026361594 W; GBT SEFD 10–15 Jy gives 0.021089275–0.031633913 W. These are conditional on calibration, width, comet distance and unit on-axis response, not a measured transmitter or unbiased interval. ON17 actual tracking remains unresolved.

Equal fitted EIRP adds only 0.015497–0.017463 ATA detector-score units at nominal calibration, 0/100 recoveries; all fifteen GBT/ATA calibration-scenario projections give 0/100. Under nominal calibration, fixed 0.1 W injections recover 100/100 GBT targets but 0/100 ATA targets; at 10 W both recover 100/100 targets. Joint reference screens are lower and separately recorded. This weakens the inference from ATA absence against a persistent very faint source; it does not establish that such a source exists.

Measured time profile: native 6.084537 s integrations and fixed ~30.4 s bins, all real gaps and ON/OFF pointing roles preserved. No per-integration frequency maximization. Strict common track, previous per-scan peaks and receiver-fixed diagnostic exported separately. The best bounded time contrast has 74/100 spectral controls at least as high after the identical 345-window family. No resolved exceptional burst or physical switching time. OFF14 has positive fitted amplitude; different sky pointings cannot demonstrate a comet source switching off. Under the new strict physical-template detector C03 does not pass the three-ON gate. This does not overwrite the older tolerance-dependent result. Original thirteen descriptive supplement complete: 3822 rows, twenty local spectral controls per candidate; no new source classifications.

Saved final artifacts:
- C03-equal-strength-envelope-report.md: libfile_06d9df0415f0819193a52b80741bb92a
- C03-temporal-envelope.png: libfile_62c03314873081918c9833ac025a2d7c
- C03-equal-transmitter-recovery.png: libfile_b45633aecb108191b96d6bf6be891611
- C03-temporal-envelope.csv: libfile_9a3b5af5a4388191beb11109b003eab7
- Original13-temporal-profiles.csv: libfile_b77ef073caf88191800e15952063a4e1
- C03-equal-strength-envelope-evidence.zip: libfile_e2e70f78bbd88191a0f8605930c03bfa

Evidence version 1, SHA256 4547e6ca946f35627881eb81c0b589a15c7c2e555d145caf8d7faa0afca1221e, 2437305 bytes. Plan is libfile_aedfd18c2bc881919943d2fac6ac0cbd; plan JSON libfile_903d305fe21c8191a128a82655e1075f. Native powers remain at the IDs in inputs/observations.json and inputs/native-input-ledger.json. README-reproduce.md explains clean restoration/recomputation. Model uses representative published SEFD, no new per-scan calibration, measured beam response, source self-noise or detailed channelizer response. Full Doppler/clock budget absent.

Next substantive work: actual antenna/gain/beam records and unused appropriately sensitive matching-frequency observations, or a separately fixed intermittent/relational signal hypothesis. Do not call an unknown feature human merely because a screen fails. Do not turn this into a technosignature detection or an exclusion of all emission classes. The full 3648–3687.75 MHz search has NOT run; Parkes comet powers remain uninspected. Earlier Wow-guided continuation remains unfinished and separate. All prior checkpoints below retained.

# CURRENT — C03 physical comparison: INPUTS AND FIXED PROFILES COMPLETE

2026-11-05. All six GBT native archive/power hashes and three ATA paired archive hashes verified. 24 fixed-track profile products complete (GBT strict/legacy/receiver; ATA strict), with independent direct-bin scalar checks. New experiment uses physical Gaussian width and calibration scenarios, not equal raw-MAD additions. Evidence checkpoint save underway; inspect confirmed receipt for its ID/version. Resume analyze.py envelope recovery validation after verifying inputs/frozen-plan-proof.json; no new source acquisition needed. Native inputs remain at the IDs in inputs/observations.json; copy them and run prepare_inputs.py to restore. Actual ON17 tracking unresolved; per-scan SEFD not measured. Final recovery and time-envelope interpretation still pending. Project c03-equal-strength-20261105.

# CURRENT — C03 equal-transmitter-strength and temporal-envelope analysis ACTIVE

2026-11-05. User authorizes equal hypothetical physical transmitter strength across GBT and ATA plus a measured temporal envelope. Project c03-equal-strength-20261105. Plan v1 saved before new scoring; native inputs are previously examined, not blind data. Restore C03 model evidence libfile_b859876c81348191928a8a40c0c73a10 and C03 follow-up evidence libfile_30a7cba244288191b5634a465f7e5a4f; six GBT IDs in audit/inputs/native-input-ledger.json; three ATA C03 paired inputs libfile_1e5ab075742c8191b90a791dc82f029c, libfile_d97acc5464f88191b65fe1970f0160e6, libfile_0c4b2b1b57a08191ae11616aba261326. Native input verification/calibration implementation pending. No new recovery/envelope result yet. Original ON17 tracking unresolved; published SEFD scales are scenario assumptions, not per-scan calibration. Other full-strip and Wow branches retain their prior status.

# CURRENT — upper-strip feasibility pilot COMPLETE

2026-11-05. No full-strip search or Parkes source-data follow-up was run. Actual ATA upper channel-cell edge is 3687.750000 MHz. One ATA July 3 observation, four fixed 1 MHz regions, all 19 integrations and both beams, plus the first Parkes July 31 reference observation in the three upper regions. Strong-tone requirement all pass: True. 96 raw-power recovery cases; 32 source-HDF5 parity comparisons; direct-score maximum error 0. Region outcomes: [{"region": "low", "target_pass": 6, "shared_pass": 0, "target_n": 12, "shared_n": 12, "strong_required_pass": 2}, {"region": "middle", "target_pass": 7, "shared_pass": 0, "target_n": 12, "shared_n": 12, "strong_required_pass": 2}, {"region": "edge", "target_pass": 6, "shared_pass": 0, "target_n": 12, "shared_n": 12, "strong_required_pass": 2}, {"region": "centre", "target_pass": 6, "shared_pass": 0, "target_n": 12, "shared_n": 12, "strong_required_pass": 2}].

Completed compact evidence: confirmed Library version 1; SHA256 1316ea467af0dc7bcec13ac9da17e3853a1aa427e8a772f85e48003e979ee56c; 482852 bytes. Portable plan guard was verified after a simulated clean restore.

Saved final files:
- ATA-upper-strip-pilot-report.md: libfile_bc4989a08ac08191bdad4e7b4c384db5
- ATA-upper-strip-pilot.png: libfile_e81929f472388191890852144f67ef15
- ATA-upper-strip-pilot-compact-evidence.zip: libfile_0a085ba548fc819180cdf0d3afa8ff46

Native evidence parts:
- ATA-upper-pilot-C0928-0-evidence.zip: libfile_b62539c73020819193d3f311ac9ce03c
- ATA-upper-pilot-C0928-1-evidence.zip: libfile_ece347eb78308191b2a1920131dee4f2
- ATA-upper-pilot-C1504-0-evidence.zip: libfile_0036c118abfc8191a40ac5ddeb7be3eb
- ATA-upper-pilot-C1504-1-evidence.zip: libfile_875c2b272de481918521405b499c5e6b
- ATA-upper-pilot-parkes-evidence.zip: libfile_8565f28d3fa0819194c340f1b3f99a7b

Resume from the final report and compact evidence together with native parts as needed. Do not call this a new signal detection or a survey null. Strong injected-tone recovery is in measured raw-row MAD units, not flux-calibrated astronomical sensitivity. Parkes source powers remain uninspected. Other survey completion and any prior exposure outside recovered records remain unknown. Next: document/model celestial reference-beam leakage or retain a separately controlled shared-beam branch, reconcile exposure/survey status, freeze full-strip discovery/reserve, controls, thresholds, quality exclusions, multiplicity and candidate cap, then ATA search; frozen ATA candidates only proceed to Parkes with its own observer ephemeris. The claimed absence of other public coverage is disproved by the saved Parkes header audit. Keep earlier CH/Wow/C03 branches and limitations separate.

# CURRENT — upper-strip pilot checkpoint: parkes

2026-11-05. Stage parkes native acquisition is complete, source hashes and CRC verified; checkpoint save in progress. Evidence archive: ATA-upper-pilot-parkes-evidence.zip; SHA256 7de48dcd7cb26ba0656da0f3867543ac5ce22d21d18cffaed15387692034bd90. Project ata-edge-pilot-20261105. Plan MD libfile_88885d3743a48191b550e792081fda88 and plan JSON libfile_45d87815054c8191939155eca4d00a48 are saved. Read per-stage save receipts to distinguish confirmed saves. Remaining stages and recoveries are pending unless a later entry says complete. Parkes SOURCE powers remain uninspected. Preserve the unknown status of the other survey and prior exposure. Resume acquisition using acquire_pilot.py (SHA-checked caches), then recovery_pilot.py; do not restart full-band acquisition or decode Parkes source powers.

# CURRENT — upper-strip pilot checkpoint: C0928-1

2026-11-05. Stage C0928-1 native acquisition is complete, source hashes and CRC verified; checkpoint save in progress. Evidence archive: ATA-upper-pilot-C0928-1-evidence.zip; SHA256 f73cf667de2e403356168f7027b159f48656ca521cf9eafc1aebc75bd2a6a1f1. Project ata-edge-pilot-20261105. Plan MD libfile_88885d3743a48191b550e792081fda88 and plan JSON libfile_45d87815054c8191939155eca4d00a48 are saved. Read per-stage save receipts to distinguish confirmed saves. Remaining stages and recoveries are pending unless a later entry says complete. Parkes SOURCE powers remain uninspected. Preserve the unknown status of the other survey and prior exposure. Resume acquisition using acquire_pilot.py (SHA-checked caches), then recovery_pilot.py; do not restart full-band acquisition or decode Parkes source powers.

# CURRENT — upper-strip pilot checkpoint: C0928-0

2026-11-05. Stage C0928-0 native acquisition is complete, source hashes and CRC verified; checkpoint save in progress. Evidence archive: ATA-upper-pilot-C0928-0-evidence.zip; SHA256 c32f8de521324d37a71d2a154930e3873c4462b899f036c13f8b308bd85d2a01. Project ata-edge-pilot-20261105. Plan MD libfile_88885d3743a48191b550e792081fda88 and plan JSON libfile_45d87815054c8191939155eca4d00a48 are saved. Read per-stage save receipts to distinguish confirmed saves. Remaining stages and recoveries are pending unless a later entry says complete. Parkes SOURCE powers remain uninspected. Preserve the unknown status of the other survey and prior exposure. Resume acquisition using acquire_pilot.py (SHA-checked caches), then recovery_pilot.py; do not restart full-band acquisition or decode Parkes source powers.

# CURRENT — upper-strip pilot checkpoint: C1504-1

2026-11-05. Stage C1504-1 native acquisition is complete, source hashes and CRC verified; checkpoint save in progress. Evidence archive: ATA-upper-pilot-C1504-1-evidence.zip; SHA256 3f675ef55955bc05584b4c55df905b7f6e7c8f6a2ba2cf45c824c930af5c74f4. Project ata-edge-pilot-20261105. Plan MD libfile_88885d3743a48191b550e792081fda88 and plan JSON libfile_45d87815054c8191939155eca4d00a48 are saved. Read per-stage save receipts to distinguish confirmed saves. Remaining stages and recoveries are pending unless a later entry says complete. Parkes SOURCE powers remain uninspected. Preserve the unknown status of the other survey and prior exposure. Resume acquisition using acquire_pilot.py (SHA-checked caches), then recovery_pilot.py; do not restart full-band acquisition or decode Parkes source powers.

# CURRENT — upper-strip pilot checkpoint: C1504-0

2026-11-05. Stage C1504-0 native acquisition is complete, source hashes and CRC verified; checkpoint save in progress. Evidence archive: ATA-upper-pilot-C1504-0-evidence.zip; SHA256 c58ac6e35ea3a76e01faa62867f28afb5610a431d03482bfc430d9decd0ec224. Project ata-edge-pilot-20261105. Plan MD libfile_88885d3743a48191b550e792081fda88 and plan JSON libfile_45d87815054c8191939155eca4d00a48 are saved. Read per-stage save receipts to distinguish confirmed saves. Remaining stages and recoveries are pending unless a later entry says complete. Parkes SOURCE powers remain uninspected. Preserve the unknown status of the other survey and prior exposure. Resume acquisition using acquire_pilot.py (SHA-checked caches), then recovery_pilot.py; do not restart full-band acquisition or decode Parkes source powers.

# CURRENT — upper-strip pilot fixed, acquisition pending

2026-11-05. Pilot plan is being saved before any new target-power decoding. Project: ata-edge-pilot-20261105. Actual ATA upper cell edge 3687.750000 MHz. Four 1 MHz tiles; one ATA observation, both beams; Parkes reference only. No 64-channel survey completion available in recovered record; exposure beyond recovered records unknown. Full-strip work and Parkes source powers are not released. Resume from pilot plan and inputs/source-metadata.json; verify durable plan receipt before acquisition.

# Coverage correction — proposed 3648–3688 MHz strip has public Parkes data

4 November 2026 (America/New_York). The quoted claim that 3648–3688 MHz is uniquely covered by public ATA July 3 data is superseded by direct Parkes header witnesses. July 31 blc27 has fch1=3776 MHz, foff=−0.000002 MHz, nchans=64,000,000: nominal 3648–3776 MHz. blc31 continues 3776–3904; blc32 continues 3904–4032. Each checked source file has 2 Hz channels, 15-second sampling, 32-bit single-IF samples and a payload consistent with 20 integrations. This establishes recorded file coverage, not usable sensitivity or a completed independent null.

Saved audit report: libfile_1e6d33b8f1308191b5b26d7c9512e7c5. Raw-header witnesses, hashes and reproducible code: libfile_2722530b75608191b5be35e49af7fb16 (archive SHA256454d4068db2509b0e41e5618029de559f74bc1f7bc1902d0ddaa9b9289452b09).

This metadata-only audit attempted one first-source high-resolution .0000.fil file per 26 listed July31 nodes: 25 headers verified; blc12 remains unverified because no matching source link was obtained. The verified nominal union is 704–1984 and 2112–4032 MHz. Do not claim continuous independently verified Parkes coverage through the unresolved node, or an audit of every cadence/file/date. September and October Parkes folders also exist, but their file coverage was not established here.

The 3648 cutoff may describe a previous reanalysis limit; it is not the public Parkes frequency ceiling. Correct any next ranking/plan accordingly. July3 ATA remains a distinct observing epoch. A useful revised strategy is ATA discovery followed by July31 Parkes independent-instrument checking with predictions frozen before inspecting the corresponding source powers. This audit decoded no powers and started no bulk 40 MHz acquisition; the other survey's 64-channel milestone was not inspected or scheduled here.

Important plan details: use signed foff per file (the 25 verified Parkes nodes include five ascending and twenty descending axes); retain/reuse demonstrated physical-chirp sign checks; qualify usable sensitivity rather than equating header coverage with a scientific null. FCC 24-136 footnote534 identifies 3600–3700 MHz extended-C fixed-satellite space-to-Earth service, so the proposed strip's interference inventory is not exclusively ground-based LTE. Allocation does not identify any particular hit's origin. Calibration/quality and source-mask overhead should be included before a large power read.

The completed 3332–3339 MHz and 2694–2696 MHz results below are unchanged. The drift-sign question and the corrected archival-coverage finding are separate evidentiary claims. Preserve earlier frozen packets. The new metadata audit is complete and recoverable; it is not a new signal search.

---

# Completed record packaging

The 63 dense score maps are saved separately as libfile_b6fd8cd8049081919556a1961fde6e26 (236373909bytes, SHA25662d19b42b65f5e5ef5f38f8b229a517e576775a5c70d6927170380672cd8beec). Their original paths and hashes are in results/score-map-manifest.json. The smaller main evidence archive retains all frame JSONs, gate ledgers, full cluster contributions, code, diagnostics and exact external native/map identities. No derived map or research data was discarded. This packaging resolves the failed combined-archive save; confirmed target versions remained unchanged by that failed preparation.

All scientific results below are complete. Older active headers are retained history. The next unresolved question is the origin of the receiver-fixed 3336/3332MHz features; this pass does not identify them as human or extraterrestrial sources.

---

# COMPLETE — ATA 3332–3339 MHz pass

Completed at 2026-11-05T00:57:02.904777+00:00. This new pass is finished; earlier active-stage headers below are history. Older Wow-guided work remains unfinished and is not discharged by this pass.

Report: libfile_2f197049378081918516ad1caa7db477. Corrected diagnostic image: libfile_66ddb3e60c3081919cfa5c2ca6363c3c. Evidence identity: libfile_f6ec1f23c0508191b0d1432cccbee0e6. Exact frozen packet: libfile_981212f21ed08191930a5aae7a14664a, SHA2562409a200195023ea4e553d4d792a04af8012739ad7e8ec178c6e1991fbeea5d1. All12native beam excerpts are externally saved; the evidence manifest lists their exact Library identities, restore filenames and archive hashes. No live process is required to preserve this result.

The full seven reference MHz were searched in all3discovery observations. All903frame/tile/observation selected maxima passed independent native-bin arithmetic; maximum score error3.32e-7. All84selected continuation paths passed, maximum error1.46e-7. All48ordinary-HDF5 parity checks passed across twelve beams; masks were zero. All36declared recovery cases completed, with strong target-only recovery, weak misses and0/18equal raw additions passing. These are finite benchmarks, not universal sensitivity bounds.

Six screened comet-track clusters and five subthreshold comet-track comparisons, plus3receiver and3flipped nominees, were frozen externally before reserve focal-power decoding. None of17nominees passed the fixed screen in any of3later observations. Added-slope comparison-family maxima equaled/exceeded the comet maximum in31/40cases. This is a conditional rank, not a global p value. Eighteen alternative-template screened clusters were outside the follow-up cap; their full ledger is retained without a null claim. Continuation tested the frozen representative frequency/duration of each chosen cluster, not every contributing cell/duration. Several template labels sample overlapping one-integration paths and are not independent witnesses.

There is also a positive descriptive result: the same native bin near3336MHz (+0.954Hz nominal center,1.907Hz channel width) is elevated in both beams in all6time-averaged scans. It stays receiver-fixed while the frozen comet path moves. An aggregate secondary excess appears near3332MHz. Native-bin contrasts averaged over six scans/two beams are about+167%at3336and+41%at3332relative to local sidebands. These post-freeze comparisons do not identify an origin, prove a frequency comb or imply an artificial source. The early diagnostic's frequency guide was removed; the final image contains measured powers and only the lime CT05 trajectory overlay.

Useful next unresolved question: identify the3336/3332MHz features against independent calibration/unrelated-target data and instrument processing, rather than declaring them human-sourced by beam coincidence alone. That origin check has NOT been completed. The bounded search result itself is complete. Use README.md, requirements.txt and verify_checkpoint.py to restore/review. Source coordinates, full contribution ledger, all gate counts, controls, raw-excerpt provenance and code are saved in the evidence. Preserve the frozen packet unchanged.

---

# Frozen discovery complete — reserve released after confirmed exact save

All903discovery frame/tile/observation scores and their independent selected native-bin checks are complete. Full discovery froze17nominees:6screened true-track clusters plus5subthreshold true-track comparisons,3receiver-fixed and3flipped. All6screened true clusters are followed;15receiver and3flipped screened clusters are outside the declared cap and are retained without a null claim. True family maximum6.129140220837041;31/40wrong-frame family maxima equal/exceed it. Robust scores and this rank do not identify an origin.

Frozen packet: libfile_981212f21ed08191930a5aae7a14664a, SHA2562409a200195023ea4e553d4d792a04af8012739ad7e8ec178c6e1991fbeea5d1. Exact-save success receipt and matching frozen_sha256 are in results/save-freeze.json. Reserve acquisitions3/4/5 started only AFTER this confirmed save; metadata-only preparation of all6reserved beams was completed earlier as allowed. Preserve the original packet unchanged. Any correction requires a labelled supplement.

The large full-contribution discovery cluster ledger is retained and tied to the packet by SHA; the evidence bundler streams it and skips redundant completed native chunk caches. All6discovery beam excerpts are separately saved. Current work: acquire both reserved beams for3/4/5, save each completed native beam, run followup.py INDEX and check_selected.py INDEX for each tile containing nominees, then followup.py summary, diagnostics.py and report.py. plot_clock_region.py provides only a post-freeze descriptive view. Never relabel a single-integration template agreement as a measured drift or a failed repeat as a proof of human origin.

Discovery2 completed normally after one incomplete HTTP body was rejected and resumed; all masks were zero, source checks passed. The new freeze/proof and all completed source-scoring code are in this checkpoint. Older stage headers below preserve the completed prior pilot and other unfinished branches. Consult actual live job handles before launching duplicates; restored logs alone do not establish a running process.

---

# Current stage — all discovery native beams saved; three scoring jobs active

Time: 2026-11-05T00:29:11.675547+00:00. All six native discovery beam archives are complete and externally saved. Final native beam2/1: libfile_f6c820a6c5a881918bd9c2cc807b6eca. The evidence SHA manifest lists all six exact Library identities and restore filenames. Discovery observations0,1,2 are scoring across all7tiles; current committed frame counts {'0': 264, '1': 256, '2': 52} /301 each. 12/21observation-tiles have independent selected-score checks complete. Run finish_checks.py to verify subsequent committed tiles; it is a bounded in-session worker, not a scheduled service. All36recovery cases complete as recorded below. Still no global nominee freeze or reserved focal-power decode.

prepare_reserved.py is reading metadata only for observations3,4,5 while discovery runs. Cached source blocks may contain uninterpreted surrounding bytes as part of HDF5 metadata reads, but no reserved data/mask dataset slice is decoded or scored. It calls no data slicing or signal analysis. Source metadata/scripts and the enforced reserve lock are in this evidence version. The lock requires an externally saved exact new frozen packet plus its matching SHA.

On resume, check live process handles before launching duplicates; files are committed restart units, not proof of a live job. Complete the current discovery and 903 native-bin checks, freeze and externally save predictions, then acquire/follow up reserved observations and verify them. Previous completed pilot, erratum and older unfinished Wow-guided branch remain intact below.

---

# Latest recoverable stage — discovery scoring and recovery checks

Time: 2026-11-05T00:23:09.125989+00:00. Evidence identity libfile_f6ec1f23c0508191b0d1432cccbee0e6. Native discovery beams 0/0, 0/1, 1/0, 1/1, 2/0 are externally saved. Additional beam2/0 identity: libfile_b268e363a8e881918cd7980bb1b3e262. The evidence's checkpoint-file-manifest.json lists exact filenames, Library identities, sizes/hashes and included partial-cache files. Discovery2 beam1 is still being acquired.

Committed discovery-frame counts at this timestamp: {'0': 94, '1': 86, '2': 0}; final requirement is 301 per observation, 903 total. No global nominee freeze or reserved focal powers. All 36 recovery benchmarks have completed: target-only amplitudes2/4/8 raw-rowMAD recover 0/3,0/3,3/3 at L4 and 0/3,3/3,3/3 at L19. Equal raw additions to both beams: 0/18 pass. Zero-amplitude identity passed at all3placements; independent Gaussian-bin quadrature error <=4.1e-10. These are finite injected benchmarks, not completeness/flux limits. Selected-score native-bin checks for observation0/tile0: all43frames passed within1e-5. Other tile checks pending.

Source acquisition and scoring can resume from committed units. Inspect actual active jobs first; restored logs do not prove a process is running. New freeze/follow-up/recovery/scalar wrappers are written; recovery has run on real native backgrounds, while global freeze and follow-up must wait for all discovery. Earlier stage headers are retained as history below.

---

# Active saved stage — full 3332–3339 MHz discovery underway

Snapshot time: 2026-11-05T00:21:09.162321+00:00. New evidence identity: libfile_f6ec1f23c0508191b0d1432cccbee0e6. Prospective plan: libfile_21f8387ef05c819198566176391c4b09. Completed previous pilot remains unchanged below.

Both beams of discovery observations 0 and 1 are complete, source HDF5 checked, array hashes recorded, native archives durably saved. Observation 2 acquisition is in progress. Discovery scoring currently has {'0': 41, '1': 33, '2': 0} completed frame/observation/tile JSONs out of 301 per observation, 903 total. These are partial counts at snapshot time. No new global candidate freeze, no reserved 3332–3339 MHz powers, no source-origin conclusion or null claim.

Saved native archives (restore these into native/ under their exact filenames):
- ATA-CH3332-pair0-beam1-2026-11-04.npz: libfile_df3c362c236c8191a0234a94c10e86fd
- ATA-CH3332-pair1-beam1-2026-11-04.npz: libfile_10adc36c41748191a591e741ef881eb9
- ATA-CH3332-pair0-beam0-2026-11-04.npz: libfile_97be7db15f008191910a3ff89aea22fb
- ATA-CH3332-pair1-beam0-2026-11-04.npz: libfile_2242be4e100c8191aa4b35831a3f2dac


The evidence ZIP includes code, exact prior ephemeris, source metadata/layouts, partial blocks for incomplete native beams, committed partial results, and a SHA manifest. Completed native bytes are stored separately by the IDs above; their redundant compressed source chunks are omitted from this checkpoint. Large NPY caches can be regenerated from native archives. Helpers are deliberately omitted; retrieve fresh current Library transfer helpers on a new run. Restore the evidence into ata-ch-search-20261104. Verify the outer ZIP CRC and contained SHA manifest before resuming.

Current source paths: acquire.py INDEX; search.py INDEX [TILE ...]; check_selected.py INDEX [TILE ...]; recovery.py. All freeze/follow-up/recovery/scalar wrappers for the new band are written and compile, but full source-data execution is still pending. Synthetic detector arithmetic check passed. Follow-up and recovery apply the corrected gate BEFORE selecting a reporting maximum; maximum-J control ranks are kept separately.

Next: finish observation 2 and any interrupted discovery tiles; source-bin scalar checks over all 903 frame cases; 36 raw-power recovery benchmarks; freeze.py only when all discovery files are committed. Save the exact new frozen-nominees.json externally and add its SHA256 as frozen_sha256 in results/save-freeze.json alongside its confirmed success receipt, BEFORE acquire.py 3/4/5. Freeze gate verifies matching bytes. Run continuation and scalar checks, retain all gate-passing clusters including capped ones, and report all finite limits. Never let an older freeze release this reserve.

Current observing data downloads intermittently return network-tunnel 403. Ordinary same-endpoint resume reads verified cached blocks; no credentials or alternate access path are used. A failed download is pending work, not a scientific null. Old stopped attempts are logs only; live processes cannot be inferred from restored files. Re-run only after checking active sessions.

---

# Active restart checkpoint — ATA 3332–3339 MHz

The previous 2694–2696 MHz pilot is complete and preserved below. The new full 7 MHz plan is saved as libfile_21f8387ef05c819198566176391c4b09. The first acquisition attempts for discovery observations 0 and 1 stopped with a network-tunnel 403. A normal retry on observation 0 is receiving further public chunks; observation 1 is being retried in parallel. No complete native beam or observation yet, no discovery score or new nominee, no reserved focal powers read.

New working directory: ata-ch-search-20261104. Restore the separate ATA-CH3332 evidence ZIP into this directory. It contains the new code, the exact saved ephemeris, source inventory/layouts, and SHA-checked partial compressed source blocks. Large sparse HDF5 placeholders and regenerable NPY caches are deliberately omitted. Retrying acquire.py uses the saved chunks without redownloading them. Current pass is active, not a null result.

Synthetic detector cross-check passed: 48 windows, 34 passing cells, exact all-cell gate counts and ledger, independently summed boxcar arithmetic within 1e-9. No actual source-power inference follows from this check. Standalone legacy core-grid/freeze entry points have been removed from the new code to prevent reuse of the old frequency band. search.py configures current tiles.

Next: complete both discovery beams for observations 0–2 and save each externally; search all seven tiles with all 43 frames; run independent source-bin checks and recovery; freeze a NEW globally ranked nominee packet durably before decoding reserved observations 3–5. Do not use any old pilot freeze to release the new reserve. Follow the new plan for the corrected gate order and all-cell ledger. Full-band freeze/follow-up/recovery wrappers still need implementation before that stage.

---

# ACTIVE: new ATA 3332–3339 MHz search, restartable tiles

4 November 2026. User asks to proceed after the interface froze. Previous2694–2696MHzpilot is COMPLETED and preserved; its corrected source and exact saved evidence were restored from Library after scratch reset. This is NEWwork in3332–3339MHz,not a rerun ofoldresults. Newfolderata-ch-search-20261104. New plan ATA-CH3332-search-plan-2026-11-04.md fixes all7MHz in seven1MHztiles; first3July3sourceobservations discovery,next3reserved. No newfocalpowersread yet. Correct gate order:retainALLeligiblecells beforeclustering; addall-cellcounts. Freezeup to10screened+5subthresholdtrue nominees andup to3screenedreceiver/3screenedflipped alternatives.40wrong-trackfamilymaxima spanalltiles/observations; newreserve requiresnewconfirmedfrozenpacket.

Recovery36cases planned at3fixedfractional-phaseplacements; scalar/sourcechecks andpairedmetadata checks required. PublicsourcebandexpectedLoD.C0928,metadata mustconfirm. Persistentcachedblocks/atomicbeams andper-frame/tile resultssurvivepauses; saveeachcompletedbeamexternally. Codeadaptationandmetadata preparation inprogress. EarlierWowbranchremainsunfinished; C03simulationcomplete; oldATApilotcompletecorrected. Fullpreviouscheckpointbelowpreserved.

--- Prior checkpoint preserved ---

# COMPLETED AND CORRECTED: ATA protected-band negative-drift pilot

4 November 2026. This bounded pass is COMPLETE. No acquisition, scoring, recovery or validation job remains pending in it. Final report: ATA-negative-pilot-report-2026-11-04.md. Diagnostic: ATA-negative-pilot-N06-2026-11-04.png. Evidence identitylibfile_a1a9a5abb02481918835fdf1ceb3b5c1 (final replacement follows this checkpoint). Exact native12beamIDs, source URLs and SHA256s ininputs/native-inputs.json; allsaved. Reconstructpairswithrestore_pairs.py; replayusessavedephemeris. Code and corrected/historical versions are preserved. No need to restart this completed pilot after a pause.

CORRECTED RESULTS: 2694–2696MHzpilot only (central2MHzofprotected2690–2700band). All129discoveryframe/observationbatches,36rawrecoverycases,48ordinaryHDF5source-slice checks complete; six pairedtime/frequencymetadata checks pass, allmaskszero. Originaltrue-familymaxJ5.900833568;23/40wrong-framefamilymaxima ashigh. Originalfivefrozen subthresholdnominees N01–N05 allfailcontinuation screens inall3reserved observations. Originalfreezelibfile_ef9f6dade4e0819187c5d5411e9e24a4 unchanged.

A gate-order omission initially yielded a WRONG zero-candidate count. Full-cell audit found N06, one true-track gate-passing cell:2695050834.6557617Hz reference coordinate; discovery0,L4integrations,start9 (67.1s template);ON6.094020792,OFF0.998020026,J5.096000766. PreselectionoflocalJmaxima suppressedthiseligiblecell. Correctedsearchretainsallgatepassingcellsbeforeclustering; exactpre-correctioncodeanderratumretained. N06is belowall40wrongframefamilymaxima. Supplementpacketlibfile_8c8870614f308191a9cbd1b0548f25a9; erratumlibfile_e38965ea19888191831313751bd91dae. ItsfixedcontinuationwasEXPLORATORY POST-FREEZE:reservedrawextractionhadbegun,butnoreserveddetectionscoreshadbeenexaminedwhenN06seated. Originalfive predictionsnotchanged.

N06 later bestJ inreserved3/4/5=1.232329447/1.843590741/2.481452748;allfailON6/J3. Any-scan100frequencycontrols:54asgoodorbetter. N06unreplicated/sourceunidentified; notprovennoise,andnotidentifiedtransmitter. RC01receiver-template maximum at2694002790.45105Hz,discovery1,L1,start13,ON6.516608077,J6.496980765also retainedunclassified. ItsseparatelylabelledfullyPOSTHOCreceiver-fixed±10Hz/L1followupfailsall3;bestlaterJ3.026217525,40/100controlsasgood. Aone-integrationfeaturedoesnotestablishstationarityordrift.

Recoverytargetonly byamp2/4/8raw-MAD:L4=0/3,0/3,3/3;L19=1/3,3/3,3/3. Equalshared0/18passes;zeroampbitwiseidentity,12binintegralquadraturechecks. Notflux/EIRPlimits. All129discoveryselectednativepathchecks maxerror3.45137e-7;36original/supplementlaterpathchecks max2.27e-7;6additionalreceiverlaterchecks pass;N06rawscalarcheckmax1.03e-7. Fullresults/ledgersretained. Transferoflastbeamfailedoncewithtunnel403; resumedfromcachedblocksandcompletedbeam,succeededwithoutauth/bypass.

PENDING OUTSIDE THIS COMPLETED PASS: scientificpriority4990–4999MHzstill403atfirstindexedchild/canonicaldirectfilesJuly5/10. No5GHzpowerssearched. Remaining2690–2694/2696–2700MHz,CHwindows3260–3264/3332–3339/3345.8–3352.5MHz,and8650–9000MHzunsearchedbythisnewdetector. Furthernewcandidateworkneedsanewboundedplan; RC01/N06 remaininledgerasunknown,notdiscardedasidentifiedhuman. EarlierWow-guidedcontinuationremainsunfinished,distinctbranch;C03simulationcomplete. Previouscheckpointsbelowarehistorical,andtheirzero-countclaimsare supersededbythiscorrection.

--- Historical checkpoints preserved ---

# CORRECTION: one gate-passing candidate was missed by peak-selection order

This supersedes the earlier zero-candidate count. A complete all-cell audit found ONE screen-passing cell in discovery0: N06 at receiver-reference2695050834.6557617Hz, L4integrations, start9; z_target6.094020792438343,z_reference0.99802002642929,J5.096000766009053. Native-bin scalar reconstruction passes. The code selected local maxima of jointJ before applying z_target>=6; this omitted a non-maximal-J cell that passes both gates. search.py now retains every eligible cell before clustering. all-cell-gates-summary.json proves1cell in0and0in1/2; selection-erratum.json andsupplementary-candidate.json preservecorrection. Candidate is below all40wrong-track familymaxima, so it is a marginal screening feature, not a statistically exceptional/source-identified detection.

The ORIGINAL FIVEfrozen nominees andtheirSHA3095b3068347705d4689ca47bac9ac0bb2a5547bd33632373df6f88595d4fd40 remain UNCHANGED. freeze() now refuses to overwrite an existing freeze. N06is an EXPLORATORY POST-FREEZEADDITION: reserved3/4rawextraction hadbegun, but NOreserved detectionscores hadbeenexamined. Do not call N06continuation preregistered. seat_supplement.py verifiesrawbins andrecords per-integrationcontributions. Supplementrule fixedbefore itsfollowup: physicaltrack,sameL4,allstarts,±10Hz,100deterministicfrequencycontrols. Followup.py--supplement3/4/5 producesSEPARATEsupplement-followupfiles/summary,leavingoriginalfiveresultsseparate.

NEXT: save supplementary-candidate.json externally BEFORE scoringit; saveallnewbeamarchives; finishreserved5(acquire35session50607)and4session13546 ifstillactive; followup.py3/4/5original and--supplement; check_followup.py mustincludeoriginal andsupplementselectedpaths; completealltables/erratum/report. Reserved3/4pairedinputscomplete now,5acquiring. All129discoverybatches/36recoveries/nativechecks alreadycompleteandpreserved. Mainfolderata-negative-search-20261104. Evidenceidentitylibfile_a1a9a5abb02481918835fdf1ceb3b5c1; planlibfile_91881700e2f48191a82e6f1680322751; originalfreezelibfile_ef9f6dade4e0819187c5d5411e9e24a4. CPpreviousversion50. EarlierWowbranchunfinished,C03simulationcomplete. Priorrecords retained for audit, not silently rewritten.

--- Earlier checkpoint (zero count corrected above) ---

# ATA protected-band pilot: discovery complete; reserved continuation active

4 November 2026. All 129 discovery track/observation batches are complete. Zero screen-passing true-track clusters. Best true-track joint scores 5.900833568,5.786750451,5.720770242; 23/40 wrong-track family maxima equal/exceed the true-family maximum. All36rawinjections complete; recovery table preserved below. All129 selected native-bin scalar checks pass, maximum score error3.45137e-7. Native-source decoder/mask checks passed for all3discovery pairs (24slices), maskszero. All6discoverybeams saved externally. No artificial/source identification.

Five nominees FROZEN and durably saved aslibfile_ef9f6dade4e0819187c5d5411e9e24a4, SHA2563095b3068347705d4689ca47bac9ac0bb2a5547bd33632373df6f88595d4fd40. Coordinates receiver-reference Hz/L/start/pair:2694774097.442627/1/14/0;2694897573.4710693/1/9/1;2695641851.425171/1/15/2;2695328689.5751953/4/7/0;2695103307.723999/4/12/2. These are SUBTHRESHOLD nominees, not detections. Do not change coordinates or durations. A single integration does not measure drift. Frozen receiptresults/save-freeze.json must be retained in evidence so reserve guard survives restoration.

Reservedfocal acquisition started only AFTER confirmed freeze save. Active sessions50607(acquire3then5),13546(acquire4). Metadata-onlywarmup99315(3/5),55330(4), no powers decoded beforefreeze. Do not launch duplicate acquisitions if thosejobs stilllive; otherwise acquire.py reusesverifiedblocks andcompletedbeams. Newworkfolderata-negative-search-20261104, planlibfile_91881700e2f48191a82e6f1680322751, evidenceidentitylibfile_a1a9a5abb02481918835fdf1ceb3b5c1. NEXT: finish3/4/5; saveeachcompletedbeam; followup.py3/4/5 at±10Hz/sameL/allstarts with100controls andany-scanmaximum; report.py onlyafterallfollowupandsourcechecks. Native-IDledgerinputs/saved-identities.json, restore_pairs.py reconstructslocalpairs. Never infer missingjobcompletionfromelapsedtime.

5GHzpriority4990–4999MHzremainspending403atfirstindexedchildandcanonicaldirectfilesJuly5/10. PilotcoversONLY2694–2696MHz,notall10MHzorotheradoptedwindows. EarlierWow-guidedbranchstillunfinished,separate;C03simulationcomplete. Fullpriorcheckpointsretainedbelow.

--- Prior checkpoint preserved ---

# ATA pilot — discovery powers and recovery complete, controls still finishing

Recoverable step4Nov2026: ALL3discovery nativepairs0/1/2complete, all6beamarchives externallysaved withCRC/SHA/source-decoderchecks. True-track search ineach hasNOscreenedpeaks(zON>=6,J>=3). BestJ0/1/2=5.900833568/5.786750451/5.720770242; allbestL1. Sign-reversed maxima comparable. 0and1all43framesdone;2controls stillrunning session39835.129batchesrequiredtotal. Never call a one-integration peak a measured drift. Native2-1libfile_57448f57d764819188e5d27abdadd4d8;native2-0libfile_a2198117446c8191be724f0565c620cd;previous4IDsbelow. inputs/saved-identities.json willindexallconfirmedreceipts.

ALL36rawrecoverycasesdone: target-onlyL4passes amp2/4/8=0/3,0/3,3/3;L19=1/3,3/3,3/3. Equalrawadditionsbothbeams0/18pass. Zeroampbitwiseidentity;12independentbinintegralchecks pass. These are normalized/raw-MADbenchmarks, notflux/EIRPlimits. Selectednativepathscalarchecksfor0/1running session87658,2mustfollowaftercontrols2finish.

Reserved3/4/5focalpowers remain NOTDECODED/SCORED. Metadata-onlywarmup sessions99315(scans3/5),55330(scan4) fetchheaders/chunkindexes withPersistentRange forlater; nofocaldataarraysread. Newwarm_metadata.py isexplicitmetadata-only. Planstillrequiresfreezing5nomineesandCONFIRMEDexternalsave(results/save-freeze.json)beforeacquire.py3/4/5. Preserveall129controlbatches,36recoverycases andscalarchecks thenrunsearch.pyfreeze/save/release reserve. Followup.pyalreadyfixed±10Hz/sameL/allstarts/100controls;report.pyprepared but mustnotrunclaimcompleteuntilreservedresultsandchecks exist.

Evidenceidentitylibfile_a1a9a5abb02481918835fdf1ceb3b5c1; fixedplanlibfile_91881700e2f48191a82e6f1680322751;workfolderata-negative-search-20261104. Mostrecentcachesnapshotincludespartialmetadata/sourceblocks andfinishedframecases. Newcompletebeamsdurable:restorebeamsfromIDsandrunrestore_pairs.py,thenresumecompletedatomicframesratherthanrestartall. EarlierWowbranchunfinished,C03simulationcomplete. Priorcheckpointbelowretained.

--- Prior checkpoint preserved ---

# ATA pilot recoverable progress — 4 November2026

Two paired discovery scans0/1complete andsourceverified. Theirtrue-track searches give no zON>=6/J>=3screened peaks; bestjointscores5.900834 and5.786750. ThisisPARTIAL: wrongtrackcontrolbatchesstillrunning, scan2beam0complete/beam1acquiring. No nomineesfrozen andreservedscans3/4/5stillUNREAD. First2pairedpowers are saved byfourbeamarchives; beam2-0isnextsave. ExactnativeIDs are in save receipts andinputs/saved-identities.json. Nativepairsregenerablewithrestore_pairs.pyfromsavedbeamsandmanifests.

Evidenceidentitylibfile_a1a9a5abb02481918835fdf1ceb3b5c1 (version3afterlatestconfirmedwrite) contains code,partialdiscoverybatches,sourcecachesforincompletebeams,metadata andephemeris. Planlibfile_91881700e2f48191a82e6f1680322751. Currentworkfolderata-negative-search-20261104. SourcecacheSHArequired; completedbeamsCRC/source-decoder-checked. Nativebeam0-0libfile_bc8510f2fcac8191b6165e826f711a7f;beam0-1libfile_466c0fe81c788191b2f5f494a403f5b8;beam1-0libfile_cc6814471cc08191bb1844393efebc00;beam1-1libfile_c41a7b906dd48191810b46cb3abdc527.

ActivejobIDs inthisruntime: search0session17007;search1session31196;acquire2session14740;36-case rawrecovery session62079. Initialnonpersistentacquisition58671wasinterrupted andconfirmedexit130; donotresurrectit. Checkremainingjobsifstilllive; do notassumecompletedafterpause. search.py skipscompletedatomicframeJSONs; recovery.py skipscompletedcaseJSONs; acquire.py reusesSHA-checkedsourceblocks andcompletedbeams. FIRSTremainingsteps: finishacquire2, search2; finishall129discoveryframebatchesand36recoverycases; runcheck_selected.py; freeze5nomineeswithsearch.pyfreeze; SAVEfrozen-nominees.jsonusinghelper(receiptsave-freeze.json)BEFOREreserveacquisition. acquire.pyenforcesconfirmedfrozen-save receipt. Followup.pyalreadypreparedfor3/4/5,±10HzsameL/allstarts,100matchedfrequencycontrols; any-scanresultmustretaintrialscope. No detections/sourceidentificationyet. 5GHzcanonicaldirectfileRangeprobesalsoreturned403(firstscanJuly5and10); noauthenticationorprivateaccessattempts.

EarlierWow-guidedworkremainsunfinished,separate. C03simulationcomplete. Priorcheckpointpreservedbelow.

--- Prior checkpoint preserved ---

# Recoverability checkpoint — ATA pilot in progress, 4 November2026

User explicitly requires in-progress work survive timeouts/usage pauses. Evidence identitylibfile_a1a9a5abb02481918835fdf1ceb3b5c1 now checkpoints code/plan/ephemeris/access and source range/chunk caches. Planlibfile_91881700e2f48191a82e6f1680322751. Firstbeam0-0native extraction completed CRC and ordinary-HDF5 decoder checks; being saved separately asbeam-0-0.npz. Do not claim pairedscan or science result yet. Pair0beam1 andpair1 acquisitionongoing underpersistent hash-checkedcache. Runlogs distinguish initialnoncachedattempt fromcheckpointed acquisition. Completedcacheblocks can be restored fromevidence and reused; completednativebeams are skipped. Sourcebytecaches keyedbyURLhashandbyteoffset withSHA; never treat missing/incomplete files as completed.

NEXT: finish paired discovery0/1/2 acquisition; runsearch.py0/1/2 and36rawinjections; freezeandSAVE5nominees before acquiringreserved3/4/5. Followup.py/check_selected.py prepared but noresults. Oldinitialacquisitionmaybe stillrunning; it duplicatesfirstpair but notnewscientificdata. Trust CRC/hashverified completedarchives and inputmanifests, notlogexistence. EarlierWowunfinished; C03simulationfinished. Priorcheckpointbelow retained.

--- Prior checkpoint preserved ---

# Active ATA protected-band negative-drift pilot — 4 November2026

LeeSharks adopts broader candidate search and the specific ranked regions. 4990–4999MHz priority remains pending: first indexed scan child on July5and10again403; parentindexes200. Exact access log saved. Accessible fallback central2MHz2694–2696MHz inJuly3LoC.C0928; first3chronological scans discovery,next3reserved. PLAN.md saved aslibfile_91881700e2f48191a82e6f1680322751 before focalpowerdecoding. Newfolderata-negative-search-20261104. Exactfirstheader andNASAobserverephemeris saved. No discoveryoutcome yet. Acquire0/1/2running. Searchincludes lengths1/4/8/19, smear-awareodd boxcar, physicalnegative/sign-flipped/receiver/40wrongtracks, beamswap; zON6/J3screens,5nominees, full-trial controlmaxima. Reservedpowersnotdecodeduntil nomineesfrozenandsaved. 36rawinjectionsplanned. Preserveeverycompletedpair/outputexternally; no backgroundcompletionclaim.

EarlierC03simulationcomplete (reportlibfile_d9ef622857c08191885c10e8e8c0d4a6,evidencelibfile_b859876c81348191928a8a40c0c73a10). OlderWow-guidedfollowupremainsunfinished,separatebranch; no cancellation. Fullpriorcheckpointbelow.

--- Priorcheckpointpreserved ---

# Completed C03 transmitter-model simulation — 4 November 2026

This bounded simulation is COMPLETE. No simulation or validation job remains pending. New exact filenames: C03-model-simulation-report-2026-11-04.md; C03-model-simulation-evidence-2026-11-04.zip; C03-model-simulation.png. Frozen plan Library ID libfile_3ee57920fab48191a87768cfdc05d2de. Search exact titles if their new Library IDs are not in the session receipt. Code folder c03-model-simulation-20261104. Six original native power IDs remain in audit/inputs/native-input-ledger.json and earlier checkpoint.

53 configurations across 6 emitting families; 100 reused local and 256 broad metadata-only placements; normalized equal-total-power levels 2.8/5.6/11.2. All 56,604 injected and 356 uninjected cases saved with profiles reconstructable from backgrounds.npz + responses.npz, every metric in all-trials.csv. Baseline calibrations and prior C03 profile reproduce exactly. Observed strict margin -0.32697835, tolerant +0.14851608; peak span/middle shift 4.190924883 Hz, outer difference 0. These are weak spectral peak estimates, not measured drone velocities.

At weakest level in broad placements, primary C03-like (tolerant pass, strict fail, span >= observed): steady single 8/256, changing single 684/4096, two static 26/512, two handoff 342/4096, three static 24/512, three handoff 463/4096. Secondary outer alignment/middle magnitude: respectively 3,105,8,63,8,97. Steady comparable-recovered-strength subset has 50 cases, 5 primary and 2 secondary. Local steady primary 5/100, secondary 0. Uninjected gates 0/100 local, 0/256 broad. Strong steady levels each 0/256 primary. These dependent model/background counts are NOT source posterior odds, false-alarm probabilities or independent Bernoulli samples.

Full raw-power injections: all 30 modified ON scans / 10 triples completed. Full recomputed normalization/calibration versus fast conditional-normalization simulation maximum score discrepancy 0.0221749464, below fixed 0.05 guard; all 10 strict/tolerant decisions agree. 159 independent scalar responses max discrepancy 5.33e-15. Six native SHA/CRC/NPY verifications passed. Gaussian idealized deterministic power response; no self-noise, complex phase, detailed receiver/beam model. Equal power in normalized units, no flux/EIRP calibration.

Conclusion: single steady weak line can imitate this C03 pattern; changing single/multicomponent alternatives also compatible. No emitter-count, spacecraft, AI or artificial-source identification. Even several radio components could be produced by one device. Source remains unresolved. Next discriminant would be time-resolved simultaneous resolved components/reproducible tracks and frozen predictions in unused sensitive observations, not interpreting threshold jitter as motion.

Earlier unfinished Wow-guided continuation remains unfinished and separate; this simulation does not finish or cancel it. The following previous checkpoint is preserved in full.

--- Earlier checkpoint preserved ---

# Active C03 transmitter-model simulation — 4 November 2026

User authorizes simulation of steady/changing single transmitter and2/3component mixtures. Newfixed exploratory plan C03-model-simulation-plan-2026-11-04.md; workfolderc03-model-simulation-20261104. Restore sixoriginalOHcoarse7powers +C03audit evidence.53finiteemittingconfigurations across6families;3equal-total-power levels expressedas noiselesssteady scoreincrements2.8/5.6/11.2;100local+upto256broadmetadata placements;fixed-F1component simulationwith10fullraw-triplechecks(30scanruns),0.05scoreaccuracyguard. PrimaryquestionhowoftensingleweaklineproducesC03's jitter/tolerancepass; noemittercount/originposterior. Modelphases/periodsnotoptimized. No simulatedoutcomesyet. NativeinputLibraryIDs unchanged. Preserveallmetrics/profiles andcheckpointbatches. EarlierWow-guidedcontinuationremainsunfinishedasrecordedbelow, notcancelled.

--- Prior checkpoint preserved ---

# Continuity after workspace expiration — 4 November 2026

User requests developmental feedback on The Portents Before the Fall, attachmentlibfile_9f06ba45c9cc81918fe28791e0d0619f; this is a detour, not cancellation of Wow-guided search. At this request the prior wow-hydrogen-20261103 scratch folder is absent. Completion of earlier background jobs cannot be verified. Do not claim final reserved-search or extended-injection results. Restore durable files before resuming; no scientific input is missing universally merely because scratch expired.

Known durable additions since checkpoint42: native15libfile_8ac0145670448191b98553120b35d89c;native16libfile_9de522a4e9508191a9fd008caca7e980; Recovery-extension-2026-11-03.md libfile_3371758a4154819198f8548690108045. Native13/14 and discovery surfaces remain saved below. Native17/18 were observed extracted withhash/sourcechecks inprior execution, but no durable IDs confirmed; reacquire ifnotfound. Latestcode added optional recovery amplitudes4.8/9.6 afterfixed18; those extension outcomes are UNKNOWN. Original search.py/plan/evidence2 suffice to restore declared base experiment; extensionplanseparate.

Transcript-observed progress (recompute fromdurable native15/16/evidence before treating asfreshlyverified artifacts): all18base injections completed;ON-only componentON>=6,J>=3 recovery byamp .6/1.2/2.4 was0/3,0/3,1/3; bothON/OFF same0/3,0/3,1/3; uninjected0. A sharedinjectionpassing componentcuts demonstratescutaloneisnotlocalization. Zeroampbitwiseidentity passed.54independent injectionselectedON/OFFscalarchecks logged maxerror0. Firstreservedpair15/16 atfrozen nomineedurations/freq±5 gave H ON2.357235810,OFF1.291048935,J1.066186875;oldreceiverON.475665982,OFF.114433908,J.361232075;revisedreceiverON1.661602226,OFF−.706080634,J1.661602226. AllthreefailedON6/J3. Partialtable wasnotyetconfirmedsavedexternally. No finalpair17/18result or18sky-selectedscalarchecks confirmed. No signal/transmitter/AI-origin claim.

NEXT whenreturning: restore Wow-guided-evidence libfile_7e701db30ab4819193f353dfb0ddda02 (lastconfirmedv2), all4savednativefiles, frozencontinuationlibfile_12a691dc44f48191a16081677d569f21. Regeneratemissing nativeNPYs andbase scorecaches. Preservefrozen nominees and3branchinterpretations. Reacquire17/18ifnotdurable; complete followup/scalarchecks. Restore/recompute18base recoverycases, then complete explicitlypost-result4.8/9.6extensionseparately; do notretroactivelyrenameitpreregistered. SaveallnativeIDs/results andfinalreport beforedeclaringboundedpasscomplete. SourceHDF5localdecoder usespublicBitshuffleLZ4options, notpost-creationDCPL (doubleprefix issuefixed);9source-global-slice checks perinput remainrequired. Noexternalmessages/authentication/transmissions authorized ormade.

--- Prior checkpoint retained intact ---

# Wow-guided discovery complete; reserved continuation frozen

Frozenplanlibfile_4978c65fbb008191818fbb2ed55cecf9,evidencelibfile_7e701db30ab4819193f353dfb0ddda02, frozencontinuationlibfile_12a691dc44f48191a16081677d569f21. First2newnativeinputs verifiedand saved:ON13libfile_310f0f5b88188191b70023bd3018498e;OFF14libfile_8c68116fa3388191a636bc57460ceb86.18original-sourceHDF5slicechecks pass;2CRC/SHA/nativeNPYhashes recorded. DiscoveryNONEscreens. Nominees(frequencyHz/frame/durationintegrations):H1420407785.439856/comet/8;oldreceiver1420450885.7801557/receiver/24;revised1420722627.080977/receiver/16. J4.683903,3.859717,3.725167;ON4.683903,4.279962,3.725167. Peranchorcomparisonge8,68,85/100. FamilymaxJ4.683903,18/100>=it;conditionalrank19/101notglobalp. Fullprimary/controlwindowmaxsurfaces+argstarts saved143MB, completecalibrations andtrialdomain reconstructablefromnative/code. Scientificclaimlimitedtothese8.4Hzlineepisodetemplates. FreezeJSONSHA6f9fb3fcde262003895a99f31237802ad59234f9d91ed404813c9e3d0fbb00f5. Reserved15–18acquisition starts onlyAFTERfrozencontinuationdurablysaved; pendingfollowupatfrozenfreq+/-5andfrozenduration,allstarts,twopairsseparateandanypair. Noresultfromreservedpowersyet.18known-durationinjectionsrunning;first3completed. Newworkfolderwow-hydrogen-20261103. Resumeacquire.py missing15–18 (max2scanworkers),searchscore missing scans,followup,verify,recovery;nativeinputssavedperbatch. Noindependentepoch/sourceidentification/artificialityfinding.

--- Prior checkpoint ---

# Completed C03 hunt and Wow-guidance pass — 3 November 2026

No analysis or acquisition job remains running in this bounded pass. Report C03-hunt-and-Wow-guidance-2026-11-03.md; evidence libfile_2bf26e04a6148191b5cfa739c6eb7bb7. Currentfolder c03-hunt-20261103. Newreport Library ID will be in final save receipt.

C03: all156legacy scores reproduce<1e-12. Correctrest-gridspacing preserves originalpass. Exactper-frequency first-order paths on sharedhalf-nativegrid failall3ONgate atboth+/-5,+/-100Hz: T0ON3.0382,1.9760,2.8529; F1ON2.6485,2.1730,3.1125. Restore+/-one nativechannel per-scanmax: passboth(minON2.6975/2.6485). Thisis frequencyfreedom sensitivity, notsourceidentification. First-ordertrackmodel lacksfullclock/relativistic/channel uncertaintybudget. All100reusedlocalcomparisonwindows haveweakermargins,nonepass. 36scalarfull/halfscorechecks match<1e-12. Timingcalibrations/fullperintegration contributions preserved. ON17actualantenna trackingstillunresolved.

All18Gaussianpower injectionconfigurations complete underT0/F1,18x2results plusuninjectedcomparators. Persistentall-ONrecovery byamp .15/.30/.60: T0 0/3,0/3,1/3;F1 0/3,1/3,1/3. Middle-onlyinjectionsallfailpersistentgate; individualmiddlepair newlypassing vsuninjected T0 1/3,1/3,3/3;F1 0/3,1/3,2/3. F1oneplacementalreadyflaggedbeforeinjection; doNOTcountthat asrecovery. PowersinrawMADunitsnotflux/EIRP/surveycompleteness. Zeroampbitwiseidentityverified. No broadfaint-emitterexclusion.

All8GBTsourceheaderssuccessfullyread via boundedpublicranges, shapes/attrs onlyinterpreted. Nodeblc23covers1501.4648465–1688.9648438MHz;neighbors do notduplicateC03coverage. Sameobservationotherproducts:2861Hz/1.073742s and366211Hz/.000349525s cannotresolvefewHzC03orindependentlyconfirm. ImportantNEWPROSPECTIVELEAD:nodeblc24covers1313.9648465–1501.4648438MHz at2.793968Hz,6.084537s; exactsix0013–0018rawspec0000URLs savedin sources/prospective-GBT-hydrogen-urls.json. No blc24spectralvalues interpretedhere. Cansearchphysicalhydrogen andWow-inspiredintermittentepisodes afterfreezing finite detector,frames,tolerances,comparisons,injections/reserveddata. Samecadence newband is notnewobservingepoch. Parkes3epochrootindexeschildren savedbutnonewperfileParkescoverage/powersresolved; donotrepeatknown403sasuniversaldataabsence.

EarlierWowconcordancereadfromcurrentoriginalHTML, savedtext. Ehman6EQUJ5 isquantizedreceiverintensity withbeamcrossingprofile, notestablishedmessage;72s isnotuniversalburstperiod. Kipping/Gray2022 stochasticrepeaterssupports explicitdutycycle/observingwindowtests, notoriginclaim. Mendez2025arXiv2508.10657v1proposes1420.726+/-0.005MHzafterchannel-order/LOcorrection; carryversion/frame ratherthan silentlyreplace1420.4556. Loeb28Sep2025himselfreports~9degseparationin1977, notco-location;lighttraveltimeadjustmentnotindependentdatecoincidence. No newWowcodedsearchwasperformed. Humanunit/displayecho admissibleseparatehypothesiswithfrozencodebook/controlcost. ReportdetailsprimaryURLs. NoAIoperator-specificsignature,artificialdetectionorhumantransmitteridentified. Noexternalcontacts.

AllsixnativeNPZsCRC/SHA andrestoredNPYhashesmatchledger. Evidencecontainscode,completeinputs/ledgers,localprofiles,all18recoverycases/calibrations,scalarchecks,metadatareadranges+hashes,figure andreport; fullregenerablecache/nativepowers remainseparateexistingIDs ininputs/native-input-ledger.json. Previousoriginal13/ATAresultsretainedbelow.

--- Prior checkpoint preserved ---

# Active: targeted C03 hunt

User authorizes huntdownC03. New fixed plan C03-hunt-plan-2026-11-03.md: corrected shared-frequency trajectories versus legacytolerance; half-scan timing;18integrated Gaussian power injections; exactpublicmetadata search for unused matching-band observations. Priorcheckpointversion36 andoriginal13evidenceversion6restored. Six existing nativeNPYs hashchecked, immutableinputs reused. No new corrected detector or recovery resultyet. Save completedbatches. Main workingfolder c03-hunt-20261103.

--- Earlier checkpoint retained ---

# Completed original-thirteen normalization/source pass — 3 November 2026

This bounded pass is complete; no analysis job is pending. It uses the same already-examined six Green Bank scans. It supplies no independent observing-epoch confirmation and no artificial-source identification.

RESULTS:
- Four-way baseline/row-whitening experiment: T0=time median/no whitening13clusters;T1=time median/whitening13;F0=frequency baseline/no whitening6;F1=frequency baseline/whitening6. Original40controls reproduce: T0/T1mean3.75,max8,0>=13;F0mean3.4,F1mean3.425,max9,7>=6. Baseline choice drives13vs6. At originalpaths, C03alone passes allfour. Fsixareownpopulation: C03,near-C01differentpath+6.985Hz and4otherfrequencies, not6originalsurvivors.
- Dense60nearby trajectory probes: T0max15,T1max14atdrift error+0.125Hz/s@1667MHz;F0/F1max11. One of60reaches/exceeds13 underT. The +.125probe corresponds nearlystationaryreceiveddrifts+.0003..+.017Hz/s and a different15frequency population. All15are retained as D95-01..15, nonepassesF0/F1atitsselected±5Hzcoordinate. Neitherthis nor thecontrolcounts establishsourceor globalpvalue.
- C03nominal first-order rest1665.633776617MHz: all4normalizations pass; all100local comparisonwindows have weaker gate margins ineachmethod andnonepass. This is100reusedneighborhoods, not400independent tests, andcandidatewasalreadyselected. SmallestFmargin~.045abovegate. Sourceunresolved.
- Explicitpost-resultbackgroundcontrols: fixedreceiverandfixed-directionstationarybarycentricmodels testedunderall4normalizations. Counts:Tmethods3/3vscomet13;Fmethods6/10vscomet6. C03failsbothbackgroundmodels atitsfirst-coordinate±5Hzunderallmethods; wholebandbackground selections have no nearbyC03cluster. These are first-order contextmodels, not allpossibleinterference.
- Fixed-path F1failures: C01/C02OFFpowerrevealsknownsharedcomplex; C04–C08/C10–C13loseONsupport;C09losesONandfailsOFF. Noadditionalhumantransmitteridentified. GlobalFbaselineMAD~4.8–5.4%largeronON; mostmeanpathscorelossacrossC03–C13comesfromtrackedresidualchange, withsmallerMADeffect. Per-candidate sum/center/scale terms retained.
- Six-headergeometry: ON17scalarheader remains16.108arcminfromICRFpredictedtarget. It lies.542arcminfrom thetangent-planeOFF16header→ON17predictedtargetsegment,26.68%remainingdistancefromtargettowardpreviousOFF. Thisiscompatiblewith a first-header/slew snapshot, notactualtrackingproof. Actualantenna/GOdata remainneeded; noexternalcontactmade.
- Verification:6nativearchives CRC/SHA and6restoredNPYhashesmatch;156priorpathscores exact;6entireoriginalT0truevectorsbitwiseequal;312fixedpath componentreconstructions exact;48independentrawC03backgroundrescores exact;17localindexoptimizationsmatchfullgrid;78symmetricdecompositionsreconstruct tofloat precision. Originalreferencefunction preservedunchanged.

Report: https://chatgpt.com/library?file_id=libfile_89c05df6e8148191973d300f9d483b42&account_id=personal
Evidence: https://chatgpt.com/library?file_id=libfile_067ebefc4a248191b17bb5a879331d1e&account_id=personal
Fixed plan: https://chatgpt.com/library?file_id=libfile_f9380a0e02308191bea625654f65af19&account_id=personal

Currentworkfolder thirteen-normalization-20261103. Evidence includes complete404frame cluster/rowledgers,5252localprimary/controlrows, namedcompeting15, allmodelqueries/paths, sourcecrops/13figures, componenttimeseries andscripts. Sixnativepowers remainunder original LibraryIDs in inputs/native-input-ledger.json. All non-power dependencies now in inputs/; restore_native.py and the report provide standalone reproduction. Large deterministiccache files are omitted but regenerable. This completedpass does not claim a new full injection sensitivity curve or solve actualpointing.

PRIORITY GOING FORWARD: C03remains the best-tested original individual. Seek appropriatelysensitive unused observations, actualON17tracking and controlled recovery/background calibration before choosing a baseline's physical interpretation. Do not reclassify unknownfeatures as human merelybecause a threshold/model fails. Do nottreatsame-data robustness/localranks as independent confirmation. EarlierATAandnumerical1667passes remain distinct.

This section supersedes the running-status notes below; those are historical.


--- Earlier checkpoints retained ---

# Original13factorial counts complete; further audit active

T0/T1physicalcounts13;F0/F1counts6. Baseline choice drives difference. Dense nearby-frame maximum15underT0, at+0.125Hz/s drift error1667MHz; actual13isnot unique maximum. All4x101count/cluster ledgers saved; original156pathscores exact,6entiretrue scorevectors bitwiseequal. Candidate decomposition/local-ranks and explicit post-result background-motion control stillrunning. Evidence libfile_067ebefc4a248191b17bb5a879331d1e. Do not infer solvedsource or globalpvalue.

# Normalization continuation: inputs verified and first8batches complete

Fixed plan libfile_f9380a0e02308191bea625654f65af19; current evidence libfile_067ebefc4a248191b17bb5a879331d1e. Completed calibration and exact-reference checks for scans0013/0015 under4methods saved. No aggregate result yet; remaining scan/method batches running. Native inputs already durably saved under original IDs; no new sky data claimed.

# Active: explain the original thirteen

User authorized the proposed normalization/source/pointing continuation. New plan PLAN.md fixes a2×2baseline/row-whitening experiment, original40controls plus60dense nearby-acceleration specificity probes, and candidate-level local comparisons. No new scores yet. Six saved full-coarse native inputs and three prior evidence packages restored; current branch thirteen-normalization-20261103. Preserve all prior results and source-unknown distinctions. Next: verify/restore nativeNPYs, run factorial scores with completed-batch saves, analyze candidate paths/local controls, inspect available pointing provenance and write report.

--- Prior checkpoint retained ---

# Completed numerical-anchor pass — 3 November 2026

All six paired ATA July3 native extracts saved; all three discovery and all three reserved continuation observations scored. No discovery or continuation screening flags. No work remains pending in this bounded pass.

Discovery strict ±5Hz best joint scores and matched-comparison counts equal/higher: OH1667-rest 2.150674,90/100;1667MHz-rest 2.604677,64/100;1667MHz-receiver 2.998742,18/100. All three broad maxima were frozen before reserved powers. Continuation ±5Hz at frozen centers with fixed duration/template: OH nominee2.311207,67/100; emitter1667 nominee2.745526,12/100; receiver1667 nominee2.632525,32/100. No all-three-scan persistence requirement. All nominees were carriers; three-tone10/100/1000Hz patterns were also searched in discovery.

16 ordinary-HDF5 source slices bitwise equal; all6nativefiles CRC/SHA pass with zero masks;12selected-max scalar checks reproduce scores within8.9e-16. All18fixed-cell injection diagnostics complete. Injections show monotonic component response but mostly remain below screen at4raw-MAD, so no broad faint-signal exclusion. The detector requires target/reference excess and does not test equally shared all-beam messages, arbitrary modulation, phase, polarization, subintegration timing or general OH profiles. Rest-frequency tests use a first-order model, not a full Doppler/clock uncertainty budget. A failed screen does not identify a human source or settle artificiality.

Report: https://chatgpt.com/library?file_id=libfile_7e1a6b1f31348191b2aba036b407ff31&account_id=personal
Evidence: https://chatgpt.com/library?file_id=libfile_9ce39f0cc9c48191ac2ca1cf7248237e&account_id=personal
Plan: https://chatgpt.com/library?file_id=libfile_e46429c156088191bce3cfc6183b1aa8&account_id=personal
Exact native IDs, filenames and source hashes are in saved-ids.json and the report. Core scripts: search.py, injections.py, check_math.py, discovery/acquire_ata.py, holdout/acquire_ata.py. Full primary surfaces and complete comparison/segment-max ledgers in each directory's all-search-arrays.npz.

This section supersedes the earlier numerical-search progress notes below. Earlier work is preserved as historical context. Prior original13GBT reconstruction, earlierC03/new-bandATA tests and pointing uncertainties remain distinct, not overwritten by this numerical test. No semantic content or inference specifically about AI operators was established.


---

# Numerical discovery complete; continuation frozen

All three new paired focal extracts saved, all18fixed injections and8source checks complete. No discovery screening flags. frozen-nominees.json and Frozen-1667-continuation-2026-11-03.md specify three prospective continuation tests. No continuation focal powers inspected yet. Evidence contains all primary surfaces and matched comparison/segment maxima.

# Numerical-anchor search progress — 3 November 2026

First new discovery paired native extract completed, CRC/SHA verified and saved as libfile_20a39cefdec881919b7b1b9e1d2a729a. All masks zero. First-scan full search scored and partial ledger saved; these are incomplete exploratory results, not detections. Remaining two discovery pairs are acquiring. Source decoding spot-check and 18 fixed-cell injection diagnostics are running. No heldout focal powers acquired yet. Active numerical plan is libfile_e46429c156088191bce3cfc6183b1aa8; executable evidence libfile_9ce39f0cc9c48191ac2ca1cf7248237e.

One transfer interruption resumed from SHA-checked compressed chunks; the ordinary public Range probe succeeded. No authenticated access, contact or policy escalation.

## Active newsearch — numerical1667anchors and intermittent patterns

User changesprior: assume numericalsignificance; examine1667closely. Frozen plan Numerical-1667-search-plan-2026-11-03.md and numeric-search-config.json before new selected powers. Threeanchors: physicalOH1667.35903MHzcometrest; literal1667MHzcometrest; literal1667MHzfixedreceiverframe. Waveforms carrier and3toothlocalpeakpatterns spacing10/100/1000Hz. Allwithin-scansegments1/2/4/8/16/19samples, no all3scanoccupancyrequirement andnogapconcatenation. Matched100frequencycenters+/-200Hz*k eachmaximizeoveridenticalfullfamily/time/frequencytrials. Jointtargetlocalpeak andtarget-minusreference score; rawpositivegates. Screens>=3empiricalMAD andaboveallcomparisons; descriptiveconditionalranks, notglobalpvalues.

Newfocalpowers: first3July3LoA.C1504pairs chunks182/183bothbeams/masks. Holdoutnext3pairsindices3–5reserved; oldinstrumentedtestsusedotherfrequencychunksinthosepairs. Beforeholdoutpowersfreezeonebest+/-100Hznomineeperanchor'sfrequency/frame/template/duration; followat+/-5Hzanywithin-scanstartofsameL innew3pairs. Sourceandmeaningremainunknownunlessfurtherindependentevidence. Initialexactplan/config savedwiththischeckpoint. Priorcompletedpersistent-tonebatchnotchanged.

Next: acquire/savenativepairs; sourcebitwisechecks; execute fixedfamily completecontrols anddiagnosticcomponentinjections; freezeall3nomineesandtestheldoutpowers; saveallpartialresultsatboundedbatches.

## LATEST COMPLETED BATCH — new-band search and allfourheldouttests complete

All acquisition and analysis jobs in thisbatch ended. No backgroundsearch isrunning. Main newreport:3I-ATLAS-new-band-search-2026-11-03.md. Completeevidence libfile_61cc8ebb901c81918cc2de8efa867237 (latestfinalversion). PriorC03report libfile_44f436fca71481918d3de5e73564797b and original13directreport remainpreserved. Currentnewworkdirectory signal-continuation-20261103; restorefromsavedfiles iftemporaryworkspaceexpires.

MEASUREDRESULTS:
1. SixGBTfrequency-baseline trueframeclusterlocations tested innewATAJuly3scans07:50:48,07:57:32,08:04:16UTC. All6x2windows(+/-5/100Hz)x2normalizations=24combinations give0flags. Notatestofall13originalGBTlocations. LowerATA sensitivity/differentepoch meansnofaintDecember/intermittentexclusion. Sourceunknown.
2. Supplementalnewfullbandsearch:781966commonfrequencygridpoints across3sourcechunks, physicalframe4clusters vs40comparisonframesmean4.475,SD3.07398,max13,22/40>=4. Conditionalrank23/41=.56098;notglobalpvalue. Noaggregateexcess. Allfournewmaxima selectedunderpredeclaredtop5cap, frequenciesfrozenbeforeheldoutpowers.
3. Heldoutsame-night3newpairs08:11:01,08:17:46,08:24:30UTC. All4failfixed+/-5Hzconstantrest test. Bestminimumacross3targets, byfullID:ATA-BAND-F00-0001=-.322679,F00-0002=-.060686,F00-0003=-.098724,F00-0004=.800147. Allbelow2.5required;targetstrengthfailsirrespectiveofreferenceveto. Eligiblecomparisoncounts100,100,100,69;geactual65,51,66,7respectively. All369eligiblecomparisons0flags. Lastfeature's31excludedcomparisonsaremetadataedgeexclusions,notRFIcuts. Noemitteridentified;intermittency/othermodulationunexcluded.
4. 24ordinaryHDFsource-slicechecks(12discoveryfirstpair,12holdoutfirstpair)bitwiseequal over3chunks,bothbeams,powers/masks. All6newpairednativearchiveshashverifiedandmaskszero. 24discoverymaxima-scorecalculationsmatchseparatefixedfrequencycodewithzeroerror. Allscorecubes,controls,perintegrationtables,41frameclusters,sourcehashes,plansandcodearepreserved.
5. Publicsourceclarifiesheaderchain:currentGBTj2000_major/minor ->RA_STR/DEC_STR ->firstinputrawspecheadercopiedtoallproducts. Exactdeployedbuild/configurationandactualantenna historynotobtained. GBTscan17stillunresolved;doNOTclaimprovedmispointing. PublicscheduleprogrammeGBT25B-999. PublicNRAOquotedGBTfiltervalidatedwith8797unfilteredrecords;dateintervalquery0GBTrecords. BLindex1296HDFlinks/norawheaderFITSloglinks;operatorlogsrouteauthwall. GBT-pointing-evidence-needed.mdspecifiesminimalpacket;notmessagedtoanyone.

Durable newnativearchives (eachpairedpowers+masks,three0.5MHzchunks):
Discovery0 libfile_319b7ede4dac8191acbfe60758e0bc03
Discovery1 libfile_c24907423ce48191b221c51b27bade31
Discovery2 libfile_950e3d84e5d081918ab3f5ea722555b4
Heldout0 libfile_178d43182ad0819188c521f2a190d0e9
Heldout1 libfile_4c2a7b38abec8191b42c0372ca6370cd
Heldout2 libfile_005238e5d5b88191b05690e8766249ce
Exacthashes/sourceURLs in native-input-ledger.json andindividualmanifests. Onecancellednetworkapprovalcallbackinterruptedfirstheldoutdownload;regular80bytepublicRangeprobe succeeded, then acquisitionresumedwithSHAverifiedchunkcache. Noauth/escalationused. Completedpowers/results survivedallpartialcheckpoints. Cachedcompressedsourcechunks aretransientandredundant,excludedfromevidence.

NEXTSUBSTANTIVEWORK: thisboundedpersistentconstant-tonebatch iscomplete. Do notrecastit asnoallpossiblesignal or ashumanidentification. A differentintermittent/relationalhypothesisneeds a declared observable,correct handlingofrealscangaps, trialinventory/injections andunused-observationprediction. Originalauthors'human-source-rejectionauditstillneedsactualoriginalexamplepowers/fullrejectionledger; keepourmaximaIDs distinctfromtheir211cases. ActualGBTantenna/GO/rawheadertime series stillneededforpointing. User'sfiveconditionsremainhypotheticalandnotamplitude-only. Noartificialoriginorsemanticmessageidentified.

## Four-candidate continuation: two heldoutnativepairs complete

Heldoutscan0 savedlibfile_178d43182ad0819188c521f2a190d0e9. Heldoutscan1nowcomplete withzero masks, CRC/hashpass:ATA-band-holdout-powers-scan1-2026-11-03.npz,102616588bytes,SHA25605d618381b966bb86f3d494e26aae3e766bc9cf3283a30cede6fbbaa8007d23a; being savedwiththischeckpoint. Thirdpairacquiring withchecksumverifiedper-chunkcache. Noheldoutscorecomputeduntilall3inputscomplete. Lastconfirmedfullevidenceversion4containsallcompleteddiscovery/sixlocation/broadframe/morphology/mathematicalvalidationandfirstholdoutmetadata; nextfinalpackagewilladdcompletedholdouttables. No newsourceclassification.

## Four-candidate continuation: first nativepair complete after transfer restart

Firstheldoutpaired1.5MHzcutout completed withzero nonzero masks andCRC/SHA256pass:ATA-band-holdout-powers-scan0-2026-11-03.npz,102616291bytes,SHA256c2b3bf4216c5ce7c3bb4621cd2b07936f6c0e9954491babfdc7d70a536825f0f. Being savedwiththischeckpoint; remaining2pairsacquiring. Earlieracquisitionprocessendedwhenanetworkapprovalcallbackwascancelled;80bytepublic-rangeprobe succeeded, so resumedregularpublicreadwithper-chunkSHA256cache. Noescalation/authenticationorcredentialsused. Cacheisaconnectionrestartoptimizationonly, numericalmethodunchanged. analyze_holdout.pywaitsforcompleted3inputs; noholdoutscoresyet. Frozenplanlibfile_7f0c737914948191919fadeea98fc664.

Directfixed-frequencymathcrosscheckofall4newmaximax6beams=24scores nowdone: allmatchbroadsearchscores withexactzeroerror. Sourceplotsandperintegrationcontributionssaved; top2positivecontributions span24–41%ineachtarget. Noemitteridentified. GBT-pointing-evidence-needed.md specifiesprecisetimewindowandcolumns; notsenttoanyone. Neitherrepeatedscalarheadersnorpublicsourcecode substitute for actualantenna history.

## Bounded full-band search completed; four new maxima frozen for continuation

All41framescomplete. Physicalframe4clusters vsfalsemean4.475,SD3.07398,max13,22/40>=4,conditionalplusonerank23/41=.56098. Noaggregateexcess. Commonmetadatafrequencygrid781966points across180–182storagechunks, identicalcountedcoverage forall41frames. Fourtrueclusters IDsATA-BAND-F00-0001..0004, rankedbymin-targetscore; allfourfrozenin band-holdout/targets.json. BestrestHz inrankingorder:1665737025.9742508,1666484637.8055997,1665766813.6614635,1665646564.467809. Discoverymin-targetscores2.8971,2.6806,2.6268,2.5286. Sourcesunknown, notcandidateconfirmed orhumanidentified.

Nextfixed3July3scanpairs indices9–11:29461_38726318,29866_38751037,30270_38775695. PlanATA-band-candidates-holdout-plan-2026-11-03.mdsavedbeforethosepowersread. Fixedbestfrequencies +/-5Hz, frequencybaseline1024,per0.5MHzcalibration, same3target>=2.5/ref<2, matched100frequencycomparisoncenters subjecttomodel/metadata-onlycoverageeligibility. Allfourreportedwithoutfrequency/driftrescue. Acquirefull3chunksforbothbeamseachpair, masksretained. Candidate nearstorageedge meanssomecomparisonsineligible; do notreport100aseligibleblindly. Actualscientificstatusawaitsnewdata.

AllsixfixedGBTfrequencyfollowupresultsandfirst3newnativepairs saved: scan0libfile_319b7ede4dac8191acbfe60758e0bc03,scan1libfile_c24907423ce48191b221c51b27bade31,scan2libfile_950e3d84e5d081918ab3f5ea722555b4. Evidencecurrent libfile_61cc8ebb901c81918cc2de8efa867237 version2beforethissave; allfull-bandresults/code andtrueframefrequency-scorecubes now included in nextversion. Nativefilehashes remain in eachsource manifest.

## Six-location batch complete; bounded new-band search running

All3newpaired1.5MHzcutouts acquired, CRC/SHA256verified, masksallzero. Firstnativepair savedlibfile_319b7ede4dac8191acbfe60758e0bc03; nexttwo being saved withthischeckpoint. TwelveordinaryHDFslices across3chunks/powers/masks/bothbeams matchbitwise. Fixedall6targets x2normalizations x2windows complete: noflags in anytargetwindow. Scores, matchedcomparisoncubes, calibration andpaths in six-followup/analysis. No new human-source classifications follow from thesenulls. LowerATA sensitivity/differentepoch limitinference.

Frozenfull-band newcandidate search running as six-followup/search_band.py; all41framecounts andclusterledgers persist aftereachcompletedframe in six-followup/broad-search/. Same full-band frequencycoverage acrossallframes determined bymetadata. User's latest 'Continue thischat' continues thisauthorizedtask. Iftrueframe clusters exist, freeze top5bestfrequencies and acquirepredeclarednext3scansbeforelooking;otherwiseboundednullcomplete. Do notassume processes survive a timeout; checkcompletedjsonoutputs andrerununfinishedbatchesifneeded.

Tracking investigation: publicNRAOAPI correctGBTqueryroutevalidated against8797unfilteredGBTrecords; requested2025-12-18/19intervalreturns0GBTrecords. Thisis a testedquery result, notabsenceofobservations or recordsatGBO. SchedulematchesGBT25B-999. BLrootcontains1296HDFproductsandnoraw/header/FITS/loglinks. Noactualtracking obtained. Publiccode shows j2000_major/minor ->RA_STR/DEC_STR ->firstinputheadercopiedtoallrawspecproducts; exactdeployedbuildunverified. Source provenance/redacted snapshotretained.

## Additional frozen search — new candidates in the same new band

Before inspecting new six-location scores or newband patterns, specified Broad-ATA-search-plan-2026-11-03.md: full retained threechunk commonmetadata coverage, one-nativerestgrid, frequencybaselineonly, same all3target2.5/ref2gate,10Hzclusters, top5byminimumtargetscore, matching40falseaccelerations seed11. Commoncoverageintersection computed fromephemeris/metadataover41frames. Conditionalranknotglobalpvalue. Anytruecluster gets frozenbestfrequency +/-5Hz and next3July3pairs indices9–11 beforepowers. This supplements ratherthanalters six-locationfollowup and adds disclosedselectiontrials. Newpowers alreadyacquiring but no spectralpatterns/scores examined at thissupplement's specification.

## Six-candidate continuation partial checkpoint — first new nativepair complete

Firstpaired1.5MHzATAcutout (nextscanafterprevioussix) acquired,19integrations/beam, zero nonzero masks, CRC/hashverified:GBT-FB-six-ATA-powers-scan0-2026-11-03.npz,102590346bytes,SHA256c33e0cb8abb899b501bd4ac8b28713095e06771682b0b9627bed5a37104caf9f. IndependentordinaryHDFsourcechecks12slices across3chunks,powers/masks,bothbeams, firsttarget/lastreference integration allbitwiseequal. Remainingtwo pairs acquiring; fixedallsixscoringawaitscompleteinputs. Planlibfile_b9fd807273e48191b47e0e89fb580790; newevidence libfile_61cc8ebb901c81918cc2de8efa867237.

PublicGBTindex1296HDFproducts,no raw/header/FITS/log links. Publicoperatorlogsroute sign-inwall. NRAOmetadataqueryrouteworking; date-onlyreturnsrecordsbutquotedGBTdatefilterreturnszero, unfilteredGBTcontrolpending; do notconflatewithnoobservationsorGBOholdingnodata. Rawsourcecodechain clarifies scalarheaders: hpguppi statusloop reads j2000_major/minor thenRA_STR/DEC_STR;rawspec copies firstinputheader intoallproducts. Exactexecutedbuild andactualantenna history unverified. Do notclaim observedtelescopeofftarget. Sourceprovenancepin/hashes saved; connectionparameters inpublicsource snapshotredactedandnotused.

## Active continuation — six GBT alternate-detector locations,3November2026

Current authorized task: continue searching. Prior completed evidence restored from libfile_30a7cba244288191b5634a465f7e5a4f version3; native files are saved separately, not assumed to remain local. Prior checkpoint version20 read in full. New frozen plan: Six-candidate-ATA-plan-2026-11-03.md and targets.json, allsix alternate GBT clusters, nextthree previouslyunexaminedJuly3LoA.C1504pairs, three sourcechunks180–182, bothbeams/masks. Fixed +/-5/100Hz windows, selectingfrequencybaseline and secondarytimemedian, per0.5MHzcalibration and100matchedcomparisonsperlocation. No new powers examined at this checkpoint. Source unknown unless evidence identifies it. PreservepriorC03null and normalization-sensitive13vs6results.

GBTtrackingbranch: publicsupportlink to operatorlogs redirects to a sign-inwall; actualtrackingdata notobtained. Publicschedule andNRAOportalHTML accessible; furthermetadata/codeprovenancecheck inprogress. No person-directedcontact or credentials used. Neverreplace actualtracking with repeatedscalarheaders.

Next: acquire nativepairs with bounded verifiedHTTP ranges; run fixedall6scores/comparisons; savepartialpowers/results aftereachbatch. Anyflag requires a separatelyfrozen continuation on next3scans.

## LATEST COMPLETED BATCH — 3 November 2026 — supersedes running-status notes below

Completed C03 independent-epoch ATA follow-up, a distinct ATA-OFFSET-01 heldout same-night continuation, and the missing GBT alternate-normalization40falseframe comparison. All jobs ended; no need to assume a still-running process.

Main report: 3I-ATLAS-C03-followup-2026-11-03.md. Evidence: current version of libfile_30a7cba244288191b5634a465f7e5a4f, C03-followup-evidence-2026-11-03.zip. Raw sixpairednativecutouts are independently saved; exactids/hashes in native-cutout-records.json and report. Previous direct original13report remains libfile_ec087222fc5c8191a477c4289e631591; original13nativeGBTinputs remain saved separately.

MEASURED RESULTS:
1. C03 rest1665633776.617Hz:3newJuly3pairedscans, noflags +/-5 or100Hz under either detector. Primary best targetminimum -0.29696 strict,1.07009 wide. LowerATA sensitivity and different epoch prevent exclusion of a faint/intermittentDecember source.
2. ATA-OFFSET-01 was selected in alternate comparison-window powers at rest1665614737.5230594Hz, targets2.8044,2.9953,3.0396. It is NOT C03 and NOT establishedRFI. Its exactfrequency and +/-5Hz continuation plan were frozen before reading next3scans. Those scans have noflag in either normalization; selecting-detector exactscores -0.65729,-1.72716,-0.46406. Bestminimum overwindow -0.89643,96/100matchedcomparisons atleasthigh. Persistenttone case weakened; source remainsunknown.
3. GBT alternatefrequencybaseline:6clusters, falseframesmean3.425,SD2.119994,max9,7/40>=6, conditionalplusonerank8/41. Nativehashes verified, normalizationcachebitwisematches, all78selectedbin alternatescores matchwithzeroerror. Sixtrueclusters reproduceoldcount. These are alternate detector's own6clusters, NOT6survivors oforiginal13. At originalselectedbins onlyC03passesalternateON/OFF. Originaltime-median13vsmean3.75,max8,0/40>=13 remains unchanged. Overallaggregateexcessnormalization-sensitive; no transmitter identified by thiscomparison. Perframeclusters/counts and updatedoriginal13ledger saved.
4. GBTscan17header discrepancy16.108arcminICRF/9.827apparent repeatedacross3products. Actual settledpointing notobtained; doNOTclaimprovenmispointing. Parkesrootaccessible; testedblc00/blc07children403. NoParkespowersread. MeerKATthresholdedlists notsubstitutedforpowers.
5. ATAall12inputbeams maskszero;6pairednativefilesCRC/hashpass;8normalHDFslices offirstpairpowers/masksbitwiseequal. Injectionfinalrecoveriespersistent0/3,2/3,3/3 at0.3/0.6/1MAD;middleonly0/9. Fixes tonumericalrecoverybookkeeping didnotchangeastronomicalscores.

NEXT SUBSTANTIVE WORK: resolve actual GBTscan17tracking versusheadersemantics; obtain source-evidence ledger for surveyrejectedrealfeatures, preserving ours versus authors' IDs. For originalcandidate pool, specify an independent empiricalbackground/sensitivitycheck before further reinterpretation. For intermittent/modulated hypothesis, freeze observable relation and heldoutprediction instead of expanding passed/failedwindows after inspection. Keep user's fiveconditionshypothetical, not amplitude-only; no artificialorigin/message established.

Reproduce current ATA results with acquire_ata.py/analyze_ata.py and offset-holdout counterparts. gbt_robust_controls.py reads prior original13nativefiles/ephemeris; itslarge deterministic scorecaches are omittedfromevidence but checksums retained. Allmethodplans, code, metadata, scores, controls, perintegrationtables andfigures are included.

## Current bounded continuation — new powers acquired

ATA-OFFSET-01 all three new same-night paired cutouts acquired with zero nonzero masks; CRC/hash checks pass. Holdout scoring running (offset-holdout/analyze_holdout.py). These three native pairs are being saved in this batch. Do not infer results before reading actual summary.

Also completing a previously missing direct GBT check: matching40false-frame counts under the fixed alternate frequency-baseline normalization. Frozen parameters in GBT-robustness-control-plan.md. Code gbt_robust_controls.py computes all41frames on six already-persistent fullcoarse inputs, bitwise checks normalized caches and matches all78prior selected-bin scores. Large deterministic score caches are transient; persist final frame/cluster tables, math validation and code. Keep this same-data robustness result separate from original13excess and independent ATAepoch. Process may need rerunning on interruption; completed original work remains saved.

Injection bookkeeping adds a numerical boundary guard under1microHz so a one-native-channel equality is not rejected through subtraction at1.66GHz. Final persistent injected recoveries0/3,2/3,3/3 at amplitude0.3,0.6,1.0; middle-only0/9. Astronomical scoring unchanged. Source spotvalidation8slices allbitwiseequal saved in independent-ata-hdf5-validation.json.

## 3 November — C03 July follow-up completed; ATA-OFFSET-01 continuation queued

All three paired native0.5MHz chunks acquired, SHA256 and CRC verified, masks allzero. C03 has no flags in either frozen +/-5Hz or +/-100Hz window under either normalization. Time-median best minimum across3targets: -0.29696 strict,1.07009 wider. Offset controls give0/100 flags in either primary window. These are conditional, lower-sensitivity July results; they do not refute the original December13cluster excess or identify its sources.

Alternate frequency-baseline normalization flags one comparison-window coordinate, designated ATA-OFFSET-01, rest1665614737.5230594Hz. Target scores2.8044,2.9953,3.0396; reference0.8212,-0.3162,-1.4341; primary time-median targets1.6400,1.7226,1.6032. No clear visible track. Source unknown. Do not label a false positive merely because selected from a comparison window. Frozen next-three-scan plan in offset-holdout/ATA-OFFSET-01-holdout-plan-2026-11-03.md; new powers not yet read at this checkpoint.

Injection recovery bookkeeping now tests any acceptable gridpoint within one native channel of the injected location, instead of only the highest target-minimum coordinate. Astronomical scores unchanged. In18idealized cases, persistent amplitudes0.3,0.6,1.0 recover0/3,2/3,3/3 respectively; middle-only0/9 by the required3scan persistence rule. Not a physical sensitivity curve.

Coordinate branch: ON17 header discrepancy16.108arcmin relative to ICRF,9.827arcmin relative to apparent. Same header appears in3frequency/resolution products, so not a single-export transcription; no actual encoder/GO tracking logs found. Do not claim proven mispointing. Parkes Oct5root opens; tested published child blc00/blc07 return403. MeerKATlists exist but are thresholded hit lists; no new powers there.

New native pairs1/2 saved successfully as libfile_d97acc5464f88191b65fe1970f0160e6 and libfile_0c4b2b1b57a08191ae11616aba261326. Current evidence version1 confirmed. Pair0 already libfile_1e5ab075742c8191b90a791dc82f029c. Next: finish source spotvalidation, execute frozen heldout plan, then write bounded report and persist batch.

# C03new-power batch1: first ATApair complete

New LoA.C1504chunk180 for firstJuly3scan is acquired,19samples perbeam,0nonzero masks, native1665.75–1666.25MHz region. C03first-orderprediction~1665.9195MHz, constantrest1665633776.617Hz, strict±5Hz/secondary±100Hz windows remain frozen. Firstpair file C03-ATA-new-powers-scan0-2026-11-03.npz,34216817bytes,SHA256c6c2efcb705156c804a697fee2cc34c50a6a2cb8bc8b35f46a063933829a1f90. It is being saved with this checkpoint. Two morepairs acquiring; no new score result yet. Metadataprefetch was expanded to bothcomplete data/mask indexes because HDF5chunk-info lookup walks them; all finalchunk offsets remain determined by HDF5.

ParkesOctober5rootindexopens but its published blc07 andblc00childdirectories return403from thisenvironment; do not generalize to allfiles. NoPKSpowersread. GBTframe check now compares bothJPLICRFandapparentcoordinates: nominalON17header differs16.108arcmin fromICRF and9.827arcmin fromapparent; simplyswitching to apparent does not reconcileit. Actualtracking/frame/epoch metadata remain unverified, so no off-target conclusion.

Next: finishpairedpowers, validate source-read spotcheck, score frozenC03and matchedcontrols, run declaredpower-domain injections, persistcompletedoutputs. Original13excess remains aseparatepreserved result.

# Active continuation — C03 independent observations, 3 November2026

Authorized: continue the search. We are testing fixed C03 in previously unexamined ATAJuly3 spectral powers and examining a ParkesOctober5 follow-up route. Also audit GBT0017headerframe/pointing semantics. No new-power result exists yet. The earlier original-thirteen result remains13vs3.75mean/max8controls, not refuted by a narrow-window null.

# C03 independent-observation follow-up plan

3 November 2026. Written before reading the new ATA or Parkes spectral powers.
This is an internal dated plan, not a public preregistration.

## Fixed target and scope
Primary target: C03, nominal first-order rest frequency F0=1665633776.617 Hz from the supplied GBT export. This is a coordinate on a2.79Hz grid, not a physical sub-hertz measurement. Model: emitted first-order rest frequency constant across epochs, received f(t)=F*(1-v_radial(t)/c), with JPL Horizons observer-site radial velocity at integration centers. This is a finite baseline hypothesis; intrinsic chirps, intermittency and arbitrary semantic organization are not excluded by its failure.

Primary new power batch: first three chronological July3ATA scan directories in the already saved published-session index:
fil_60859_24992_38453552_JPLH_ATLAS_0001
fil_60859_25484_38483581_JPLH_ATLAS_0001
fil_60859_25888_38508239_JPLH_ATLAS_0001
Use both simultaneous beams of LoA.C1504, targetbeam0/referencebeam1, and original19integrations at16.777216s and1.9073486Hz resolution. Those observation times were used at other frequencies in earlier work, but the C03-frequency powers have not been inspected.

## Frozen target windows and controls
- Strict coordinate test: rest F0±5Hz, half-native-channel grid.
- Secondary model-tolerance window: rest F0±100Hz on the same grid. This permits a finite additional offset; it is not a quantified complete relativistic/ephemeris uncertainty budget and cannot cover arbitrary transmitter modulation.
- Retain the entire0.5MHzcompressed source chunk containing the predicted frequency, all times and beams. If an edge prevents coverage, acquire adjacent chunk(s) based on metadata/ephemeris alone before viewing powers.
- One hundred matched control centers: F0±k*1000Hz, k=1..50, using the same window widths, grid, time coverage, detector and beam requirements. Discard an uncovered control only by metadata before powers.
- First-order absolute model is explicit; higher-order Doppler/clock effects can shift apparent rest frequency across months. Record both strict and100Hz-window results without enlarging either after inspection.
- Preserve raw powers and masks. A shared feature remains in the ledger as unlocalized; it does not become an identified human emitter without evidence.

## Detector and interpretation
Primary detector matches the original C03 family: per-channel time-median division minus1,3native-bin boxcar, physical-track power sum, per-scan median/MAD calibration over the full extracted slab. Use exact rest-frequency coordinates for candidate paths, no circular-wrap valid-power assumptions. Derive calibration with fixed-band shifts, and record approximation/edge treatment.
Frequency-baseline normalization with1024channel median blocks is a planned sensitivity check; it does not replace the primary result.

A candidate flag requires a single consistent frequency with score>=2.5in all3target scans and<2in all3reference scans. This is a follow-up flag, not a globally calibrated discovery threshold. Record the strongest target-minimum score and off-beam scores even if no flag survives. Apply the identical procedure to the matched frequency controls. Retain both primary and secondary frequency-window results.
An alternate-normalization pass at the same coordinate is a robustness check, not independent confirmation. The new observing epoch/instrument is independent of the GBT selection; the statistical methods are still exploratory.

Power-domain injections: amplitudes0.3,0.6,1.0in local per-sample MAD units, placements F0-3,F0,F0+3Hz, both all3targetscans and middle-target-scan-only occupancy. Add before normalization, no addition to reference beam. These are idealized native-bin powers, not a voltage/channel-response simulation or physical flux calibration. Do not extrapolate18placements/occupancies into a complete sensitivity bound.

## Other branches
Inspect Parkes October5public metadata to locate the C03 band and its6scan cadence; if accessible, freeze a second instrument-specific plan before powers. Its lower published sensitivity must remain explicit.
Inspect actual public metadata for GBTscan0017. Check JPL astrometric versus apparent coordinates, GBTheader provenance, coordinateframe/epoch and catalog-versus-encoder semantics. A numericalheader discrepancy is not proof of telescope mispointing. No person-directed contact is authorized here.
MeerKAThit-list availability can be mapped, but do not silently substitute thresholded hit tables for a subthreshold power search.

## Durable work batches
Save plan/checkpoint before acquisition. After acquisition save raw cutouts, source metadata/range hashes and ephemeris. After scoring save every candidate/control result and update checkpoint. All conclusions remain separate from the exact13clusterreproduction (which remains13vscontrolmean3.75,max8under its original rules).


--- Historical checkpoint ---

# Latest completed state — original13directaudit,3November2026

The original13coincidenceclusters and all78roundedscanvalues reproduce on public full-coarse7powers. All6optimizedtrue-framevectors match the unchanged supplied function bitwise. The packet's40seed11falseaccelerationcontrols reproduce mean3.75,SD2.046338,max8,none>=13. The finite plus-one rank1/41is not a global p-value. Keep this as a reproducible exploratorycount excess, not an identified transmission or a demonstrated fluctuation.

Important scope correction: all13span2.93MHz, none in our prior±5kHzOHwindow. That narrow-window result cannot reject them. The earlier report libfile_d1b9045bdfe48191b47dbafa2c5130a2 now has a scope addendum (version1). New report: GBT-OH13-direct-audit-2026-11-03.md. New evidence: libfile_6b47f6362dcc8191b56b0921522df356. All6complete full-channel native archives are separately saved; IDs and hashes in native-input-ledger.json.

Matched-control sensitivities: corrected reference rest-gridspacing gives12vsmean3.625,max9; carrier±10Hztrajectoryveto12vsmean3.725,max8; broader±60Hzveto11vsmean3.725,max8. No control reachestruecount in each construction. Actual nominalONroletriple has13; other19triples0–6, descriptive only because roles/time/sky/noise are not exchangeable.

C02directly crosses common fixed line complex near1665.61512MHz, visibleallON/OFF. About91%of its positive0013contribution is near measured localpeaks; it is the only strictON>=3survivor. C01does not cross centralcitedcarrier (nearestselectedpath27.5Hz), but occupies nearbylinecomb;52%ofpositive0015contribution near measuredpeaks. Do not conflate incorrectliteralcarrier-crossingwording with no contamination: localcomplex evidence is real. Four prominentpeaksshow~60.35Hzspacing, descriptive, emitterunidentified. C03–C13remainunclassified; no demonstratedhumanoriginforeach.

C03priority: nominal first-order rest1665633776.617Hz (2.79Hzgrid; no sub-hertz physicalaccuracy claimed). Underalternatefrequencybaselinenormalization,ONscores2.546,2.820,2.966 andOFF1.623,1.069,0.168. Removinglargesttwo path samples leavesON2.990,2.780,2.524. These are same-data robustness, not independent confirmation. Wholetruepipeline aftertrimming1or2largest samples gives7clusters; alternatenormalization6. Theirmatchingfalsecontrolsnotrun; do not use thosecountsas calibratedrejection/validation.

Lower-cut bookkeeping discrepancy: statedON>=2/OFF<1.5 gives80vs83.575mean;ON>=2/OFF<2gives107vs108.15mean, not packet118vs120.9. Needoriginalconfiguration; qualitativeabsenceofloosecutexcess holds. Supplied FFTscript concatenatesgappedONscans; claimedshuffletestimplementationnotincluded. Preserveunknown vs notdone.

NominalON17header coordinates differ from suppliedcomet by16.108arcmin IF sameframe;ON13=.158,ON15=.711arcmin. Officialblimpycodeconfirmshours/deg units. Actualpointing,frame/epoch and catalogvsencodermetadata meaning unresolved. Do not callscan17offtarget withoutantenna/pointingtelemetry. All6headersreplicated, masksunchanged.

Data durability:294fullcoarsechunks match priorcompressedhashes;112871892overlappingnativevalues match bitwise;all6full outputCRCs/SHAchecked. Totalcompressedoutput1050141263bytes. restore_inputs.py has been executed successfully for all6archives and reproduces exactnativeNPYhashes. Standalonenormalizationmodule ASTmatchesexecutedfunction; codehardening prevents completedstatewithoutmissingrawdatafromsilentlycreatingzeroarrays. Scores,41candidate-sets,all13six-scanwaterfalls,paths/times anddiagnostics are in evidence; large regenerable numericalcaches excluded.

Next focusedwork: verifyheadersemantics/actualpointing and freeze an independent-data test forC03beforeexaminingnewpowers, with explicit frequency/modeltolerance,occupancy andstatistic. Resolveglobaltrialhistory andlower-cutconfiguration. The broader fiveconditions remainhypotheses; no semanticmessage identified. Keep ATApublishedFig7/8audit separate.

--- Historical checkpoints below ---

# Exact reproduction complete: original thirteen survive reproduction

All thirteen clusters reproduce, and every one of78reported rounded scan scores agrees to its0.01precision. Mean cluster frequencies agree within0.0005Hz (export rounding, not physical accuracy). For all6scans, optimized true-frame score vectors are bitwise identical to the original unmodified supplied function.40false-acceleration controls reproduce mean3.75,SD2.046338,max8;none reaches13. A plus-one rank is1/41under this finite control construction; it is not a globally calibrated p-value. The earlier pastedmax10is superseded by READMEand independently reproducedmax8for these40seed11controls.

This is a reproducible exploratory count excess under the supplied method, not an established transmission. The original selection spans2.93MHz and is separate from the previous±5kHzaggregateanalysis. Do not overwrite it with the earlier negative narrow-window result. All full-coarse inputs are acquired;scan18 is being saved with this checkpoint. Remaining work: direct13candidate diagnostics, source-line contamination check, coordinate-grid and spike-removal sensitivity, and careful treatment of the nominalON17header discrepancy. Do not automatically classify C01as crossing the fixed tone: its entire supplied path remains below it. Both possible human interference and intrinsic/transmitter interpretations must carry their actual evidence.

## Input batch complete through scan0017; exact reproduction running

Full coarse7 for scans13–17 has completed source-chunk SHA comparison against the previous acquisition, native overlap equality, output CRC and SHA checks; scan18 is finishing. All13 supplied frequencies span the coarse channel, none in the former±5kHz line window. The original supplied code is preserved unchanged. Exact original-parameter Horizons query has been saved, including response; header RA units confirmed as hours by official blimpy source. A source-header inconsistency exists for nominalONscan17: its coordinates differ from the supplied comet position by16.108arcmin (ON13=0.158arcmin; ON15=0.711arcmin). This is a nominal-header check, not proof of actual telescope pointing/tracking. Need actual pointing telemetry before using the discrepancy as a rejection.

reproduce.py is computing the legacy40-control procedure with float64 row caching, each true-frame output checked against unmodified supplied code. No reproduced candidate count exists yet. Candidate labels C01/C02 remain supplied classifications pending raw-spectrum audit; C01's listed monotone track is already below the cited fixed tone at its start, so a literal crossing must not be assumed merely from the proximity label.

# Active continuation: direct thirteen-candidate audit, 3 November2026

The original candidate CSV and code were supplied. They expose an important scope mismatch: the thirteen are drawn from an entire2.93MHz coarse channel, and none is in the previous±5kHz OH window. Previous results remain bounded to their narrower selection and must not be used as a rejection of these thirteen. The new audit plan follows. No full-channel reproduction result yet.

# Direct audit of Claude's thirteen candidates
Written3November2026 before acquiring full-channel powers for this audit.

## Inputs and scope correction
User supplied oh13.zip (SHA2562034f51db60240330fb35c618900be6ace1af5e49b3609a29abb0f1202dfdff5) and oh13_candidates.csv (SHA256d3d15492915a18b09787534bc2e8df70f54a4d9934658ad631e0a9a7fb7f42df). ZIP CSV and attached CSV are identical;78rows,13IDs,6scans. The13span rest1665.604557–1668.429424MHz, a full2.93MHz coarse-channel selection, NOT a±5kHz OH-line window. None lies in the previous central±5kHz1667window; seven lie in the earlier wider raw cutouts. Therefore the previous narrow-window result does not adjudicate these13. Keep it as a separate completed analysis and add explicit scope correction.

## Frozen reproduction
- Preserve attached sources unchanged under reference/. Never run their fetching scripts blindly.
- Acquire entire coarse channel7 for all6exact files from the already verified published index. Reuse known chunk locations/hashes, retain every49native integration and1048576channels. Check equality to existing saved overlapping windows and per-chunk hashes.
- Save native full-channel arrays, output CRC/hashes and source manifests per completed scan.
- Fetch and save the EXACT original-code Horizons query (C/2025N1, geodeticGBT(-79.8398,38.4331,0.807), original start/stop/1minute grid). Compare candidate-export path/velocities with current response; do not assume the historical solution identical.
- Reproduce original time-median-per-channel division, 3-channel boxcar, rolling/integer drift, global coarse-channel MAD score,9DCbinszeroing, ±1channel ON/OFFmaxfilter, ON>=2.5allthree/OFF<2allthree, and10Hz clustering. Save all clusters, not only first50. Reproduce40false-acceleration controls seed11 and0.03–1Hz/s scaling at1.42GHz; compare README13vs3.75±2.05,max8 with earlier pastedmax10.
- For efficient but faithful computation cache each scan's normalized3-bin rows once. Preservefloat64math and accumulation order; verify selected outputs against original unmodified code. Calibrate every frame's MAD separately as original.
- Export uses clustermean frequency but scores of a separately chosen best member; identify that mapping and do not require rounded mean coordinate to reproduce best score.

## Candidate diagnostics, after reproduction
For all13: reported vs reproduced scores, per-time/per-scan contributions, fixed topocentric feature crosschecks, brightest samples, ON/OFFmorphology and local-neighbor controls. Test C01/C02's supplied interference labels rather than adopt them. Keep source-ID/human-transmitter-ID unresolved unless independently supported.

Inspect method sensitivities separately, without silently changing legacy reproduction: time-median versus frequency-baseline normalization; three-bin smoothing/tolerance; global coordinate spacing versus exact reference rest-grid spacing; circular rolling/edge validity; same-count clustering in true/null; different masks. Selection-bias checks must rerun the whole selection in each control, not treat positive ONmeans of selected candidates as independent evidence.

A metadata concern to audit: uploaded ONscan0017 pointing RA10.86618h andDec6.7017deg differ visibly from uploaded comet coordinates162.722566deg,6.692033deg. Verify original header units and values before interpreting; nominal header coordinates alone do not establish actual pointing/tracking.

## Checkpoint
Persist full-channel inputs and completed computation batches during work. Nextcommand: acquire fullcoarse7withboundedranges, all6files, save each output.


---

# Latest state: GBT1667 reconstruction and extra checks complete, 3 November2026

All six raw cutouts, source hashes, exact ephemeris, acquisition/analysis code and final report are preserved in this completed batch. The report is GBT-1667-excess-audit-2026-11-03.md; evidence package is libfile_130c575875688191881fcdc77c1c6782. Native cutout IDs are in native-input-ledger.json. No unfinished spectral analysis is being claimed as complete.

Result: no exceptional general1667 comet-pointing narrowband excess under this independently defined detector. In±5kHz, thresholds2,2.5,3 empirical MAD units give ON86,19,3 versusOFF99,32,6. A second normalization width gives18ON versus28OFF at2.5. These are NOT Claude's sigma units or his missing13candidate identities.

The strongest ON-minus-OFF feature is distributed over all threeON scans and is not a single-spike artifact, but51of66neighbor windows have an equal/larger contrast maximum. Among40correlated alternative drift curves,38 have an equal/larger ON maximum and28 an equal/larger contrast maximum. No global p-value is claimed. All50new contrast peaks have per-scan/leave-one-out/sample-concentration records; all26at1667 have six-scan waterfalls.

Eighteen native-power injections through complete normalization show the stronger persistent model passing the descriptive ON≥4 andcontrast≥4 gate at3/3placements (amplitude0.6per-samplelocalMAD). At0.15/0.3 and for middle-scan-only injections,0/3 placements pass percase. This is not a completeness curve, voltage simulation, physical upperlimit or proof that every weak/intermittent signal is absent. Fourth condition is not equated with low amplitude.

Ordinary original-file HDF5 reads match64selected saved values bitwise. All six output CRCs and SHA256checked.582,092,902bytes of native cutouts retained from1,907,740,953compressedchunkbytes plusmetadata. Score files, CSVs, plots, fullcodes and original ephemeris are in the final evidence package. Earlier checkpoint statuses below are historical and superseded.

Next substantive action: obtain or locate Claude's exact13candidatecoordinates and score/control/trial definitions, then cross-match them to the already saved native powers. Without that handoff the original13-versus40 statistic cannot be individually adjudicated. Any fresh confirmation must use unexamined observations at the specified1667feature with adequate sensitivity; another receiver band is not direct replication. Keep the unresolved ATA Fig7/8 raw-data audit separate.

---

## Batch2 complete — new1667 track-power reconstruction

All six native raw-power cutouts are now saved (native-input-ledger.json lists their Library IDs). A separate ordinary HDF5 read of original source scan13 agrees bit-for-bit for32 selected values at each OH window (64 values total). No mask dataset exists in that inspected source. All input-file hashes match the acquisition ledger.

New detector, central rest±5kHz,1024-channel baseline:1667 ON connected-peak counts at2,2.5,3 units are86,19,3; OFF counts99,32,6.1665 counts at2.5 are24 ON and24 OFF. Score units are empirical background MAD, NOT Gaussian significance or Claude's sigma. The1667 ON maximum is3.1547 and OFF maximum4.1177. With4096-channel baseline,1667 counts at2.5 are18 ON and28 OFF. No general comet-pointing excess appears under this reconstruction.

The26 selected1667 ON-minus-OFF contrast clusters have a maximum3.37849 at rest1667.363232724MHz (offset+4202.724Hz). This top peak is distributed across all three ON scans (individual scores1.717,1.908,1.266), with aggregateON2.820 andOFF-1.961; it is not dominated by one integration (top two positive samples7.56%). However51 of66 matched neighboring10kHz windows have an equal/larger maximum contrast;64 of66 have an equal/larger ON maximum. Thus it is not exceptional relative to these descriptive controls. No formal global p-value computed; neighboring windows are not independent experiments.

All50 new contrast clusters (26 at1667,24 at1665) have a per-scan ledger and leave-one-ON-scan-out scores. They are not Claude's missing13 candidate identities. The full distributions, continuous tracks, raw spectral medians and threshold curves are saved. At1667,15 of26 contrast-selected peaks have positive scores in all three ON scans, but that is same-data selection and not independent confirmation.

Currently running extra_checks.py: correlated drift-curve multiplier controls,18 power-domain injections through original-power normalization (two occupancies,three amplitudes,three placements), and six-scan waterfalls for every new1667 contrast cluster. No extra-check result is asserted yet. Next: inspect outputs, write bounded final report, update evidence ZIP/checkpoint. Main analysis is already preserved by this batch.

## Batch1 complete — all six GBT native-resolution cutouts acquired

All scans0013–0018 completed, each49 samples, both original0.8MHz windows at2.7939677Hz resolution. Output CRCs and SHA256 verified. Native-input-ledger.json lists each output and downloaded compressed-byte total. Scans13–16 already saved; scans17–18 being saved with this checkpoint. All six raw cutouts are distinct from normalized analysis. The initial source file contains only data, no mask dataset. Selected samples are being independently checked against ordinary HDF5 reads of the original file via validate.py.

Next command: python -u gbt-excess-20261103/analyze.py. Analysis code SHA256 969347848572ea5d4d617e91d62307939a06eb5c7d560221765be80e1777f685. It uses first-sample-center reference, JPL radial-velocity curve, nearest native-bin track sums, empirical per-background MAD units, ON/OFF contrast, stationary-frequency comparison, local median-block widths1024 and4096, central rest-frequency windows±5kHz and nearby-window controls. Threshold counts are descriptive; no global significance claim will be made. Exact Claude detector/frequencies still unavailable. This is an exploratory reconstruction.

## Completed power batches: scans0013–0016

Four of six native-resolution OH scan cutouts have completed and passed ZIP CRC and output hash checks. Scan13 is already saved as libfile_17d429ae470c81919f72cc2c6523fa43; scans14–16 are being persisted with this checkpoint. Scans17–18 still acquiring. No score analysis has been run. First source HDF5 inspection lists only data, no separate mask dataset. Analysis code defines a new detector (1024-channel local median bandpass with4096-channel sensitivity variant), not Claude's unrecovered original statistic.

## Completed power batch: scan0013

Scan0013 native-resolution windows completed and passed ZIP CRC validation. Output GBT-OH-scan0013-2026-11-03.npz, 97,620,813 bytes, SHA256 ebbb776ee940da6ef0a45583891453f80c6c94021228a983ec4df0bbeac01ee8. All49 integrations and both frozen windows retained. Remaining scans acquiring; no statistic evaluated yet. Archive input state and decoding code accompany the evidence package. Resume with acquire.py acquire --scan0 (completed scans can be skipped once outputs verified); currently running sequentially. Save individual scan outputs as they finish.

# Active batch — Green Bank 1667 MHz reconstruction, 3 November 2026

## Batch 1 checkpoint: metadata complete, powers acquiring

All six exact blc23 L-band file headers, channel selections and HDF5 chunk locations are saved. JPL Horizons query uses C/2025 N1 and observer -9@399, verified by response as Green Bank 100-m GBT. Saved response uses JPL#55 solution dated 21 October 2026; this is not necessarily Claude's ephemeris, so exact replication remains unclaimed. Deldot during cadence is about -1.90 to -1.86 km/s, predicting negative frequency drift about -0.11 Hz/s. Both lines fall inside frozen windows.

Native powers have not completed acquisition yet. An initial decoder setup erroneously supplied HDF5-generated bitshuffle filter prefixes as user parameters; no resulting powers were saved. Corrected code supplies block size/codec only and uses HDF5 native memory rather than threaded Python file callbacks. A complete compressed block decoded successfully in this corrected configuration. The current acquisition runs scan13–18 sequentially with eight bounded-range workers, shared physical chunks deduplicated, atomic per-piece state, native-resolution power windows and hashes. Resume only from nonempty completed-piece state and CRC-checked output archives. Code, exact input links, all six metadata records and ephemeris are in GBT-OH-reconstruction-evidence-2026-11-03.zip. Next: finish first scan, save it, then remaining scans. No new excess result yet.


Authorized by Lee: proceed with the investigation. We are acquiring the six L-band scans and small native-resolution OH windows. Exact Claude thirteen-candidate artifacts are still absent; label this as a new exploratory reconstruction. The full frozen batch plan follows and precedes the historical checkpoint. No new power-spectrum result exists yet.

# Green Bank 1667 MHz reconstruction — batch plan

Written 3 November 2026 before retrieving spectral powers for this reconstruction.

## Status and scope
Claude's exact thirteen frequencies, original score definition, trial ledger and code are not available in the current record. This is a new exploratory reconstruction, not a reproduction of that statistic. All six L-band scans have already been examined by Claude; no scan in this cadence will be described as fresh confirmation. Prior ATA work is distinct.

## Batch 1: data and physical checks
1. Enumerate exact public index links for blc23 L-band scans0013–0018, high spectral resolution product0000, and retrieve each header and chunk-location metadata.
2. Obtain JPL Horizons topocentric radial velocities for 3I/ATLAS at Green Bank at scan sample centers; archive query/response. Verify designation and observer location. Apply first-order radial Doppler model with explicit sign; use independent header frequency/time checks.
3. Extract native float32 spectra for every integration over observed 1666.95–1667.75 MHz and1665.00–1665.80 MHz (generous windows around the two laboratory lines allowing ephemeris correction); retain original channel order, exact frequencies, timestamps and raw powers. This interval choice is frozen before power inspection; extend only if verified ephemeris shows it misses required context and document why. Downloaded compressed chunks may cover wider coarse channels; preserve their hashes and trim stored arrays to the stated intervals.
4. Validate range responses, input dimensions, zero masks, finite values, chunk filter decoding and per-scan time coverage. Compare at least one decoded chunk with ordinary HDF5 decoding via an in-memory single-chunk reconstruction.
5. Persist spectra and input manifests after each completed scan. Save batch1 artifacts and update main checkpoint before score analysis.

## Batch 2: exploratory analysis
- Inspect raw/normalized frequency-time spectra, bandpass and coarse-channel boundaries; preserve original arrays.
- Use row local median noise normalization and frequency structure controls with explicit bandwidths; compare a second normalization as sensitivity check.
- Comet-frame constant-rest-frequency track stack versus fixed observer frequency; separate ON(13,15,17)/OFF(14,16,18). Score ON/OFF separately and combined with recorded variances, do not blindly assume equal receiver noise.
- Retain continuous scores and score distributions, counts above 2,2.5,3 as descriptive benchmarks only. Cluster adjacent bins into peaks before interpreting counts.
- Report every selected peak with per-scan contribution, leave-one-ON-scan-out robustness, and corresponding OFF-track scores. Identify single-integration contributions.
- Compare matched nearby-frequency and controlled drift templates on identical valid coverage. Do not assign formal global significance without calibrating complete selection/trials and noise correlations.
- Broad OH emission, bandpass effects and interference remain candidate explanations. Missing1665 counterpart is not mandatory rejection of an artificial emitter model.
- Injection recovery through complete normalization/selection measures sensitivity; statistical score units are not turboSETI units or physical flux/EIRP.
- Any relational/message hypothesis must be specified finitely and tested on unexamined data, not endlessly fit to these scans.

## Immediate next action
Run metadata acquisition; no signal conclusion yet. Code and completed batches must be durable before long continuation.


---

# 3I/ATLAS research: durable checkpoint and recovery handoff

## 1667 MHz follow-up: access verified and next analysis, 3 November 2026

Current user asks how to investigate Claude's reported 1667 MHz excess more deeply. No reproduction of the excess has yet occurred.

Primary sources checked:
- https://seti.berkeley.edu/atlas/ : GBT L-band scans 0013–0018, one six-scan cadence, spectrograms total intensity only. Do not propose polarization analysis on this product.
- https://arxiv.org/html/2512.19763v1 : December 18, 2025 observations; ABACAD three ON and three OFF, five minutes per scan. L-band covers 1.1–1.9 GHz. Paper uses approximately 16-sigma ON and 10-sigma OFF thresholds after software calibration, not Claude's bespoke 2–3-sigma statistic.
- https://bldata.berkeley.edu/ATLAS/GB_ATLAS/ : index opens and lists the six L-band scans and all three spectral products.

Direct public file access works with HTTP 206. Inspected headers for scan 0013 on nodes blc21–blc26 using bounded ranges; all are accessible. Node blc23 is the segment containing both OH lines:
https://bldata.berkeley.edu/ATLAS/GB_ATLAS/blc23_guppi_61027_17226_DIAG_3I_ATLAS_0013.rawspec.0000.h5

Verified scan-0013 metadata: dataset data shape (49,1,67108864), float32, chunks (1,1,1048576), fch1 1688.96484375 MHz, foff -2.7939677238464355e-6 MHz (2.7939677 Hz channel width), tsamp 6.084537002666661 s, tstart MJD 61027.199375. File size 10,205,777,185 bytes. Header/metadata inspection transferred 118,049 bytes for this file. Initial 65,536-byte block SHA256 b01e8a87062a472a894c3df6bbb1a9fb68c522d973cbb9ce5b6d283160b4f673. No power-spectrum cutout has been fetched in this continuation.

The same public index lists blc23 products for:
- 0013, 17226, ON
- 0014, 17543, OFF
- 0015, 17861, ON
- 0016, 18179, OFF
- 0017, 18497, ON
- 0018, 18814, OFF
Use the exact hrefs from the index rather than infer filenames. Only scan0013 metadata has been checked on this pass; verify all remaining headers before extraction. The header's single feed/intensity dimension and official total-intensity description do not preserve separate polarization streams.

Recommended staged follow-up, not yet executed or fully preregistered:
1. Recover Claude's exact 13 candidate frequencies, selection definition, normalization, deduplication, reference epoch, ephemeris and controls. If unavailable, label a new reconstruction rather than claim exact replication.
2. Extract bounded original-resolution context around the 1667 MHz region from all six blc23 scans; inspect bandpass and coarse-channel boundaries, timestamps, channel order and Doppler sign/reference frame. Keep unnormalized powers.
3. Inspect all 13, not a selected four, and cluster adjacent bins/templates into distinguishable features. Produce per-scan and time-bin contributions; leave-one-scan-out is robustness only, because all original scans are already examined.
4. Compare ON/OFF behavior with local-noise normalization and time-variable interference considered. Compare physical comet-frame, stationary receiver-frame, and controlled offset tracks. Different frames must sample comparable noise and not create a misleading control population.
5. Replace the single threshold-count claim with the full score distribution and threshold curve, plus matched controls. Calibrate the complete selection over tested windows, thresholds and track choices; do not treat 40 control drifts as 40 independent sky observations.
6. Compare broad OH-line/background and instrumental models as well as narrow tones. Other OH transition is useful context, not mandatory artificial-signal replication.
7. Test recovery by injecting signals through the entire normalization/selection pipeline over amplitudes, durations and occupancy; publish completeness. This measures what a null can exclude.
8. Actual confirmation requires unexamined observations of the same predicted feature, ideally another epoch/instrument with adequate sensitivity. A different GBT receiver band cannot directly reproduce 1667 MHz. Frozen relational predictions can be tested only after a candidate relation is defined; do not retrofit new symbolic keys indefinitely.

Next concrete deliverable: exact input/candidate ledger, small spectral cutouts, and per-scan contribution table, before another global verdict. Persist that bounded batch and code. The reported 13-versus-controls excess is presently an unresolved exploratory statistic, not a verified astronomical excess or a detected message.



Checkpoint date: 3 November 2026 (updated with user-supplied Claude narrative). Purpose: preserve active task identity, verified outputs, gaps, and the next action across timeouts, usage-limit pauses, context loss, or replacement of the temporary workspace. This checkpoint contains no new astronomical analysis.



## Continuation update — Claude's reported MeerKAT and Green Bank work, 3 November 2026

Source: Lee pasted Claude's account in the current conversation. This recovers a narrative record, not the underlying code, input files, plots, hashes, ephemeris query, or complete candidate ledger. It is not yet established that this is the same interrupted pass described earlier. Keep it separate from our independently saved ATA analyses. The unrelated opening MPAI review in the paste is not astronomical evidence.

### Reported MeerKAT hit-list searches

Claude reports about 6 million hits across five observing days, with 63 other beams as controls. Each hit list is said to include only detections with S/N >= 6.

1. Comet drift: minute-by-minute JPL Horizons predictions, within 0.005 Hz/s; comet-beam match fraction 0.70%, other-beam fraction 1.24%. A December 19 comb at 1276–1281 MHz was labelled Galileo E6 and appeared in all 64 beams. Reported seven-pointing drifts: -0.30, -0.19, -0.005, -0.19, -0.17, -0.09, -0.12 Hz/s; comet prediction approximately -0.18 to -0.12. Agreement only in last pointing weakens simple persistent comet-drift interpretation; specific transmitter ID remains to be audited against files.
2. Comet-frame frequency repeats: 187 recurring frequencies; another statistic counts 358 matches. Across 400 random frame shifts, average 392 matches and 87% tie or exceed true-frame count. Resolve unique-frequency versus pairwise-match units before reproducing.
3. OH windows: ±5 kHz around 1612, 1665, 1667 MHz rest; zero hits in any beam.
4. Hydrogen, H/sqrt(2), H/phi: ±1 kHz in comet frame; zero hits in any beam.
5. A later hydrogen-band candidate around 1420.549–1420.558 MHz on December 19: 449 hits, all 64 beams, all seven pointings over about three hours; S/N 6.7–7.2, slopes spread -10 to +10 Hz/s. Claude reports LSR velocities -1.7 to -3.4 km/s and interprets this as Galactic hydrogen. Shared occurrence and inconsistent slopes undermine a localized comet tone; physical source assignment and velocity transformation not independently reproduced.
6. Important admitted correction: ±20-channel (~32 Hz) beam matching missed counterparts a few kHz away in broad features. Earlier unique-beam counts 310, 47, 628 are overstated and must not be reused as valid localization evidence. Widening a coincidence window must be calibrated for accidental matches; inspect shared spectral morphology rather than use an unlimited window.

### Reported Green Bank raw-spectrum searches

Claude reports six L-band scans and two OH channels, subthreshold tone searches, plus wrong-drift controls:
- 1667 MHz, 2.5 sigma: 13 candidates; 40 wrong-drift controls average about 4, maximum 10.
- 1667 MHz, 3 sigma: 1; controls 0–2.
- 1667 MHz, 2 sigma: 118; controls 121 ± 12.
- 1665 MHz, 2.5 sigma: 5; controls 5.7 ± 2.2, maximum 11; 29/40 tie or beat true frame.
- Four candidate plots reportedly show no convincing track; one is dominated by one scan.
- Reported recovery floor around one third of per-sample noise; injection definitions, completeness versus amplitude, durations, and statistical normalization unavailable.
- Candidate-set structure tests report p = 0.14–0.48 versus size-matched random sets. Nine false-drift frames tested, retaining sets with at least four candidates. No mirrored pairs in either population; mean candidate distance to whole-kHz offsets 0.25 kHz versus false-frame 0.15–0.37 kHz. Metric definitions, selections, and all trials remain needed.

### Limits on interpretation and next audit

These results, if reproduced, support no demonstrated comet-locked narrowband signal in the specific tested data and templates. They do not establish absence of every structured signal or full agreement across every band in the published survey.

- Second OH line absence is a replication failure only for a stated model predicting corresponding structure there. An artificial emitter is not intrinsically required to use both OH transitions.
- A 2.5-sigma-cut excess disappearing at adjacent cuts does not by itself prove fluctuation; both real populations and selection effects can do that. The reported 13 exceeds all 40 controls. If this were a single prespecified exchangeable statistic, the plus-one Monte Carlo tail estimate would be 1/41, not zero; post-selection trials and control validity must be audited before any significance claim.
- Condition 4 (boundary of determinability) does not logically force amplitude below the quoted recovery floor. Ambiguity may concern source, modulation, temporal relation, or interpretation at detectable amplitude.
- Comet-frame tests impose an emitter model. A sender able to control transmission could compensate its apparent drift; a failure of this template is not a general null for deliberate address.
- Reported nonsignificant structure tests mean no detected structure under those statistics, not proof of structure's absence.
- Do not assume every raw spectral product preserves polarization or voltage phase; inspect the actual dataset dimensions and metadata.
- Obtain or locate Claude's filenames, code, ephemeris query, candidate tables, plots, trials ledger, and injection results before calling this independently verified.

### Access update and immediate next action

The archive is a nested public index; do not shift navigation onto Lee. On 3 November, we followed the root to July 5 and July 9 session indexes successfully (HTTP 200). Both explicitly list the required Figure 7/8 scan directories. Those exact directories return 403 from both urllib and web retrieval, with encoded or literal colons; the first listed scan in each of those sessions also returns 403. Known July 3 scan opens, lists 28 subband folders and metadata; a known beam file supports HTTP 206 byte ranges (256 bytes retrieved from a 4,782,367,488-byte file). These results establish request-specific failure, not universal archive inaccessibility. Next substantive steps remain mapping available products ourselves and auditing real rejections, while locating the separate Claude-work artifacts if accessible.


## Latest correction — working public download exists

Lee Sharks reports that he can download the data, but the files are huge. Do not treat earlier assistant HTTP 403 responses as proof of general inaccessibility or assume the archive operators must repair permissions. The assistant has not yet matched Lee's working URL/filename to the exact Fig. 7/8 observations. The new pasted attachment was unavailable, so no content was read from it.

Immediate next action (superseded by 3 November navigation update above): follow the nested public index ourselves; reuse a working URL if already supplied, rather than require Lee to locate it or upload multi-gigabyte data. Compare its identity with the required scan/subband/beam; test a small HTTP byte-range request. If ranges are supported, use the already developed metadata/chunk extraction method to preserve only the needed original-resolution spectral windows, with manifests and hashes. If range access is unavailable, use a resumable download into durable storage or a local cutout workflow. Keep raw power spectra distinct from plots and filtered hit lists. No external message has been sent.

## Current continuation — published human-source examples, batches 1–2

User has authorized continuing the search under all five conditions, including an intention to become recognizable as signal to observers who learn how to look, and double-checking human-source rejections. The active branch is the published-rejection audit, not a synthetic injection exercise.

Batch 1 identifies the authors' Figures 7 and 8 as actual published inspected cases. Figure 7 is centered at 1626.675919 MHz, above Iridium's documented 1626.5 MHz upper service-band edge. This undermines a simple in-band attribution, not the wider possibility of human interference. Figure 8's similar two-beam feature supports spatial rejection but does not identify an emitter. Both exact public scan-directory links currently return HTTP 403; raw-array reanalysis of these cases has not been performed. The report is [ATA-published-rejections-audit-2026-11-02.md](https://chatgpt.com/library?file_id=libfile_dda33beda8108191b9a2c6b1e13fc291&account_id=personal), and the evidence package is [ATA-published-rejections-evidence-2026-11-02.zip](https://chatgpt.com/library?file_id=libfile_9f5bc41d48b48191bf92bafcb93664bb&account_id=personal). Read their latest saved versions on resumption.

Batch 2 complete: CEPT ERC Report 91 explicitly supports a possible Iridium unwanted-emission mechanism above 1626.5 MHz, so the band edge does not rule Iridium out. Both exact and four adjacent example directories returned 403; the old July 3 control remains accessible. A new first-nine/last-ten crossbeam transfer diagnostic on our 15 exploratory candidate windows gives test R² 0.060–0.228. Sixty neighboring-frequency controls also transfer, so common background contributes; no emitter or message is identified. Results and code are in the updated evidence package. Next: obtain accessible paired powers for the published cases or the authors complete rejection ledger, and run a frozen relational search on unexamined accessible observations. Keep authors' candidate identities separate from our own. Persist results and this checkpoint after the batch. The historical recovery record below remains preserved.

## Active task — do not substitute another branch

Lee Sharks asks to recover a specific interrupted pass: looking further at radio features ruled out as human-sourced/terrestrial interference, and testing how solid those classifications were. He reports an hour or more of work on that pass before a gap. The latest assistant response mistakenly discussed a future teaching/decoder test instead of addressing that interrupted audit.

Do not treat synthetic injections, a template-bank null, or a future decoding proposal as the missing real-feature rejection audit. Do not rerun adjacent work and label it recovery of the missing pass. New reconstruction must be identified as new reconstruction.

## Recovery result

Completed research packages survive in durable storage. The present temporary workspace no longer contains the later baseline/readable-signal working directories. The three-scan package was restored in this recovery check and its archive CRCs were verified. Older first-pass and filter-audit ZIPs were also CRC-checked. Named real-feature tables have been recovered.

A distinct later human-source classification audit from the hour described by Lee has **not been located** in the inspected saved-file inventory, current working files, or retrieved conversation context. This does not establish that the work never occurred. Do not claim that the missing pass is safely retained or completed without finding its actual evidence.

The latest substantive saved outputs found in the 2 November file inventory were the readable-signal report/package and revised archive review, saved around 11:59 a.m. Eastern (16:59 UTC). No later substantive research artifact was found in that inventory during this check.

## What does survive

| Work | Verified surviving content | Scope distinction |
|---|---|---|
| First excluded-data pass | Paired spectra and report around 1075 MHz; ZIP CRC checked | Shared feature supports an interference/instrumental interpretation, not identification of a particular human transmitter |
| Filter/code follow-up | 11 real-track rows; archived selector tests; 72 injections; code and arrays; ZIP CRC checked | Our shortlist and source-code behavior; not the authors' complete rejected-hit catalogue |
| Three-scan real-feature follow-up | 15 named maxima and 40 adjacent-scan comparisons; full ZIP restored and CRC checked; tables extracted | Real-feature screening survives; not proof that these were the authors' individually classified 211 final cases |
| Baseline-emitter pass | Report and analysis/spectra packages present in saved-file inventory | A separate physical-trajectory search, not the missing RFI-classification audit |
| Eight-family readable-signal pass | Report read in full; analysis package present in inventory | Expanded model coverage and synthetic recovery; not a replacement for checking actual human-source classifications |

The three-scan record reports that the 15 maxima largely cross or follow shared spectral structures; two time bins account for 63.7–91.0% of their positive beam-difference contribution. None of 40 exact adjacent-scan continuations passed its stated screen. Fourteen looser window comparisons passed, but were not exact recurrence. This supports the limited conclusion of no convincing persistent target-specific line in that sample. It does not identify each transmitter or rule out every possible coexisting weaker component.

Recovered named examples include S0-target-0000 at approximately 1075.010054588 MHz, drift −0.372640190 Hz/s, and S0-target-0002 at approximately 1075.060820580 MHz, drift +0.05 Hz/s. Refer to the recovered CSV for exact stored values and definitions. These are our exploratory maxima, not authenticated IDs from the original survey's rejection ledger.

## Durable file references

- [First excluded-data package](https://chatgpt.com/library?file_id=libfile_b7612f610a80819181b16a3f3f9e82f5&account_id=personal)
- [Filter/code audit package](https://chatgpt.com/library?file_id=libfile_3cf2d2e5c9808191acf61a59eb5a1fa0&account_id=personal)
- [Three-scan real-feature report](https://chatgpt.com/library?file_id=libfile_533c20002e088191a0f5d921f4f89206&account_id=personal)
- [Three-scan data and analysis package](https://chatgpt.com/library?file_id=libfile_6f7ab05ea5688191bb1b1fd0e15d9785&account_id=personal)
- [Baseline report](https://chatgpt.com/library?file_id=libfile_4eaf891f124c8191beb093c4e58efc1b&account_id=personal)
- [Baseline analysis package](https://chatgpt.com/library?file_id=libfile_859f52be87c48191bf1133ac14264170&account_id=personal)
- [Baseline spectra package](https://chatgpt.com/library?file_id=libfile_f61c525436548191bee7e5850e30f54a&account_id=personal)
- [Readable-signal report](https://chatgpt.com/library?file_id=libfile_8fdb6d0d835c81919363e236ba63a28c&account_id=personal)
- [Readable-signal analysis package](https://chatgpt.com/library?file_id=libfile_490eb1973bf08191abe8cc161b8b1e7d&account_id=personal)
- [Archive review, current version](https://chatgpt.com/library?file_id=libfile_972eb58bcec48191b1158ce7f769f809&account_id=personal)

## Unresolved materials and next substantive action

The inspected saved reports state that the exact executed blanking script, complete signed pre/post-filter hit catalogues, full rejection ledger, and study-specific final plotting population had not been obtained. A statistical or spatial screen suggesting RFI must not be silently upgraded to identification of a human transmitter.

Before restarting research, read this checkpoint and the current three-scan report, inspect the restored per-candidate tables, and identify which real-feature branch Lee means from any available contemporaneous evidence. If no later pass can be recovered, state that limitation and label any continuation as a new reconstruction. Continue the human-source rejection question, not an unrelated decoder-learning study.

For a reconstructed audit, the first deliverable should be a per-feature ledger: original source/candidate identifier if available; observation coordinates; exact rejection reason and executed-rule evidence; same-time other-beam evidence; neighboring-frequency and adjacent-epoch checks; evidence for a specific terrestrial emitter versus generic interference; alternative explanations; and what remains unresolved. Keep our new candidates distinct from the authors' candidates.

## Checkpoint procedure for subsequent work

This is an execution requirement from Lee's request, not a claim that live processes or unsaved memory can survive interruption.

1. Update this same checkpoint before a long run: task, branch, frozen choices, inputs and hashes, command, output paths, and the next action.
2. Break work into bounded batches. At the end of each completed batch, write its results and rejection reasons to files; atomically finish those files; update this checkpoint with completed versus pending work.
3. Persist the partial results and checkpoint as versions during the work, rather than waiting for a polished final report. Inspect each save result. An unconfirmed save is not durable completion.
4. On resumption, read the latest saved checkpoint first, restore the named files, validate inputs, and resume from the last confirmed batch. Never infer that a process is still running because an earlier message said it was.
5. If an interruption happens within an unfinished batch, that batch may need rerunning. Preserve earlier completed batches and disclose the gap; do not silently replace the active task with an adjacent one.

The companion recovery evidence ZIP contains the saved-file inventory, CRC/hash verification receipts, recovered 15-row candidate and 40-row continuation tables, and the 11-row filter-audit shortlist. It does not purport to contain the missing later pass.
import time,json,zipfile,subprocess,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
for scan in map(int,sys.argv[1:]):
    receipt=ROOT/'results'/f'native-save-{scan:04d}.json'
    if receipt.exists():continue
    meta=ROOT/'metadata'/f'scan-{scan:04d}.json'
    while not meta.exists():time.sleep(2)
    archive=ROOT/f'GBT-high-time-native-{scan:04d}.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        for n in [f'data/scan-{scan:04d}.npy',f'metadata/scan-{scan:04d}.json',f'metadata/header-{scan:04d}.json',f'metadata/chunk-index-{scan:04d}.json','PLAN.md','acquire.py','inputs/candidate-high-time-mapping.json']:z.write(ROOT/n,n)
    request={'uploads':[{'local_path':str(archive),'purpose':'create_library_file','library_artifact_type':'other'}]}
    run=subprocess.run([sys.executable,str(ROOT/'helpers/library_upload.py')],input=json.dumps(request),text=True,capture_output=True)
    (ROOT/'results'/f'native-save-{scan:04d}.log').write_text(run.stdout+'\n'+run.stderr)
    if run.returncode:raise RuntimeError(f'Native save {scan} failed; do not automatically retry uncertain save')
    result=json.loads(run.stdout.strip().splitlines()[-1]);assert result['results'][0]['status']=='succeeded'
    result['archive_sha256']=hashlib.sha256(archive.read_bytes()).hexdigest();result['archive_bytes']=archive.stat().st_size
    receipt.write_text(json.dumps(result,indent=2));print('PERSISTED',scan,result['results'][0]['library_file_id'],flush=True)

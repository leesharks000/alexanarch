"""Read only public directory listings and first 4096 bytes of SIGPROC files."""
from pathlib import Path
import concurrent.futures,datetime,hashlib,json,struct,urllib.parse,urllib.request,sys
from html.parser import HTMLParser
ROOT=Path(__file__).resolve().parent
class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,tag,attrs):
        if tag=='a':
            href=dict(attrs).get('href','')
            if href and href!='../' and not href.startswith('?'):self.links.append(href)
DOUBLE={'tstart','tsamp','fch1','foff','src_raj','src_dej','az_start','za_start','refdm','period','fchannel'}
INTEGER={'machine_id','telescope_id','data_type','barycentric','pulsarcentric','nbits','nchans','nifs','nbeams','ibeam','nsamples','npuls','nbins'}
STRING={'rawdatafile','source_name'}
def check(node):
    old=ROOT/f'parkes-jul31-{node}-header.json'
    if old.exists():
        r=json.loads(old.read_text());binary=old.with_suffix('.bin')
        if r.get('status')=='header_read' and binary.exists() and hashlib.sha256(binary.read_bytes()).hexdigest()==r['header_sha256']:
            print(json.dumps({'node':node,'status':'verified_checkpoint_reused'}),flush=True);return r
    directory=f'https://bldata.berkeley.edu/ATLAS/PKS_Jul_31_2025/{node}/'
    result={'node':node,'directory':directory,'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        with urllib.request.urlopen(directory,timeout=25) as f:page=f.read(100000)
        links=Links();links.feed(page.decode());choices=[h for h in links.links if h.endswith('.0000.fil') and '3IATLAS_S' in h]
        assert choices,'No observed source file link';url=urllib.parse.urljoin(directory,choices[0]);result['url']=url
        request=urllib.request.Request(url,headers={'Range':'bytes=0-4095'})
        with urllib.request.urlopen(request,timeout=25) as f:
            assert f.status==206;blob=f.read(4097);result['http_content_range']=f.headers.get('Content-Range')
        assert len(blob)==4096
        pos=0;header={}
        def string():
            nonlocal pos
            n=struct.unpack_from('<i',blob,pos)[0];pos+=4;assert 0<n<256,n
            value=blob[pos:pos+n].decode('ascii');pos+=n;return value
        assert string()=='HEADER_START'
        while True:
            key=string()
            if key=='HEADER_END':break
            if key in DOUBLE:value=struct.unpack_from('<d',blob,pos)[0];pos+=8
            elif key in INTEGER:value=struct.unpack_from('<i',blob,pos)[0];pos+=4
            elif key in STRING:value=string()
            elif key=='signed':value=blob[pos];pos+=1
            else:raise ValueError('Unknown header key '+key)
            header[key]=value
        df=header['foff'];last=header['fch1']+(header['nchans']-1)*df
        result.update(status='header_read',header=header,header_bytes=pos,header_sha256=hashlib.sha256(blob[:pos]).hexdigest(),
                      channel_edge_interval_MHz=[min(header['fch1'],last)-abs(df)/2,max(header['fch1'],last)+abs(df)/2])
        raw=ROOT/f'parkes-jul31-{node}-header.bin';raw.write_bytes(blob[:pos]);result['raw_header_file']=raw.name
    except Exception as error:result.update(status='unverified',error=type(error).__name__+': '+str(error))
    path=ROOT/f'parkes-jul31-{node}-header.json';tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(result,indent=2));tmp.replace(path)
    print(json.dumps(result),flush=True);return result
if __name__=='__main__':
    nodes=[f'blc{i}{j}' for i in range(3) for j in range(8)]+['blc31','blc32'] if '--all' in sys.argv else ['blc27','blc31','blc32']
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(check,nodes))

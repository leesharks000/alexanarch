"""Summarize the saved header witnesses and package this bounded metadata audit."""
from pathlib import Path
import json,hashlib,zipfile
ROOT=Path(__file__).resolve().parent
def run():
    rows=[json.loads(p.read_text()) for p in sorted(ROOT.glob('parkes-jul31-*-header.json'))]
    verified=[r for r in rows if r['status']=='header_read'];assert any(r['node']=='blc27' for r in verified)
    for r in verified:
        h=r['header'];r['nominal_interval_MHz']=sorted([h['fch1'],h['fch1']+h['nchans']*h['foff']])
        total=int(r['http_content_range'].split('/')[-1]);rowbytes=h['nchans']*h['nifs']*h['nbits']//8
        assert (total-r['header_bytes'])%rowbytes==0;r['payload_integrations']=(total-r['header_bytes'])//rowbytes
        assert hashlib.sha256((ROOT/r['raw_header_file']).read_bytes()).hexdigest()==r['header_sha256']
    union=[]
    for lo,hi in sorted(r['nominal_interval_MHz'] for r in verified):
        if union and lo<=union[-1][1]+1e-9:union[-1][1]=max(union[-1][1],hi)
        else:union.append([lo,hi])
    summary={'date_label':'2026-11-04 America/New_York',
             'scope':'First observed on-source high-resolution .0000.fil file per listed July31 Parkes node; metadata only, no power samples decoded',
             'nodes_attempted':len(rows),'verified_headers':len(verified),'unverified':[r for r in rows if r['status']!='header_read'],
             'nominal_verified_union_MHz':union,'target_3648_3688_has_public_parkes_data':True,
             'decisive_node':'blc27','interpretation_limit':'Headers and payload length establish recorded spectral coverage, not usable sensitivity, absence of flags or a completed signal search. Nominal endpoints round Hz-scale channel conventions.',
             'records':rows,'derived_verified_records':verified}
    (ROOT/'coverage-audit.json').write_text(json.dumps(summary,indent=2))
    files=[ROOT/'coverage-audit.json',ROOT/'check_parkes_headers.py',ROOT/'build_audit.py',ROOT/'Parkes-coverage-correction-2026-11-04.md']
    files+=sorted(ROOT.glob('parkes-jul31-*-header.json'))+sorted(ROOT.glob('parkes-jul31-*-header.bin'))
    manifest=[];out=ROOT/'Parkes-coverage-header-witnesses-2026-11-04.zip';tmp=out.with_suffix('.tmp')
    with zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:
            data=p.read_bytes();manifest.append({'path':p.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});z.writestr(p.name,data)
        z.writestr('manifest.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(tmp) as z:assert z.testzip() is None
    tmp.replace(out);print(json.dumps({'verified_headers':len(verified),'union_MHz':union,'archive_bytes':out.stat().st_size,'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
if __name__=='__main__':run()

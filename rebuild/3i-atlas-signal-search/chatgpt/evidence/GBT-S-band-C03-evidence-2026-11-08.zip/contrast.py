import json
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent/'results'
def run():
    out=[];arrays={}
    for model in ['comet','receiver']:
        zs=np.array([np.load(R/f'profiles-S-{s:04d}-{model}.npz')['scores'] for s in range(29,35)])
        arrays[model+'_scores']=zs
        delta=zs[[0,2,4]].mean(axis=0)-zs[[1,3,5]].mean(axis=0)
        center=np.median(delta[1:]);scale=1.4826*np.median(abs(delta[1:]-center))
        pattern=(zs[[0,2,4]]>0).all(axis=0)&(zs[[1,3,5]]<0).all(axis=0)
        ordering=zs[[0,2,4]].min(axis=0)>zs[[1,3,5]].max(axis=0)
        out.append({'model':model,'target_ON_minus_OFF_score_mean':float(delta[0]),'control_center':float(center),'control_MAD':float(scale),'target_contrast_robust_units':float((delta[0]-center)/scale),'controls_at_least_as_high':int((delta[1:]>=delta[0]).sum()),'control_count':100,'target_all_ON_positive_OFF_negative':bool(pattern[0]),'controls_with_same_sign_pattern':int(pattern[1:].sum()),'target_every_ON_above_every_OFF':bool(ordering[0]),'controls_with_every_ON_above_every_OFF':int(ordering[1:].sum()),'scope':'Adaptive descriptive statistic chosen after viewing per-scan signs; no global p-value or significance claim; same100 correlated spectral controls.'})
    (R/'adaptive-ON-OFF-contrast.json').write_text(json.dumps(out,indent=2));np.savez_compressed(R/'adaptive-ON-OFF-contrast-arrays.npz',**arrays)
if __name__=='__main__':run()

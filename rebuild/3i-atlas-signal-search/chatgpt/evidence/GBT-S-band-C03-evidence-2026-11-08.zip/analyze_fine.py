import json,csv,hashlib,time
from pathlib import Path
import numpy as np
from scipy.special import erf
ROOT=Path(__file__).resolve().parent
P=json.loads((ROOT/'inputs/fixed-fine-plan.json').read_text());EP=np.load(ROOT/'inputs/sband-ephemeris.npy');C=299792.458
def mad(x,axis=None):
    m=np.median(x,axis=axis,keepdims=True);return 1.4826*np.median(abs(x-m),axis=axis)
def csvsave(p,rows):
    if not rows:return
    q=p.with_suffix('.tmp')
    with q.open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    q.replace(p)
def template(obs,place,receiver=False):
    t=obs['times'];dt=obs['dt'];sub=t[:,None]+((np.arange(16)+.5)/16-.5)*dt/86400
    assert sub.min()>=EP[0,0] and sub.max()<=EP[-1,0]
    vel=np.interp(sub.ravel(),EP[:,0],EP[:,2]).reshape(sub.shape)
    ratio=np.ones_like(vel) if receiver else 1-vel/C
    fq=place*ratio;sig=P['sigma_rest_hz']*ratio;df=obs['df'];f0=obs['f0'];q=(fq-f0)/df
    lo=int(np.floor(q.min()-8*sig.max()/abs(df)-2));hi=int(np.ceil(q.max()+8*sig.max()/abs(df)+2))+1
    assert 0<=lo<hi<=obs['nchan']
    jj=np.arange(lo,hi);fc=f0+jj*df
    u=(fc[None,:,None]+abs(df)/2-fq[:,None,:])/(np.sqrt(2)*sig[:,None,:]);v=(fc[None,:,None]-abs(df)/2-fq[:,None,:])/(np.sqrt(2)*sig[:,None,:])
    h=np.mean(.5*(erf(u)-erf(v)),axis=2);assert np.max(abs(h.sum(axis=1)-1))<1e-9
    return jj,h,q.mean(axis=1)
def baseline(a,q,df):
    gap=int(np.ceil(50/abs(df)))+1;bs=128;nb=10;centers=np.floor(q).astype(int)
    offsets=np.r_[np.arange(-gap-nb*bs,-gap),np.arange(gap+1,gap+1+nb*bs)]
    ii=centers[:,None]+offsets;assert ii.min()>=0 and ii.max()<a.shape[1]
    values=np.asarray(a[np.arange(len(q))[:,None],ii],float).reshape(len(q),20,128)
    b=np.median(values.mean(axis=2),axis=1);assert (b>0).all();return b
def profile(a,obs,place,receiver=False):
    jj,h,q=template(obs,place,receiver);b=baseline(a,q,obs['df']);r=np.asarray(a[:,jj],float)/b[:,None]-1
    amp=(r*h).sum(axis=1)/(h*h).sum(axis=1)
    return amp,(jj,h,q,b)
def scanfit(A,obs):
    sig=mad(A[1:],axis=0);assert (sig>0).all();w=1/sig**2
    dist=np.interp(obs['times'],EP[:,0],EP[:,1]);q=(np.median(dist)/dist)**2
    means=(A@(w*q))/np.sum(w*q*q);center=float(np.median(means[1:]));scale=float(mad(means[1:]));assert scale>0
    return {'weights':w,'distance_weights':q,'denominator':float(np.sum(w*q*q)),'means':means,'center':center,'scale':scale,'z':(means-center)/scale}
def analyze(scan,force=False):
    out=ROOT/'results'/f'fine-S-{scan:04d}.json'
    if out.exists() and not force:print('ALREADY ANALYZED',scan,flush=True);return
    while not (ROOT/'metadata'/f'fine-S-{scan:04d}.json').exists():time.sleep(2)
    meta=json.loads((ROOT/'metadata'/f'fine-S-{scan:04d}.json').read_text());path=ROOT/'data'/f'fine-S-{scan:04d}.npz'
    assert hashlib.sha256(path.read_bytes()).hexdigest()==meta['native_sha256']
    z=np.load(path);a=z['power'];obs={'times':z['times_mjd'],'dt':float(z['dt_s']),'df':float(z['df_hz']),'f0':float(z['f0_hz']),'nchan':a.shape[1]}
    records=[];recoveries=[];checks=[];profiles=[]
    for mode,base,receiver in [('comet',P['rest_hz'],False),('receiver',P['receiver_fixed_hz'],True)]:
        coords=np.r_[base,base+np.asarray(P['control_offsets_hz'])];A=np.array([profile(a,obs,place,receiver)[0] for place in coords]);fit=scanfit(A,obs)
        amp,(jj,h,q,b)=profile(a,obs,base,receiver)
        # Independent scalar dot products at selected rows, using original power bins.
        errors=[]
        for t in [0,len(a)//2,len(a)-1]:
            value=sum(float(h[t,k])*(float(a[t,int(j)])/float(b[t])-1) for k,j in enumerate(jj))/sum(float(v)*float(v) for v in h[t]);errors.append(abs(value-float(amp[t])))
        assert max(errors)<1e-10
        checks.append({'mode':mode,'scalar_profile_max_error':max(errors),'template_mass_max_error':float(np.max(abs(h.sum(axis=1)-1)))})
        records.append({'scan':scan,'role':meta['role'],'model':mode,'coordinate_hz':base,'score':float(fit['z'][0]),'mean_amplitude':float(fit['means'][0]),'control_center':fit['center'],'control_MAD':fit['scale'],'controls_at_least_as_high':int((fit['z'][1:]>=fit['z'][0]).sum()),'controls_n':100,'passes_role_gate':bool(fit['z'][0]>=2.5) if scan%2 else bool(fit['z'][0]<2.0),'mean_recorded_background':float(np.mean(b))})
        for t in range(len(a)):profiles.append({'scan':scan,'role':meta['role'],'model':mode,'sample':t,'mjd':float(obs['times'][t]),'amplitude':float(amp[t]),'background':float(b[t]),'topocentric_center_hz':float(obs['f0']+q[t]*obs['df']),'weight':float(fit['weights'][t])})
        # Frozen-coordinate recovery in dimensionless recorded-power units, not source EIRP.
        for offset in [0,-45000,-35000,-25000,-15000,-5000,5000,15000,25000,35000,45000]:
            place=base+offset;original,(jj,h,q,b)=profile(a,obs,place,receiver)
            original_mean=float(np.sum(original*fit['weights']*fit['distance_weights'])/fit['denominator'])
            for level in [.01,.03,.1,.3,1.0]:
                injected=a.copy();injected[:,jj]+=level*b[:,None]*h
                got,_=profile(injected,obs,place,receiver);increment_error=float(np.max(abs((got-original)-level)));assert increment_error<2e-6
                value=float(np.sum(got*fit['weights']*fit['distance_weights'])/fit['denominator']);score=(value-fit['center'])/fit['scale']
                recoveries.append({'scan':scan,'role':meta['role'],'model':mode,'offset_hz':offset,'injected_fractional_line_amplitude':level,'baseline_score':(original_mean-fit['center'])/fit['scale'],'injected_score':score,'passes_2p5':bool(score>=2.5),'linear_increment_max_error':increment_error,'scope':'prescribed coordinate; frozen background weights; dimensionless measured-power recovery, no celestial sensitivity calibration'})
        np.savez_compressed(ROOT/'results'/f'profiles-S-{scan:04d}-{mode}.npz',amplitudes=A,coordinates=coords,weights=fit['weights'],distance_weights=fit['distance_weights'],means=fit['means'],scores=fit['z'],times=obs['times'])
    csvsave(ROOT/'results'/f'fine-scores-{scan:04d}.csv',records);csvsave(ROOT/'results'/f'fine-profiles-{scan:04d}.csv',profiles);csvsave(ROOT/'results'/f'recovery-{scan:04d}.csv',recoveries)
    out.write_text(json.dumps({'scan':scan,'role':meta['role'],'scores':records,'checks':checks,'injection_trials':len(recoveries)},indent=2));print('FINE ANALYZED',scan,records,flush=True)
def finish():
    rows=[];recoveries=[];checks=[]
    for scan in range(29,35):
        r=json.loads((ROOT/'results'/f'fine-S-{scan:04d}.json').read_text());rows.extend(r['scores']);checks.extend(r['checks'])
        with (ROOT/'results'/f'recovery-{scan:04d}.csv').open() as f:recoveries.extend(list(csv.DictReader(f)))
    csvsave(ROOT/'results/fixed-C03-scores.csv',rows);csvsave(ROOT/'results/all-injection-trials.csv',recoveries)
    gates={mode:all(r['passes_role_gate'] for r in rows if r['model']==mode) for mode in ['comet','receiver']}
    summary={'status':'complete','scope':P['scope'],'scores':rows,'three_ON_three_OFF_gates':gates,'injection_trials':len(recoveries),'checks':checks,'response_calibration':'not established at candidate frequency; no physical null or upper limit'}
    (ROOT/'results/fine-summary.json').write_text(json.dumps(summary,indent=2));print('FIXED COMPARISON COMPLETE',gates,flush=True)

if __name__=='__main__':
    import sys
    for scan in range(29,35):analyze(scan,'--force' in sys.argv)
    finish()

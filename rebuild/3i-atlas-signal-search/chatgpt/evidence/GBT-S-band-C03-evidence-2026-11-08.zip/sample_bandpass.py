import json,hashlib,concurrent.futures,time
from pathlib import Path
from html.parser import HTMLParser
import requests,h5py,hdf5plugin,numpy as np
from remote_backend import Remote,clean,atomicjson,ROOT,BASE

class Links(HTMLParser):
    def __init__(self):super().__init__();self.links=[]
    def handle_starttag(self,t,a):
        if t=='a':self.links.append(dict(a).get('href',''))

def run():
    (ROOT/'inputs').mkdir(exist_ok=True)
    saved=ROOT/'inputs/source-files.json'
    if saved.exists():
        names=json.loads(saved.read_text())['files']
    else:
        index=requests.get(BASE,timeout=30);index.raise_for_status()
        (ROOT/'inputs/public-index.html').write_text(index.text)
        p=Links();p.feed(index.text)
        names=[n for n in p.links if n.startswith('blc27_') and n.endswith('.0002.h5') and any(f'_{s:04d}.' in n for s in range(29,35))]
        assert len(names)==6,names
        atomicjson(ROOT/'inputs/source-files.json',{'files':names,'index_url':BASE,'index_sha256':hashlib.sha256(index.content).hexdigest(),'fixed_sample_rule':'every 16th middle-product row plus first, middle, last'})
    for name in names:
        scan=int(name.split('.rawspec')[0][-4:]);out=ROOT/'data'/f'S-{scan:04d}.npz';meta=ROOT/'metadata'/f'S-{scan:04d}.json'
        if out.exists() and meta.exists():print('ALREADY',scan,flush=True);continue
        r=Remote(BASE+name,scan)
        with h5py.File(r,'r') as f:
            d=f['data'];a={k:clean(v) for k,v in d.attrs.items()}
            assert d.shape[1:]==(1,65536) and d.chunks==(1,1,1024)
            r.prefetch_tree()
            rows=np.unique(np.r_[np.arange(0,d.shape[0],16),d.shape[0]//2,d.shape[0]-1])
            records=[]
            for t in rows:
                group=[]
                for c in range(0,65536,1024):
                    q=d.id.get_chunk_info_by_coord((int(t),0,c));group.append({'row':int(t),'channel':c,'offset':q.byte_offset,'size':q.size,'mask':q.filter_mask})
                records.append(group)
            atomicjson(ROOT/'metadata'/f'chunks-S-{scan:04d}.json',records)
            jobs=[]
            for group in records:
                merged=[]
                for q in sorted(group,key=lambda x:x['offset']):
                    if merged and q['offset']==merged[-1][-1]['offset']+merged[-1][-1]['size']:merged[-1].append(q)
                    else:merged.append([q])
                jobs.extend(merged)
            print('BANDPASS ACQUIRE',scan,'rows',rows.tolist(),'requests',len(jobs),'payload',sum(q['size'] for g in records for q in g),flush=True)
            powers=np.empty((len(rows),65536),np.float32);rowmap={int(t):i for i,t in enumerate(rows)}
            with h5py.File('decode','w',driver='core',backing_store=False) as tmp:
                decoder=tmp.create_dataset('x',shape=(1,1,1024),chunks=(1,1,1024),dtype='float32',**hdf5plugin.Bitshuffle(nelems=0,cname='lz4'))
                def fetch(group):
                    a=group[0]['offset'];b=group[-1]['offset']+group[-1]['size']-1
                    return group,r.fetch(a,b,'sampled data')
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                    for group,(blob,record) in pool.map(fetch,jobs):
                        r.ledger.append(record)
                        for q in group:
                            start=q['offset']-group[0]['offset'];b=blob[start:start+q['size']]
                            decoder.id.write_direct_chunk((0,0,0),b,filter_mask=q['mask'])
                            powers[rowmap[q['row']],q['channel']:q['channel']+1024]=decoder[0,0,:]
            assert np.isfinite(powers).all()
            comparisons=[]
            for t,c in [(int(rows[0]),0),(int(rows[0]),60500),(int(rows[len(rows)//2]),32000),(int(rows[-1]),65535)]:
                v=float(d[t,0,c]);w=float(powers[rowmap[t],c]);assert v==w
                comparisons.append({'row':t,'channel':c,'direct_HDF5':v,'decoded':w})
            frequency=a['fch1']+np.arange(65536)*a['foff']
            part=out.with_suffix('.partial.npz');np.savez_compressed(part,power=powers,frequency_mhz=frequency,rows=rows);part.replace(out)
            info={'source_url':r.url,'scan':scan,'role':'ON' if scan%2 else 'OFF','attrs':a,'dataset_shape':d.shape,'chunks':d.chunks,'file_size':r.size,'etag':r.etag,'sampled_rows':rows.tolist(),'source_range_ledger':r.ledger,'native_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'direct_HDF5_comparisons':comparisons}
            atomicjson(meta,info)
            print('SAVED BANDPASS',scan,flush=True)

if __name__=='__main__':run()

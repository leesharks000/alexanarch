import json,csv,hashlib,time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
ROOT=Path(__file__).resolve().parent
WINDOWS={'low_recorded':(1655,1660),'C03_and_thirteen':(1665.5,1668.5),'filter_edge':(1678,1682),'above_filter':(1685,1695),'pre_calibration':(1700,1710),'calibration_low_end':(1720,1730),'reference_low':(1750,1760),'reference_high':(1810,1820)}
def csvout(p,rows):
    with p.open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def run():
    results=ROOT/'results';rows=[];qc=[];spectra=[]
    for scan in range(29,35):
        meta=ROOT/'metadata'/f'S-{scan:04d}.json'
        while not meta.exists():time.sleep(2)
        m=json.loads(meta.read_text());p=ROOT/'data'/f'S-{scan:04d}.npz'
        assert hashlib.sha256(p.read_bytes()).hexdigest()==m['native_sha256']
        z=np.load(p);a=z['power'];f=z['frequency_mhz'];rr=z['rows'];s=np.nanmedian(a,axis=0)
        refmask=(f>=1750)&(f<=1760);ref=float(np.nanmedian(a[:,refmask]));spectra.append((scan,f,s,ref))
        for name,(lo,hi) in WINDOWS.items():
            cut=a[:,(f>=lo)&(f<=hi)];perrow=np.nanmedian(cut,axis=1);value=float(np.nanmedian(perrow));ratio=value/ref
            rows.append({'scan':scan,'role':m['role'],'window':name,'low_mhz':lo,'high_mhz':hi,'sampled_times':len(a),'frequency_bins':cut.shape[1],'median_recorded_power':value,'relative_to_1750_1760_mhz':ratio,'relative_recorded_power_db':float(10*np.log10(ratio)) if ratio>0 else None,'temporal_fractional_MAD':float(1.4826*np.nanmedian(abs(perrow-value))/value) if value>0 else None,'minimum_row_power':float(np.nanmin(perrow)),'maximum_row_power':float(np.nanmax(perrow))})
        qc.append({'scan':scan,'finite_fraction':float(np.isfinite(a).mean()),'zero_samples':int((a==0).sum()),'negative_samples':int((a<0).sum()),'rows':rr.tolist(),'native_sha256':m['native_sha256'],'direct_HDF5_comparisons':len(m['direct_HDF5_comparisons'])})
        csvout(results/'bandpass-summary.csv',rows)
        print('BANDPASS ANALYZED',scan,flush=True)
    fig,axes=plt.subplots(2,1,figsize=(11,8),sharex=True)
    for scan,f,s,ref in spectra:
        # Median of fixed1024-channel chunks for legibility; retain full-resolution native arrays.
        xx=np.median(f.reshape(64,1024),axis=1);yy=np.median(s.reshape(64,1024),axis=1)/ref
        label=f'{scan} '+('ON' if scan%2 else 'OFF')
        axes[0].semilogy(xx,yy,label=label,lw=1.2)
        axes[1].plot(xx,10*np.log10(yy),label=label,lw=1.2)
    for ax in axes:
        ax.axvspan(1665.5,1668.5,color='crimson',alpha=.2,label='candidate band' if ax is axes[0] else None)
        ax.axvline(1680,color='black',ls='--',lw=.9);ax.axvline(1730,color='gray',ls=':',lw=.9);ax.grid(alpha=.2)
    axes[0].set_ylabel('Recorded power / 1750–1760 MHz');axes[0].legend(ncol=4,fontsize=8)
    axes[1].set_ylabel('Relative recorded power (dB)');axes[1].set_xlabel('Header frequency (MHz)')
    axes[0].set_title('Later Green Bank S-band: sampled bandpass, not calibrated antenna gain')
    fig.tight_layout();fig.savefig(results/'S-band-recorded-bandpass.png',dpi=160);plt.close(fig)
    target=[r for r in rows if r['window']=='C03_and_thirteen']
    summary={'status':'feasibility stage complete','quality':qc,'candidate_band_rows':target,'response_gate':'No supported celestial response calibration at1665–1668MHz established. Outside nominal1730MHz receiver range and below documented1680MHz widest RF-filter edge. Stop physical C03-strength exclusion; measured recorded power is not a gain calibration.','source_powers_examined':'20 preselected rows per scan across full node frequency axis; not a search for C03 in .0000 spectra.','total_native_values':int(sum(len(q['rows'])*65536 for q in qc)),'direct_HDF5_comparisons':sum(q['direct_HDF5_comparisons'] for q in qc)}
    (results/'feasibility-summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
    print('FEASIBILITY COMPLETE',flush=True)

if __name__=='__main__':run()

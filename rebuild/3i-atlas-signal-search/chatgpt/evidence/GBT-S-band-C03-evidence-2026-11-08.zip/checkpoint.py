from pathlib import Path
import json,zipfile,hashlib,sys
R=Path(__file__).resolve().parent
def pack(final=False):
    band=[int(x.stem[-4:]) for x in (R/'metadata').glob('S-*.json')]
    fine=[int(x.stem[-4:]) for x in (R/'metadata').glob('fine-S-*.json')]
    scores=[int(x.stem[-4:]) for x in (R/'results').glob('fine-S-*.json')]
    state={'bandpass_complete':sorted(band),'fine_acquisition_complete':sorted(fine),'fine_scoring_complete':sorted(scores),'all_fine_results_complete':(R/'results/fine-summary.json').exists(),'validation_complete':(R/'results/validation.json').exists(),'status':'complete' if final else 'partial'}
    (R/'results/checkpoint-state.json').write_text(json.dumps(state,indent=2))
    text='# S-band C03 follow-up — '+state['status']+'\n\n'
    text+='Bandpass scans saved: '+str(sorted(band))+'. Fine-cutout scans saved: '+str(sorted(fine))+'. Fine scores saved: '+str(sorted(scores))+'.\n\n'
    text+='C03 frequency is outside the nominal S receiver range and below the published wide RF-filter edge. Public calibration did not establish celestial response there. Fine results are descriptive recorded-feature comparisons only. Do not call a failed recurrence an exclusion at the prior26mW C03 strength. The original13 are not all retested by this narrow cutout.\n\n'
    text+='Restore this archive directly. Native NPZs, complete metadata/range hashes and scripts are included; optional compressed cache files are omitted. Read README-reproduce.md. Dependencies and versions are in inputs/software-versions.json. Run prepare_tracks.py from saved ephemerides, sample_bandpass.py for any missing20-row bandpass cuts, acquire_fine.py for any missing fine cuts, analyze_bandpass.py, analyze_fine.py and validate.py. Do not assume an earlier live process survived. Pending stages can be restarted; completed NPZ/metadata pairs are skipped.\n\n'
    text+='Plan: libfile_07ff89040aa0819183425bbae4140813. Frozen fine coordinates: libfile_45d898dea6c08191936419c8a2415f32. Evidence identity: libfile_ef5dac4441d081918167e751b6b1225d. Original high-time/older C03 work remains separate and unchanged.\n'
    (R/'CHECKPOINT.md').write_text(text)
    data={}
    for f in R.rglob('*'):
        if not f.is_file():continue
        rel=f.relative_to(R)
        if any(x in rel.parts for x in ['cache','helpers','__pycache__']):continue
        if f.name in ['GBT-S-band-C03-evidence.zip','SHA256SUMS.json'] or '.partial.' in f.name:continue
        data[str(rel)]=f.read_bytes()
    sums={k:hashlib.sha256(v).hexdigest() for k,v in data.items()};s=json.dumps(sums,indent=2).encode();(R/'SHA256SUMS.json').write_bytes(s)
    with zipfile.ZipFile(R/'GBT-S-band-C03-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        for k,v in data.items():z.writestr(k,v)
        z.writestr('SHA256SUMS.json',s)
    print(json.dumps(state));print('bytes',(R/'GBT-S-band-C03-evidence.zip').stat().st_size)
if __name__=='__main__':pack('final' in sys.argv)

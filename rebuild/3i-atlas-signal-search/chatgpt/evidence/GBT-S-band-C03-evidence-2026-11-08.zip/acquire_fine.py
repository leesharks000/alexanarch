import json,concurrent.futures,hashlib
import numpy as np,h5py,hdf5plugin
from remote_backend import ROOT,Remote,clean,atomicjson,BASE

def run():
    plan=json.loads((ROOT/'inputs/fixed-fine-plan.json').read_text());sources=json.loads((ROOT/'inputs/source-files.json').read_text())['files']
    for source in sources:
        name=source.replace('.0002.h5','.0000.h5');scan=int(name.split('.rawspec')[0][-4:]);out=ROOT/'data'/f'fine-S-{scan:04d}.npz';meta=ROOT/'metadata'/f'fine-S-{scan:04d}.json'
        if out.exists() and meta.exists():print('ALREADY FINE',scan,flush=True);continue
        r=Remote(BASE+name,10000+scan)
        with h5py.File(r,'r') as f:
            d=f['data'];a={k:clean(v) for k,v in d.attrs.items()}
            assert d.chunks==(1,1,1048576) and d.shape[1:]==(1,67108864)
            df=a['foff']*1e6;f0=a['fch1']*1e6
            lo=int(np.floor((plan['tile_high_hz']-f0)/df));hi=int(np.ceil((plan['tile_low_hz']-f0)/df))+1
            chunk0=(lo//1048576)*1048576;assert chunk0==((hi-1)//1048576)*1048576
            r.prefetch_tree()
            jobs=[]
            for t in range(d.shape[0]):
                q=d.id.get_chunk_info_by_coord((t,0,chunk0));jobs.append({'t':t,'offset':q.byte_offset,'size':q.size,'mask':q.filter_mask})
            print('FINE ACQUIRE',scan,'coarse',chunk0//1048576,'tile',hi-lo,'compressed_bytes',sum(q['size'] for q in jobs),flush=True)
            power=np.empty((d.shape[0],hi-lo),np.float32)
            with h5py.File('decode','w',driver='core',backing_store=False) as tmp:
                dec=tmp.create_dataset('x',shape=(1,1,1048576),chunks=(1,1,1048576),dtype='float32',**hdf5plugin.Bitshuffle(nelems=0,cname='lz4'))
                def fetch(q):return q,r.fetch(q['offset'],q['offset']+q['size']-1,'fine source chunk')
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                    for q,(blob,rec) in pool.map(fetch,jobs):
                        r.ledger.append(rec);dec.id.write_direct_chunk((0,0,0),blob,filter_mask=q['mask']);power[q['t']]=dec[0,0,lo-chunk0:hi-chunk0]
            assert np.isfinite(power).all() and (power>0).all()
            parity=[]
            for t,j in [(0,0),(d.shape[0]//2,(hi-lo)//2),(d.shape[0]-1,hi-lo-1)]:
                v=float(d[t,0,lo+j]);w=float(power[t,j]);assert v==w;parity.append({'t':t,'full_channel':lo+j,'source':v,'copy':w})
            times=a['tstart']+(np.arange(d.shape[0])+.5)*a['tsamp']/86400
            partial=out.with_suffix('.partial.npz');np.savez_compressed(partial,power=power,times_mjd=times,f0_hz=f0+lo*df,df_hz=df,dt_s=a['tsamp']);partial.replace(out)
            info={'scan':scan,'role':'ON' if scan%2 else 'OFF','url':r.url,'source_shape':d.shape,'source_chunks':d.chunks,'source_file_size':r.size,'etag':r.etag,'attrs':a,'tile_full_channel_start':lo,'tile_full_channel_stop':hi,'coarse_channel':chunk0//1048576,'cutout_shape':power.shape,'native_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'byte_ranges':r.ledger,'direct_HDF5_parity':parity,'compressed_data_bytes':sum(q['size'] for q in jobs)}
            atomicjson(meta,info);print('SAVED FINE',scan,flush=True)

if __name__=='__main__':run()

# S-band C03 follow-up — complete

Bandpass scans saved: [29, 30, 31, 32, 33, 34]. Fine-cutout scans saved: [29, 30, 31, 32, 33, 34]. Fine scores saved: [29, 30, 31, 32, 33, 34].

C03 frequency is outside the nominal S receiver range and below the published wide RF-filter edge. Public calibration did not establish celestial response there. Fine results are descriptive recorded-feature comparisons only. Do not call a failed recurrence an exclusion at the prior26mW C03 strength. The original13 are not all retested by this narrow cutout.

Restore this archive directly. Native NPZs, complete metadata/range hashes and scripts are included; optional compressed cache files are omitted. Read README-reproduce.md. Dependencies and versions are in inputs/software-versions.json. Run prepare_tracks.py from saved ephemerides, sample_bandpass.py for any missing20-row bandpass cuts, acquire_fine.py for any missing fine cuts, analyze_bandpass.py, analyze_fine.py and validate.py. Do not assume an earlier live process survived. Pending stages can be restarted; completed NPZ/metadata pairs are skipped.

Plan: libfile_07ff89040aa0819183425bbae4140813. Frozen fine coordinates: libfile_45d898dea6c08191936419c8a2415f32. Evidence identity: libfile_ef5dac4441d081918167e751b6b1225d. Original high-time/older C03 work remains separate and unchanged.

import json,hashlib,math,csv
from pathlib import Path
from statistics import median
import numpy as np
R=Path(__file__).resolve().parent
def run():
    checks=[];source_checks=0
    for scan in range(29,35):
        for kind,name in [('bandpass',f'S-{scan:04d}'),('fine',f'fine-S-{scan:04d}')]:
            m=json.loads((R/'metadata'/f'{name}.json').read_text());p=R/'data'/f'{name}.npz'
            assert hashlib.sha256(p.read_bytes()).hexdigest()==m['native_sha256']
            cc=m['direct_HDF5_comparisons'] if kind=='bandpass' else m['direct_HDF5_parity'];source_checks+=len(cc)
        for mode in ['comet','receiver']:
            p=np.load(R/'results'/f'profiles-S-{scan:04d}-{mode}.npz');a=p['amplitudes'];q=p['distance_weights'];weights=[]
            for t in range(a.shape[1]):
                values=list(map(float,a[1:,t]));mid=median(values);sig=1.4826*median([abs(x-mid) for x in values]);weights.append(1/sig**2)
            denom=math.fsum(w*float(v)**2 for w,v in zip(weights,q));means=[]
            for row in a:means.append(math.fsum(float(v)*w*float(qq) for v,w,qq in zip(row,weights,q))/denom)
            center=median(means[1:]);scale=1.4826*median([abs(x-center) for x in means[1:]])
            score=(means[0]-center)/scale;error=abs(score-float(p['scores'][0]));assert error<1e-9
            checks.append({'scan':scan,'mode':mode,'independent_score':score,'stored_score':float(p['scores'][0]),'score_error':error})
    with (R/'results/all-injection-trials.csv').open() as f:trials=list(csv.DictReader(f))
    maximum=max(float(x['linear_increment_max_error']) for x in trials);assert maximum<2e-6 and len(trials)==660
    result={'passed':True,'native_archives_hash_checked':12,'direct_source_HDF5_scalar_checks':source_checks,'independent_whole_scan_score_checks':checks,'score_max_error':max(x['score_error'] for x in checks),'raw_power_injection_trials':len(trials),'injection_max_increment_error':maximum,'scope':'Independent Python median/fsum reconstruction; measured-power recoveries, no celestial source calibration.'}
    (R/'results/validation.json').write_text(json.dumps(result,indent=2));print('VALIDATED',len(checks),'scores;',source_checks,'source parity checks;',len(trials),'injections',flush=True)
if __name__=='__main__':run()

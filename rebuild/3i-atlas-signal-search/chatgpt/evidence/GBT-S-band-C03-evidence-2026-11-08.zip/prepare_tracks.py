import json,datetime,hashlib
import numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parent
C=299792.458
def read_ep(p):
    s=json.loads(Path(p).read_text())['result'];rows=[]
    for line in s.split('$$SOE')[1].split('$$EOE')[0].strip().splitlines():
        cells=line.split(',');numeric=[]
        for cell in cells:
            try:numeric.append(float(cell.strip()))
            except ValueError:pass
        if any(2400000<v<2600000 for v in numeric):t=next(v for v in numeric if 2400000<v<2600000)-2400000.5
        else:
            date=datetime.datetime.strptime(cells[0].strip(),'%Y-%b-%d %H:%M')
            t=(date-datetime.datetime(1858,11,17)).total_seconds()/86400
        rows.append([t,numeric[-2],numeric[-1]])
    return np.array(rows),s
if __name__=='__main__':
    new,ss=read_ep(ROOT/'inputs/sband-horizons-response.json')
    old,_=read_ep(ROOT/'inputs/prior-GBT-ephemeris.json')
    keep=(old[:,0]>=new[0,0])&(old[:,0]<=new[-1,0]);delta=np.interp(old[keep,0],new[:,0],new[:,2])-old[keep,2]
    prior=json.loads((ROOT/'inputs/prior-plan.json').read_text());anchor=61027.2011003606
    rf=prior['rest_hz']*(1-np.interp(anchor,old[:,0],old[:,2])/C)
    maxerr=float(abs(delta).max()*prior['rest_hz']/C)
    assert maxerr<.1,'Ephemeris change exceeds 0.1Hz; inspect before proceeding'
    plan={'rest_hz':prior['rest_hz'],'sigma_rest_hz':prior['sigma_rest_hz'],'exposure_subtimes':16,'receiver_fixed_hz':rf,'receiver_anchor_mjd':anchor,'control_offsets_hz':prior['controls_hz'],'background_exclusion_hz':50,'background_blocks_per_side':10,'background_block_channels':128,'template_support_sigma':8,'gate':{'ON':2.5,'OFF':2.0},'ephemeris_overlap_max_frequency_difference_hz':maxerr,'ephemeris_overlap_rows':int(keep.sum()),'tile_low_hz':1665580000.,'tile_high_hz':1665710000.,'scope':'Descriptive uncalibrated raw-feature recurrence, no physical upper limit or source exclusion. Strict frozen coordinates; no maximization.'}
    (ROOT/'inputs/fixed-fine-plan.json').write_text(json.dumps(plan,indent=2));np.save(ROOT/'inputs/sband-ephemeris.npy',new)
    print(json.dumps(plan,indent=2))

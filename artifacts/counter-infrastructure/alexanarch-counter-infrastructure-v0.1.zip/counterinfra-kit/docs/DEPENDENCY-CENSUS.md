# Dependency Census — 2026-07-12

## GitHub

- Account: `leesharks000`
- Repositories inspected: 41
- GitHub-reported aggregate size: 934,681 KiB (~913 MiB)
- Public: 39 repositories, 687,867 KiB
- Private: 2 repositories, 246,814 KiB
- Immediate consequence: a single account action can affect canonical data, build code, observatories, public domain surfaces, and private source material together.

## Vercel

`alexanarch` is a predominantly static repository. The provider-specific `vercel.json` consists principally of redirects, response headers, CORS, and cache policy. These rules are reproduced in `hosting/Caddyfile`; Vercel is therefore replaceable as a serving substrate.

## Existing fanout

The current `scripts/fanout.py` covers:

- Software Heritage submission for `alexanarch`, `machinemediation-org`, and `the-mandala-oracle`;
- IndexNow notification;
- best-effort Wayback capture;
- optional per-deposit Internet Archive items;
- per-deposit GitHub releases.

Current persisted fanout state records:

- Software Heritage last run: `2026-07-12T04:34Z`
- GitHub releases high-water mark: `1055`
- IndexNow high-water mark: `1055`

It contains no persisted Wayback or Internet Archive item high-water mark. That does not prove no captures exist; it means the repository state does not currently evidence successful advancement of those two adapters.

## DNS and registrar

The registrar, DNS provider, renewal dates, recovery contacts, account identifiers, and transfer-lock state were not available to this execution environment. They belong in a **private** custody manifest, not the public repository.

## Recovery priority

Tier 0 repositories must be captured first. See `config/estate-repos.json`. Private repositories cannot be recovered from Software Heritage, Wayback, or public GitHub snapshots and therefore require authenticated backup.

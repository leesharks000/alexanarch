# Backup Secret Setup

The workflow is useful without secrets for public repositories. Independent upload and private-repository capture require secrets.

## Required for private repositories

`ESTATE_GH_TOKEN`

Use a fine-grained token limited to read-only access to the repositories in the estate. Do not grant administration, issue, workflow, or write permissions.

## Required for Internet Archive upload

- `IA_ACCESS`
- `IA_SECRET`

These are used only as `LOW access:secret` authorization for uploads to the configured Internet Archive item.

## Required for a second forge

- `MIRROR_SSH_KEY`
- `MIRROR_BASE_SSH`, for example `git@example.org:archive`

Pre-create empty target repositories or use a forge-specific provisioning step outside this generic workflow.

Never commit credentials to the repository, recovery archives, workflow logs, or generated manifests.

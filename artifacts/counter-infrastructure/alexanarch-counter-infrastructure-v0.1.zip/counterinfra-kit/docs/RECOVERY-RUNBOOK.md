# Estate Recovery Runbook

## 1. Verify the custody set

From the recovery directory:

```bash
sha256sum -c SHA256SUMS.txt
```

Do not restore from a set that fails verification.

## 2. Restore a repository from a Git bundle

```bash
git clone bundles/alexanarch.bundle alexanarch
cd alexanarch
git fsck --full
```

A bundle preserves Git objects and refs. It does not automatically contain Git LFS payloads or independent submodule repositories; consult `recovery-index.json` for warnings.

## 3. Restore without a Git forge

The default-branch worktree archive can be unpacked directly:

```bash
mkdir alexanarch-static
cd alexanarch-static
tar -xzf ../worktrees/alexanarch-main.tar.gz
```

Serve it locally:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080/`.

## 4. Serve with Caddy

Copy the restored Alexanarch tree to `/srv/alexanarch`, install Caddy, and use the supplied `hosting/Caddyfile`.

```bash
sudo caddy run --config hosting/Caddyfile
```

The configuration reproduces the essential Vercel redirects and security headers without requiring Vercel.

## 5. Restore to a new forge

Create an empty repository at the replacement forge, then:

```bash
cd alexanarch
git remote remove origin 2>/dev/null || true
git remote add origin git@example.org:archive/alexanarch.git
git push --mirror origin
```

Repeat in restore-order sequence from `config/estate-repos.json`.

## 6. Restore the resolution graph

Confirm that the following are present before announcing restoration:

- `data/registry.json`
- canonical texts under `data/texts/`
- static records under `s/records/`
- AXN resolver pages under `s/axn/`
- DOI-resolution data
- checksum manifests
- deposit schema and machine-facing manifests

A homepage-only mirror is not an archive restoration.

## 7. Domain failover

1. Deploy the static site to the replacement server.
2. Test through a temporary hostname.
3. Lower DNS TTL before planned migration when possible.
4. Change the `A`, `AAAA`, or `CNAME` records at the registrar/DNS provider.
5. Verify HTTPS, canonical URLs, redirects, JSON endpoints, and AXN resolution.
6. Preserve the former deployment as a mirror rather than deleting it.

## 8. Clean-room test

At least monthly, restore the archive in a fresh directory or virtual machine using only the recovery set and this runbook. Record:

- recovery-set identifier;
- checksum result;
- repositories restored;
- failed or missing refs;
- LFS/submodule warnings;
- AXN resolution test results;
- elapsed restoration time.

#!/usr/bin/env bash
set -euo pipefail

RECOVERY_DIR="${1:-estate-recovery}"
: "${MIRROR_BASE_SSH:?Set MIRROR_BASE_SSH, e.g. git@example.org:archive}"

python3 - "$RECOVERY_DIR" <<'PY'
import json, os, pathlib, subprocess, sys
recovery = pathlib.Path(sys.argv[1]).resolve()
base = os.environ['MIRROR_BASE_SSH'].rstrip('/')
manifest = json.loads((recovery / 'estate-repos.json').read_text())
for repo in sorted(manifest['repositories'], key=lambda r: (r.get('restore_order', 99), r['name'])):
    bundle = recovery / 'bundles' / f"{repo['name']}.bundle"
    if not bundle.exists():
        print(f"SKIP {repo['name']}: no bundle")
        continue
    tmp = recovery / '.mirror-work' / repo['name']
    tmp.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['git', 'clone', '--mirror', str(bundle), str(tmp)], check=True)
    target = f"{base}/{repo['name']}.git"
    print(f"PUSH {repo['name']} -> {target}")
    subprocess.run(['git', f'--git-dir={tmp}', 'push', '--mirror', target], check=True)
    subprocess.run(['rm', '-rf', str(tmp)], check=True)
PY

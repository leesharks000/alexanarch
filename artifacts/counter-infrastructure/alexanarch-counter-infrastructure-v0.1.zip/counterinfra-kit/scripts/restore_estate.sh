#!/usr/bin/env bash
set -euo pipefail

RECOVERY_DIR="${1:-estate-recovery}"
DEST="${2:-restored-estate}"
mkdir -p "$DEST"

(
  cd "$RECOVERY_DIR"
  sha256sum -c SHA256SUMS.txt
)

python3 - "$RECOVERY_DIR" "$DEST" <<'PY'
import json, pathlib, subprocess, sys
recovery = pathlib.Path(sys.argv[1]).resolve()
dest = pathlib.Path(sys.argv[2]).resolve()
manifest = json.loads((recovery / 'estate-repos.json').read_text())
for repo in sorted(manifest['repositories'], key=lambda r: (r.get('restore_order', 99), r['name'])):
    bundle = recovery / 'bundles' / f"{repo['name']}.bundle"
    target = dest / repo['name']
    if not bundle.exists():
        print(f"SKIP {repo['name']}: no bundle")
        continue
    if target.exists():
        print(f"SKIP {repo['name']}: target exists")
        continue
    print(f"RESTORE {repo['name']}")
    subprocess.run(['git', 'clone', str(bundle), str(target)], check=True)
    subprocess.run(['git', '-C', str(target), 'fsck', '--full'], check=True)
PY

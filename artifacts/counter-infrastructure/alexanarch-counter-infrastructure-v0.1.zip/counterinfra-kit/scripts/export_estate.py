#!/usr/bin/env python3
"""Create verified, portable recovery objects for a multi-repository estate.

Outputs for each non-empty repository:
- Git bundle containing all refs/history
- default-branch worktree tar.gz
- optional Git LFS object tar.gz when LFS objects are present
- verification and warning metadata

Optional: upload the output tree to an Internet Archive item.

No secret is written to disk or printed. Public repositories work without a token.
Private repositories require ESTATE_GH_TOKEN with read-only repository access.
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MANIFEST = ROOT / "config" / "estate-repos.json"


def run(cmd: list[str], *, env: dict[str, str] | None = None, cwd: Path | None = None,
        capture: bool = False, check: bool = True) -> subprocess.CompletedProcess[str]:
    safe = " ".join(cmd)
    print(f"+ {safe}")
    return subprocess.run(
        cmd,
        cwd=str(cwd) if cwd else None,
        env=env,
        text=True,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.STDOUT if capture else None,
        check=check,
    )


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def auth_env(token: str) -> dict[str, str]:
    env = os.environ.copy()
    if not token:
        return env
    basic = base64.b64encode(f"x-access-token:{token}".encode()).decode()
    env.update({
        "GIT_CONFIG_COUNT": "1",
        "GIT_CONFIG_KEY_0": "http.https://github.com/.extraheader",
        "GIT_CONFIG_VALUE_0": f"AUTHORIZATION: basic {basic}",
        "GIT_TERMINAL_PROMPT": "0",
    })
    return env


def current_ref(mirror: Path, configured_default: str) -> str | None:
    candidates = [f"refs/heads/{configured_default}", "refs/heads/main", "refs/heads/master"]
    for ref in candidates:
        result = run(["git", f"--git-dir={mirror}", "show-ref", "--verify", "--quiet", ref], check=False)
        if result.returncode == 0:
            return ref
    result = run(["git", f"--git-dir={mirror}", "for-each-ref", "--format=%(refname)", "refs/heads"], capture=True)
    refs = [line.strip() for line in (result.stdout or "").splitlines() if line.strip()]
    return refs[0] if refs else None


def has_file_at_ref(mirror: Path, ref: str, path: str) -> bool:
    result = run(["git", f"--git-dir={mirror}", "cat-file", "-e", f"{ref}:{path}"], check=False)
    return result.returncode == 0


def clone_and_export(repo: dict[str, Any], out: Path, work: Path, token: str) -> dict[str, Any]:
    name = repo["name"]
    visibility = repo["visibility"]
    result: dict[str, Any] = {
        "name": name,
        "full_name": repo["full_name"],
        "visibility": visibility,
        "criticality_tier": repo.get("criticality_tier"),
        "status": "pending",
        "files": [],
        "warnings": [],
    }
    if visibility == "private" and not token:
        result["status"] = "skipped-private-no-token"
        result["warnings"].append("ESTATE_GH_TOKEN is required for this private repository")
        return result

    mirror = work / f"{name}.git"
    url = f"https://github.com/{repo['full_name']}.git"
    env = auth_env(token if visibility == "private" else "")
    try:
        run(["git", "clone", "--mirror", url, str(mirror)], env=env)
    except subprocess.CalledProcessError as exc:
        result["status"] = f"clone-failed-{exc.returncode}"
        return result

    refs = run(["git", f"--git-dir={mirror}", "for-each-ref", "--format=%(refname)"], capture=True)
    all_refs = [line.strip() for line in (refs.stdout or "").splitlines() if line.strip()]
    if not all_refs:
        result["status"] = "empty-repository"
        return result

    bundles = out / "bundles"
    worktrees = out / "worktrees"
    lfsdir = out / "lfs"
    logs = out / "verification"
    for d in (bundles, worktrees, lfsdir, logs):
        d.mkdir(parents=True, exist_ok=True)

    bundle = bundles / f"{name}.bundle"
    run(["git", f"--git-dir={mirror}", "bundle", "create", str(bundle), "--all"])
    verify = run(["git", "bundle", "verify", str(bundle)], capture=True)
    verify_path = logs / f"{name}.bundle-verify.txt"
    verify_path.write_text(verify.stdout or "", encoding="utf-8")
    result["files"].append(str(bundle.relative_to(out)))
    result["files"].append(str(verify_path.relative_to(out)))

    ref = current_ref(mirror, repo.get("default_branch", "main"))
    result["restored_default_ref"] = ref
    if ref:
        archive = worktrees / f"{name}-{ref.rsplit('/',1)[-1]}.tar.gz"
        with archive.open("wb") as target:
            proc = subprocess.Popen(
                ["git", f"--git-dir={mirror}", "archive", "--format=tar.gz", ref],
                stdout=target,
            )
            if proc.wait() != 0:
                raise RuntimeError(f"git archive failed for {name}")
        result["files"].append(str(archive.relative_to(out)))
        if has_file_at_ref(mirror, ref, ".gitmodules"):
            result["warnings"].append("repository contains submodules; back up each submodule independently")

    # Fetch and preserve LFS objects when git-lfs is available.
    if shutil.which("git-lfs") or run(["git", "lfs", "version"], check=False).returncode == 0:
        fetch = run(["git", f"--git-dir={mirror}", "lfs", "fetch", "--all"], env=env, check=False)
        lfs_objects = mirror / "lfs" / "objects"
        if fetch.returncode == 0 and lfs_objects.exists() and any(lfs_objects.rglob("*")):
            lfs_archive = lfsdir / f"{name}-lfs-objects.tar.gz"
            with tarfile.open(lfs_archive, "w:gz") as tf:
                tf.add(lfs_objects, arcname="lfs/objects")
            result["files"].append(str(lfs_archive.relative_to(out)))
        elif fetch.returncode != 0:
            result["warnings"].append("git-lfs fetch failed or is not authorized")
    else:
        result["warnings"].append("git-lfs unavailable; bundle may contain pointers without LFS payloads")

    result["refs"] = len(all_refs)
    result["status"] = "ok"
    shutil.rmtree(mirror, ignore_errors=True)
    return result


def write_checksums(out: Path) -> None:
    checksum_path = out / "SHA256SUMS.txt"
    files = sorted(p for p in out.rglob("*") if p.is_file() and p != checksum_path)
    lines = [f"{sha256_file(p)}  {p.relative_to(out).as_posix()}" for p in files]
    checksum_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def upload_ia(out: Path, identifier: str, access: str, secret: str) -> None:
    if not access or not secret:
        print("Internet Archive upload skipped: IA_ACCESS/IA_SECRET not both present")
        return
    files = sorted(p for p in out.rglob("*") if p.is_file())
    for index, path in enumerate(files):
        remote_name = path.relative_to(out).as_posix()
        url = f"https://s3.us.archive.org/{identifier}/{remote_name}"
        headers = ["-H", f"Authorization: LOW {access}:{secret}"]
        if index == 0:
            headers += [
                "-H", "x-archive-auto-make-bucket: 1",
                "-H", "x-archive-meta-title: Alexanarch Estate Recovery Set",
                "-H", "x-archive-meta-creator: Lee Sharks",
                "-H", "x-archive-meta-mediatype: data",
                "-H", "x-archive-meta-subject: Alexanarch; archival continuity; disaster recovery; Git bundles",
            ]
        run(["curl", "--fail", "--show-error", "--silent", "--retry", "4", "--retry-all-errors",
             *headers, "--upload-file", str(path), url])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--output", type=Path, default=Path("estate-recovery"))
    parser.add_argument("--public-only", action="store_true")
    parser.add_argument("--repo", action="append", default=[], help="limit to one or more repository names")
    parser.add_argument("--upload-ia", action="store_true")
    parser.add_argument("--ia-identifier", default="alexanarch-estate-recovery")
    args = parser.parse_args()

    if not shutil.which("git"):
        print("git is required", file=sys.stderr)
        return 2
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    repos = manifest["repositories"]
    if args.repo:
        wanted = set(args.repo)
        repos = [r for r in repos if r["name"] in wanted]
    if args.public_only:
        repos = [r for r in repos if r["visibility"] == "public"]

    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out = args.output.resolve()
    work = out / ".work"
    out.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.manifest, out / "estate-repos.json")

    token = os.environ.get("ESTATE_GH_TOKEN", "")
    results = []
    for repo in sorted(repos, key=lambda r: (r.get("restore_order", 99), r["name"])):
        print(f"\n=== {repo['full_name']} ===")
        results.append(clone_and_export(repo, out, work, token))

    shutil.rmtree(work, ignore_errors=True)
    index = {
        "schema": "EA-COUNTERINFRA-RECOVERY-INDEX-0.1",
        "created_at": stamp,
        "source_manifest": args.manifest.name,
        "repository_results": results,
    }
    (out / "recovery-index.json").write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8")
    write_checksums(out)

    failures = [r for r in results if r["status"].startswith("clone-failed")]
    core_failures = [r for r in failures if r.get("criticality_tier") == 0]
    if args.upload_ia:
        upload_ia(out, args.ia_identifier, os.environ.get("IA_ACCESS", ""), os.environ.get("IA_SECRET", ""))
    print(f"\nRecovery set: {out}")
    print(f"Repositories attempted: {len(results)}; failures: {len(failures)}; tier-0 failures: {len(core_failures)}")
    return 1 if core_failures else 0


if __name__ == "__main__":
    raise SystemExit(main())

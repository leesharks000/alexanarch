#!/usr/bin/env python3
"""Best-effort Wayback seeding for critical public surfaces."""
import argparse, os, pathlib, time, urllib.parse, urllib.request, urllib.error

p = argparse.ArgumentParser()
p.add_argument('url_file', nargs='?', default=str(pathlib.Path(__file__).resolve().parent.parent/'config'/'critical-urls.txt'))
p.add_argument('--delay', type=float, default=5.0)
a = p.parse_args()
access, secret = os.getenv('IA_ACCESS',''), os.getenv('IA_SECRET','')
headers = {'Accept':'application/json','User-Agent':'EA-COUNTERINFRA-01/0.1'}
if access and secret:
    headers['Authorization'] = f'LOW {access}:{secret}'
urls = [u.strip() for u in pathlib.Path(a.url_file).read_text().splitlines() if u.strip() and not u.startswith('#')]
failed=[]
for url in urls:
    req=urllib.request.Request('https://web.archive.org/save', data=urllib.parse.urlencode({'url':url}).encode(), headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            print(r.status, url)
            if r.status not in (200,302): failed.append(url)
    except Exception as exc:
        print('ERROR', url, exc)
        failed.append(url)
    time.sleep(a.delay)
raise SystemExit(1 if failed else 0)

# Alexanarch Counter-Infrastructure Kit

This kit is the first executable custody layer for **EA-COUNTERINFRA-01 v0.1**.

It contains:

- a frozen inventory of 41 repositories under `leesharks000`;
- a full-history Git bundle and worktree-export generator;
- private-repository support through a read-only token;
- checksum and bundle-verification generation;
- optional direct upload to an Internet Archive item;
- a second-forge mirror script and workflow;
- a vendor-neutral Caddy deployment configuration reproducing the essential Vercel behavior;
- a clean-room recovery runbook;
- a Wayback seeding script for critical surfaces.

## Fastest operational path

1. Copy this kit into the root of `alexanarch` or another controlled runner.
2. Add the workflow files under `.github/workflows/` if GitHub Actions is the first execution substrate.
3. Add read-only `ESTATE_GH_TOKEN` and Internet Archive credentials as described in `docs/SECRET-SETUP.md`.
4. Run the **Estate recovery export** workflow manually.
5. Download the resulting recovery set and verify `SHA256SUMS.txt` outside GitHub.
6. Confirm that the Internet Archive item contains the same checksum manifest.
7. Perform a clean-room restore using `docs/RECOVERY-RUNBOOK.md`.

The GitHub artifact is temporary staging only. The independent custody copy is the point.

# Install into the Alexanarch repository

Copy these files:

```text
config/estate-repos.json                 -> config/estate-repos.json
scripts/export_estate.py                 -> scripts/export_estate.py
scripts/restore_estate.sh                -> scripts/restore_estate.sh
scripts/mirror_estate.sh                 -> scripts/mirror_estate.sh
scripts/seed_wayback.py                  -> scripts/seed_wayback.py
workflows/estate-recovery.yml            -> .github/workflows/estate-recovery.yml
workflows/mirror-secondary.yml           -> .github/workflows/mirror-secondary.yml
hosting/Caddyfile                        -> counterinfra/hosting/Caddyfile
hosting/docker-compose.yml               -> counterinfra/hosting/docker-compose.yml
docs/RECOVERY-RUNBOOK.md                 -> counterinfra/RECOVERY-RUNBOOK.md
docs/SECRET-SETUP.md                     -> counterinfra/SECRET-SETUP.md
EA-COUNTERINFRA-01_v0.1.md               -> counterinfra/EA-COUNTERINFRA-01_v0.1.md
```

Do not replace the existing `scripts/fanout.py`. That script handles propagation; this kit adds estate-level custody and reconstruction.
